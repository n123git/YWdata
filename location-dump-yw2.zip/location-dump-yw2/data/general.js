// NOTE: for datapoints like these which dynamically generate themselves, open up console IN my editor and the built versions can be accessed (and copied) there :D

const weatherevents = ["<unknown>", "<unknown>", "Yo-kai Advisory", "Yo-kai Warning", "Tripping Advisory", "Bugs: Swarming!", "Fish: Good fishing!", "<unknown>"];

const chests = Array.from({ length: 144 }, (_, i) => // 144-bit
{
  switch(i) { // by the time i'n done, this'll be the longest switch statement in human history, undertale can't compete with that (ifykyk)

    // Harisville Main Area (90-99)
    case 90:
      return "Harrisville -640 90 -585 Bitter Medicine";
    case 91:
      return "Harrisville -100 25 215 Amazing Milk" // my semi-colons will be very inconsistently placed from here on out :>
    case 92:
      return "Harrisville  92 -775 55 -155 Dancing Star";
    case 93:
      return "Harrisville -620 -15 200 Bronze Doll 2x"
    case 94:
      return "Harrisville -650 80 -320 Cucumber x10"
    case 95:
      return "Harrisville -1100,120,-575 Medium Exporb 2x";
    case 96:
      return "Harrisville -50 15 450 Carrot x10"
    case 97:
      return "Harrisville 350 -11 400 Candy Apple x2"
    case 98:
      return "Harrisville 1000, 15, 500 Purple Coin";
    case 99:
      return "Harrisville 750, -35, 600 Shaved Ice 2x";
    case 113:
      return "Rice Paddy Path -100, 100, 75 Medium Exporb"
   case 114:
      return "Rice Paddy Path 10, 80, -100 Strength Talisman 2x";
    case 123:
      return "Harrisville Station Plaza 185, 0, 200 Use Karate";
    case 124:
      return "Harrisville Station Plaza 350, 0, 50 Slab Bacon"; // I totally didn't make the semi-colons EVEN more inconsistent while doing this :<>
    case 128:
      return "Alley off the Plaza ?, ?, ? Key to Apt. C-302"
    case 129:
      return "Alley off the Plaza ?, ?, ? Pretty Ring"
    case 130:
      return "Alley off the Plaza ?, ?, ? Amazing Milk";
    default:
      return `Chest ${i}`;
    } 
}); // treasure chest labels

const trophies = Array.from({ length: 96 }, (_, i) => // 96-bit
{ // Even though I got trophy editing BEFORE treasure chest editing, i'm only labelling it now smh :<
  let z = i + 1
  switch(z) {  // I totally didnt make the mistake of making this i - 1, why would you assume that!?... and then realised it was correct an HOUR later (to be fair I was adding trophy data)

    
    // Playtime Trophies
    case 10:
      return `Promising Rookie (Bronze, "Played for 30+ hours.")` // no semicolons AT ALL this time :<>
    case 11:
      return `Seasoned Veteran (Silver, "Played for 100+ hours.")`
    case 12:
      return `Honorary President (Gold, "Played for 300+ hours.")`

    // Boss defeating
    case 13:
      return `Dame's Destruction (Silver, "Defeated Dame Demona.")`
    case 14:
      return `String Slicer (Bronze, "Defeated Kat Kraydel.")`

    // Medallium Trophies

      // Medallium Percentage
    case 15:
      return `Yo-kai Fan (Bronze, "Filled 25% of the Medallium.")`
    case 16:
      return `Yo-kai Fanatic (Silver, "Filled 50% of the Medallium.")`
    case 17:
      return `Yo-kai Master (Gold, "Filled 100% of the Medallium.")`
    
      // Medallium by Type + Alliance
      
    case 18:
      return `Spirited Ally (Gold, "Became friends with every type of Bony Spirit.")`
    case 19:
      return `Soul Seeker (Gold, "Became friends with every type of Fleshy Soul.")`

    // Battle Trophies

      // Battle Amounts
    case 20:
      return `Warrior (Bronze, "Completed 100 battles.")`
    case 21:
      return `Berserker (Silver, "Completed 1,000 battles.")` // where gold one :<>

      // Tournament Battles
    
        // Official Ones
    case 22:
      return `Official Gold Champ (Bronze, "Won every battle in official gold knockout bout.")` // ironic name, also grammar issue in official translation?
    case 23:
      return `Official Platinum Ace (Silver, "Won 50 battles in official platinum knockout bout.")` // also maybe grammar issue in official translation?
    case 24:
      return `Official Platinum Star (Gold, "Won 100 battles in official platinum knockout bout.")` // also, also maybe grammar issue in official translation?

      // Casual Ones
    case 25:
      return `Casual Gold Champ (Bronze, "Won every battle in casual gold knockout bout.")` // also ironic name, also grammar issue in official translation?
    case 26:
      return `Casual Platinum Ace (Silver, "Won 50 battles in casual platinum knockout bout.")` // also maybe grammar issue in official translation?
    case 27:
      return `Casual Platinum Star (Gold, "Won 100 battles in casual platinum knockout bout.")` // also, also maybe grammar issue in official translation?

      // More boss related battles

    case 28:
      return `Boss Battler (Bronze, "Completed three boss rushes.")`
    case 29:
      return `Boss Master (Silver, "Completed every boss rush.")`

      // Mission related battles
    
    case 30:
      return `Mission Master (Silver, "Completed every mission battle.")`

      // Generic Battle Stats

        // Battle action counts

    case 31:
      return `Soultimate Star (Bronze, "Performed 300 Soultimates.")`
    case 32:
      return `Gold Master (Bronze, "Pinned 100 golden Wisps.")`
    case 33:
      return `Spirit Master (Bronze, "Performed 1,000 Purifications.")`
    case 34:
      return `Turning Tactician (Bronze, "Turned the Yo-kai Wheel a total of 9,999 times during battle.")`

        // Ranks
    case 35:
      return `Yo-kai Beginner (Bronze, "Obtained Rank 5 in random Yo-kai battles.")` // Watch how Rank is capital here
    case 36:
      return `Yo-kai Expert (Silver, "Obtained Expert rank in random Yo-kai battles.")` // but now it's "Expert rank" :<>

    default:
      return `Trophy ${z}`;
    } 
}); // trophy labels


console.warn("Note: Instead of trying to read through the console, read the raw HTML or read the docs folder on my github. If you still have any questions, feel free to ping me on discord (@n123original)") // friendly reminder

const wallpapers = [
  "Cool Blue",  // index 0
  "Antique Blossoms",  // index 1
  "Bamboo Forest",  // index 2 and so on....
  "Merchant Purple",
  "Hearts and Fluff",
  "Classic Gold",
  "Up All Night", 
  "Oh My Swirls! Pattern",
  "Galaxy Cruise",
  "Small Cream Soda",
  ...Array(246).fill("Not a valid Wallpaper (Renders as -1)")  // indexes 10–255
];

const cycles = [
  "Also Breeze??? but it isnt selected, probably a fallback/default", // index 0
  "Sunset Cycle",  // index 1
  "Seaside Cycle",  // index 2
  "Sakura Cycle",  // index 3
  "Forest Cycle",  // index 4, you should probably have gotten the hint by now, but whatever
  "Cirrus Cycle",  // index 5
  "Sunshine Cycle",  // index 6
  "Splendid Cycle",  // index 7
  "Sinister Cycle",  // index 8
  "Golden Cycle",  // index 9
  "Breeze Cycle",  // index 10
  ...Array(245).fill("Not a valid Cycle, is invisible during usage")  // indexes 11-255
];

const bells = [
  "Classic Bell", // not labelling the indexes this time :>
  "Spring Bell",
  "<unknown>",
  "<unknown>",
  "Chime Bell",
  "<unknown>",
  "<unknown>",
  "Siren Bell",
  ...Array(256 - 8).fill("<unknown>")  // fills indexes 8 through 255

];


locations = { /* Incomplete: doesn't include all unused areas */
  "17200202": "Springdale Hot Springs Lobby",
  "58714891": "Old Springdale",
  "66035755": "Cicada Canyon",
  "67711696": "Wayfarer Manor 102",
  "89317490": "Unknown (Black Minimap, Just one texture inside)",
  "9C5EC1A9": "Paradise Springs Entrance",
  "260FC830": "Gera Gera Land Entrance",
  "B03FCF47": "Wolfit Down Entrance",
  "859AACAE": "Paradise Springs",
  "3FCBA537": "Gera Gera Land",
  "A9FBA240": "Wolfit Down",
  "38E61DD0": "Kaibuki Theater",
  "AED61AA7": "Kaibuki Theater Basement",
  "989BADCD": "Yo-kai world Entrance",
  "22CAA454": "Yo-kai world",
  "B4FAA323": "Liar Mountain",
  "176FC7BD": "Hooligan Road",
  "815FC0CA": "Hungry Pass",
  "FFDBAFC7": "Unknown (Hexpress?)",
  "69EBA8B0": "Paradise Springs Station",
  "D3BAA129": "Gera Gera Land Station",
  "458AA65E": "Wolfit Down Station",
  "CADA26AD": "Underground Waterway",
  "936460AF": "Unknown (Carried over from YW1)",
  "398D9D62": "Shady Back Alley",
  "83DC94FB": "Lonely Waterway",
  "15EC938C": "The Catwalk",
  "2049F065": "Desolate Lane",
  "F603DC17": "Uptown Springdale",
  "6A1E456A": "Nate's house F1",
  "D04F4CF3": "Nate's house F2",
  "467F4B84": "Katie's House F1",
  "E5EA2F1A": "Katie's House F2",
  "E87C7358": "Banter Bakery",
  "C41D7DB6": "Everymart Uptown",
  "F1B81E5F": "Springdale Community Center",
  "DDD910B1": "Piggleston Bank",
  "DAF4A856": "Lambert Post Office",
  "A94D6841": "Jungle Hunter",
  "B0890546": "Memory Store",
  "2FEA3217": "Springdale Elementary 1F South",
  "95BB3B8E": "Springdale Elementary 1F North",
  "038B3CF9": "Springdale Elementary 2F",
  "362E5F10": "Springdale Elementary 3F",
  "8B52EE6E": "Springdale Elementary Roof",
  "1D62E919": "Springdale Elementary Gym",
  "D7222870": "Mt. Wildwood Trail",
  "6D7321E9": "Mt. Wildwood Summit",
  "FB43269E": "Jumbo Slider",
  "1471055B": "Abandoned Tunnel West",
  "AE200CC2": "Abandoned Tunnel East",
  "18AC6905": "Mt. Wildwood",
  "84B1F078": "Deserted House",
  "3EE0F9E1": "Deserted House (Empty?)",
  "06D3C64A": "Mt. Wildwood Cave",
  "B24594C8": "Trucked Away Lot",
  "9E249A26": "Hidden Side Street",
  "F3748FD1": "Secret Byway",
  "7116B9E3": "Old Mansion Main House",
  "5D77B70D": "Old Mansion Side House",
  "68D2D4E4": "Old Mansion Main House Attic",
  "D283DD7D": "Old Mansion Side House Attic",
  "B680F8AC": "Infinite Inferno 1st Circle",
  "0CD1F135": "Infinite Inferno 2nd Circle",
  "9AE1F642": "Infinite Inferno 3rd Circle",
  "397492DC": "Infinite Inferno 4th Circle",
  "AF4495AB": "Infinite Inferno 5th Circle",
  "15159C32": "Infinite Inferno 6th Circle",
  "83259B45": "Infinite Inferno 7th Circle",
  "123824D5": "Infinite Inferno 8th Circle",
  "7DCBD5BD": "Blossom Heights",
  "E1D64CC0": "Bernstein House 1F",
  "5B874559": "Bernstein House 2F",
  "CDB7422E": "Bernstein House 3F",
  "63B47AF2": "Timers & More",
  "4FD5741C": "Candy Stop",
  "7A7017F5": "Everymart Blossom Heights",
  "228561EB": "Shoten Temple",
  "0EE46F05": "Prayer's Peak Tunnel",
  "3B410CEC": "Chloro-Phil Good",
  "863DBD92": "Springdale Hot Springs Men",
  "100DBAE5": "Springdale Hot Springs Female",
  "A4223BBD": "Byrd House",
  "F14111E1": "Wayfarer Manor 101",
  "DD201F0F": "Wayfarer Manor 103",
  "4B101878": "Wayfarer Manor 104",
  "E8857CE6": "Wayfarer Manor 105",
  "7EB57B91": "Wayfarer Manor 201",
  "C4E47208": "Wayfarer Manor 202",
  "52D4757F": "Wayfarer Manor 203",
  "C3C9CAEF": "Wayfarer Manor 204",
  "55F9CD98": "Wayfarer Manor VIP Room",
  "0B7D4355": "Academy Shortcut",
  "271C4DBB": "Behind Frostia's Place",
  "12B92E52": "Delivery Bay",
  "4A4C584C": "Springdale Business Tower 4F",
  "662D56A2": "Springdale Business Tower 13F",
  "E44F6090": "Construction Site 3F",
  "C4F30220": "Downtown Springdale",
  "DA8CAD6F": "Seabreeze Tunnel",
  "F6EDA381": "Frostia's Place",
  "C348C068": "Arcadia Arcade",
  "EF29CE86": "Nom Burguer",
  "E8047661": "Fortune Hospital 1F",
  "0D8DB101": "Fortune Hospital 2F",
  "9BBDB676": "Foundation Academy",
  "B7DCB898": "Everymart Downtown Springdale",
  "8279DB71": "Café Shanista",
  "AE18D59F": "Springdale Sports Club 1F",
  "3F056A0F": "Springdale Sports Club 2F",
  "A9356D78": "Springdale Sports Club 3F",
  "5C2BF739": "Belly Buster Curry",
  "1D1AEC20": "Springdale Business Tower 1F",
  "317BE2CE": "Springdale Business Tower 7F",
  "DE49C10B": "Springdale Central Station",
  "6E1AFFED": "Shopping Street Narrows",
  "2F2BE4F4": "Tranquility Apts.",
  "957AED6D": "Tranquility Apts.",
  "034AEA1A": "Tranquility Apts.",
  "A0DF8E84": "Tranquility Apts.",
  "36EF89F3": "Tranquility Apts.",
  "8CBE806A": "Tranquility Apts.",
  "1A8E871D": "Tranquility Apts.",
  "8B93388D": "Tranquility Apts.",
  "1DA33FFA": "Tranquility Apts.",
  "7A48CEA8": "Tranquility Apts.",
  "EC78C9DF": "Tranquility Apts.",
  "5629C046": "Tranquility Apts.",
  "C019C731": "Tranquility Apts.",
  "638CA3AF": "Tranquility Apts.",
  "F5BCA4D8": "Tranquility Apts.",
  "4FEDAD41": "Tranquility Apts.",
  "6ADF9389": "Nocturne Hospital 1F",
  "46BE9D67": "Nocturne Hospital 2F",
  "731BFE8E": "Nocturne Hospital 3F",
  "5F7AF060": "Nocturne Hospital Basement",
  "CE674FF0": "Nocturne Hospital Basement Lab",
  "A194BE98": "Shopper's Row",
  "29DB16A0": "Springdale Flower Road",
  "BFEB11D7": "Settle In Bookstore",
  "938A1F39": "North Wind Ramen",
  "A62F7CD0": "Everymart Shopper's Row",
  "8A4E723E": "Sun Pavilion",
  "8D63CAD9": "Toys iZ We",
  "FEDA0ACE": "Mary's Coin Laundry",
  "D2BB0420": "Superior Style",
  "E71E67C9": "Whatta Find",
  "CB7F6927": "Sushi Springdale",
  "C18451E6": "Rugged Path (Yo-kai Watch 1)",
  "43E667D4": "Gourd Pond Museum 1F",
  "F9B76E4D": "Gourd Pond Museum 2F",
  "6F87693A": "Gourd Pond Museum Vault",
  "8470269B": "Gate Room",
  "A8112875": "Creator Zone",
  "9DB44B9C": "Can-Kicking Zone 1F",
  "27E54205": "Can-Kicking Zone 2F",
  "B1D54572": "Can-Kicking Zone 3F",
  "B6F8FD95": "Can-Kicking Zone Exit",
  "C5413D82": "Traffic-Light Zone 1F",
  "7F10341B": "Traffic-Light Zone 2F",
  "E920336C": "Traffic-Light Zone 3F",
  "4AB557F2": "Traffic-Light Zone Exit",
  "66D4591C": "Compunzer's Zone 1F",
  "F0E45E6B": "Compunzer's Zone 2F",
  "61F9E1FB": "Compunzer's Zone 3F",
  "F7C9E68C": "Compunzer's Zone Exit",
  "061210A9": "Quiz Room 1F",
  "BC431930": "Quiz Room 2F",
  "2A731E47": "Quiz Room 3F",
  "89E67AD9": "Quiz Room Exit",
  "4F3B0B8A": "Breezy Hills",
  "D32692F7": "Archer House 1F",
  "69779B6E": "Archer House 2F",
  "CAE2FFF0": "Stone House",
  "E683F11E": "Amy's House 1F",
  "E1AE49F9": "Amy's House 2F",
  "5144A4C5": "Everymart Breezy Hills",
  "7D25AA2B": "Trophy Room",
  "96D2E58A": "Wisteria Gardens Parking",
  "2C83EC13": "Wisteria Gardens Entrance",
  "2A5CB732": "Excellent Tower",
  "F337A0D5": "Unknown (Mostly empty, some textures inside are from Harrisville)",
  "6F2A39A8": "Unknown (Textures inside are from a train)",
  "59DE5D18": "Briny Grotto",
  "75BF53F6": "Hidden Workshop",
  "401A301F": "Unknown (Has a placeholder minimap, altmost empty tho)",
  "18EF4601": "Seaside Cave",
  "96501C6D": "San Fantastico",
  "0A4D8510": "Rolling Waves Meeting Hall",
  "262C8BFE": "Rusty's Mart",
  "DD4C997E": "Deserted House",
  "1E1FB455": "Sea (Boat)",
  "431EC0E8": "Unknown (Big map, Empty, Only textures)",
  "E9F73D25": "Rice Paddy Path",
  "53A634BC": "Nokotopia",
  "C59633CB": "Fullface Rock",
  "F0335022": "Mt. Middleton Summit",
  "FDA50C60": "Infinite Tunnel",
  "90F51997": "Infinite Tunnel Final Zone",
  "06C51EE0": "Infinite Tunnel Final Zone",
  "A5507A7E": "Infinite Tunnel Final Zone",
  "33607D09": "Infinite Tunnel Final Zone",
  "26797C50": "Harrisville",
  "BA64E52D": "Grandma's House",
  "9605EBC3": "Harrisville School",
  "A3A0882A": "Mountain Market",
  "07588837": "Alley off the Plaza",
  "C8D6C942": "Harrisville Station Plaza",
  "64A8B22B": "Flatpot Plains",
  "3D16F429": "Unknown (Empty, For some reason has English textures)",
  "97FF09E4": "Fox Shrine Road",
  "BB9E070A": "Well Road",
  "D6CE12FD": "Old Springdale Ironworks",
  "159D3FD6": "Sunset Manufacturing Co. Main Gate",
  "39FC3138": "Sunset Manufacturing Co. Furnace 1",
  "C46CD1EC": "Old Shoten Temple",
  "E80DDF02": "Old Timers & More",
  "DDA8BCEB": "Unknown (Placeholder Minimap)",
  "136DCD82": "Galleria Boulevard",
  "D03EE0A9": "Old Prayer's Peak Tunnel",
  "B6DEFD83": "Old Mount Wildwood",
  "E1499F0C": "Gourd Pond",
  "ED6C546E": "Unknown (Empty)",
  "4785A9A3": "Old Rice Paddy",
  "6BE4A74D": "Old Fullface Rock",
  "C871C3D3": "Old Cicada Canyon",
  "5E41C4A4": "Old Mt. Middleton Summit",
  "880BE8D6": "Old Harrisville",
  "141671AB": "Ninja Forest",
  "38777F45": "Secret Base",
  "0DD21CAC": "Old Grandma's House",
  "66A45DC4": "Old Harrisville Station Plaza",
  "FDA2145A": "Sawayama Castle Town",
  "130DA148": "Inside Sawayama Castle",
  "8F103835": "Banquet Hall",
  "766A1DF0": "Sekigahara Stronghold"
}