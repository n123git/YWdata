xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Cicala verde"
			},
			{
				"_id": "1753366683",
				"_name": "Cicala verde★"
			},
			{
				"_id": "1228371524",
				"_name": "Cicala marrone"
			},
			{
				"_id": "4052422945",
				"_name": "Cicala marrone★"
			},
			{
				"_id": "1702355358",
				"_name": "Cicala grande"
			},
			{
				"_id": "3721103099",
				"_name": "Cicala grande★"
			},
			{
				"_id": "4236161060",
				"_name": "Cicala africana"
			},
			{
				"_id": "1153619777",
				"_name": "Cicala africana★"
			},
			{
				"_id": "1043351250",
				"_name": "Cicala serale"
			},
			{
				"_id": "2257330615",
				"_name": "Cicala serale★"
			},
			{
				"_id": "2339995826",
				"_name": "Cicala asiatica"
			},
			{
				"_id": "868607959",
				"_name": "Cicala asiatica★"
			},
			{
				"_id": "1314566749",
				"_name": "Scarabeo lucanide"
			},
			{
				"_id": "4142323000",
				"_name": "Scarabeo luc.★"
			},
			{
				"_id": "858605080",
				"_name": "Dorcus"
			},
			{
				"_id": "2341544317",
				"_name": "Dorcus★"
			},
			{
				"_id": "354227473",
				"_name": "Lucanus"
			},
			{
				"_id": "2913038964",
				"_name": "Lucanus★"
			},
			{
				"_id": "3612599271",
				"_name": "Cervo volante"
			},
			{
				"_id": "1877968002",
				"_name": "Cervo volante★"
			},
			{
				"_id": "2689913713",
				"_name": "Scarabeo rino."
			},
			{
				"_id": "417903636",
				"_name": "Scarabeo rino.★"
			},
			{
				"_id": "2350138539",
				"_name": "Falena bianca"
			},
			{
				"_id": "883434446",
				"_name": "Falena bianca★"
			},
			{
				"_id": "3374651071",
				"_name": "Coda di rondine"
			},
			{
				"_id": "1905881562",
				"_name": "Coda di rondine★"
			},
			{
				"_id": "2063668422",
				"_name": "Occhio di pavone"
			},
			{
				"_id": "3283973027",
				"_name": "Occhio di pavone★"
			},
			{
				"_id": "541504394",
				"_name": "Farfalla viola"
			},
			{
				"_id": "2566575343",
				"_name": "Farfalla viola★"
			},
			{
				"_id": "3662603053",
				"_name": "Libellula lydia"
			},
			{
				"_id": "1660060744",
				"_name": "Libellula lydia★"
			},
			{
				"_id": "2907296699",
				"_name": "Libellula reale"
			},
			{
				"_id": "368424158",
				"_name": "Libellula reale★"
			},
			{
				"_id": "2969153051",
				"_name": "Libellula grande"
			},
			{
				"_id": "138791294",
				"_name": "Libellula grande★"
			},
			{
				"_id": "3189909033",
				"_name": "Lucciola"
			},
			{
				"_id": "111034700",
				"_name": "Lucciola★"
			},
			{
				"_id": "3109020208",
				"_name": "Coccinella"
			},
			{
				"_id": "32736597",
				"_name": "Coccinella★"
			},
			{
				"_id": "962429643",
				"_name": "Cavalletta"
			},
			{
				"_id": "2179065262",
				"_name": "Cavalletta★"
			},
			{
				"_id": "1463911196",
				"_name": "Grillo del riso"
			},
			{
				"_id": "4026393721",
				"_name": "Grillo del riso★"
			},
			{
				"_id": "3739594700",
				"_name": "Locusta"
			},
			{
				"_id": "1717160105",
				"_name": "Locusta★"
			},
			{
				"_id": "2455941619",
				"_name": "Grillo"
			},
			{
				"_id": "719246998",
				"_name": "Grillo★"
			},
			{
				"_id": "2087506143",
				"_name": "Suzumushi"
			},
			{
				"_id": "3302012858",
				"_name": "Suzumushi★"
			},
			{
				"_id": "201729104",
				"_name": "Cavalletta verde"
			},
			{
				"_id": "3032105781",
				"_name": "Cavalletta verde★"
			},
			{
				"_id": "1563510735",
				"_name": "Mantide asiatica"
			},
			{
				"_id": "3851231402",
				"_name": "Mantide asiatica★"
			},
			{
				"_id": "2850201434",
				"_name": "Mantide gigante"
			},
			{
				"_id": "291436607",
				"_name": "Mantide gigante★"
			},
			{
				"_id": "1345079045",
				"_name": "Longicorno"
			},
			{
				"_id": "3901759584",
				"_name": "Longicorno★"
			},
			{
				"_id": "3448658526",
				"_name": "Insetto stecco"
			},
			{
				"_id": "1966226747",
				"_name": "Insetto stecco★"
			},
			{
				"_id": "3710068532",
				"_name": "Grillotalpide"
			},
			{
				"_id": "1704935505",
				"_name": "Grillotalpide★"
			},
			{
				"_id": "2614427096",
				"_name": "Oniscidea"
			},
			{
				"_id": "594057917",
				"_name": "Oniscidea★"
			},
			{
				"_id": "657160083",
				"_name": "Scarabeo fiore"
			},
			{
				"_id": "2677477622",
				"_name": "Scarabeo fiore★"
			},
			{
				"_id": "3848634725",
				"_name": "Scarabeo"
			},
			{
				"_id": "1574561280",
				"_name": "Scarabeo★"
			},
			{
				"_id": "2500818410",
				"_name": "Scarabeo verde"
			},
			{
				"_id": "766710415",
				"_name": "Scarabeo verde★"
			},
			{
				"_id": "3792192892",
				"_name": "Stercorario"
			},
			{
				"_id": "1521754649",
				"_name": "Stercorario★"
			},
			{
				"_id": "4123589647",
				"_name": "Ditisco"
			},
			{
				"_id": "1299487594",
				"_name": "Ditisco★"
			},
			{
				"_id": "3025330938",
				"_name": "Belostomatide"
			},
			{
				"_id": "216958367",
				"_name": "Belostomatide★"
			},
			{
				"_id": "191619145",
				"_name": "Coleottero"
			},
			{
				"_id": "3017246508",
				"_name": "Coleottero★"
			},
			{
				"_id": "3973303630",
				"_name": "Lucertola bruna"
			},
			{
				"_id": "1416604203",
				"_name": "Lucertola bruna★"
			},
			{
				"_id": "2854492066",
				"_name": "Lucertola"
			},
			{
				"_id": "311980231",
				"_name": "Lucertola★"
			},
			{
				"_id": "2194656409",
				"_name": "Geco fiammato"
			},
			{
				"_id": "980659196",
				"_name": "Geco fiammato★"
			},
			{
				"_id": "1516012502",
				"_name": "Notostraca"
			},
			{
				"_id": "3806389427",
				"_name": "Notostraca★"
			},
			{
				"_id": "708212569",
				"_name": "Lumaca di stagno"
			},
			{
				"_id": "2458521660",
				"_name": "Lumaca di stagno★"
			},
			{
				"_id": "1143633550",
				"_name": "Ampullaria dorata"
			},
			{
				"_id": "4237693419",
				"_name": "Ampullaria dorata★"
			},
			{
				"_id": "3355352717",
				"_name": "Lumaca"
			},
			{
				"_id": "2135095784",
				"_name": "Lumaca★"
			},
			{
				"_id": "3460879014",
				"_name": "Raganella"
			},
			{
				"_id": "1995748803",
				"_name": "Raganella★"
			},
			{
				"_id": "4212356157",
				"_name": "Rospo"
			},
			{
				"_id": "1135547224",
				"_name": "Rospo★"
			},
			{
				"_id": "3522973129",
				"_name": "Tartaruga"
			},
			{
				"_id": "1765812908",
				"_name": "Tartaruga★"
			},
			{
				"_id": "3325883578",
				"_name": "Trionichide"
			},
			{
				"_id": "2122355679",
				"_name": "Trionichide★"
			},
			{
				"_id": "230968935",
				"_name": "Granchio di fiume"
			},
			{
				"_id": "3044550914",
				"_name": "Granchio di fiume★"
			},
			{
				"_id": "2496471005",
				"_name": "Gambero di fiume"
			},
			{
				"_id": "745633976",
				"_name": "Gambero di fiume★"
			},
			{
				"_id": "2108603112",
				"_name": "Aragosta"
			},
			{
				"_id": "3306347917",
				"_name": "Aragosta★"
			},
			{
				"_id": "3321527362",
				"_name": "Gamberetto"
			},
			{
				"_id": "2101746471",
				"_name": "Gamberetto★"
			},
			{
				"_id": "3002944724",
				"_name": "Stella marina"
			},
			{
				"_id": "172043185",
				"_name": "Stella marina★"
			},
			{
				"_id": "350191398",
				"_name": "Ippocampo"
			},
			{
				"_id": "2892175427",
				"_name": "Ippocampo★"
			},
			{
				"_id": "2711009606",
				"_name": "Carpa"
			},
			{
				"_id": "422239779",
				"_name": "Carpa★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "1848503989",
				"_name": "Ayu★"
			},
			{
				"_id": "748280183",
				"_name": "Cefalo"
			},
			{
				"_id": "2485501458",
				"_name": "Cefalo★"
			},
			{
				"_id": "2476792772",
				"_name": "Salmone rosso"
			},
			{
				"_id": "723303585",
				"_name": "Salmone rosso★"
			},
			{
				"_id": "2973484076",
				"_name": "Carpa koi"
			},
			{
				"_id": "159884105",
				"_name": "Carpa koi★"
			},
			{
				"_id": "1224023155",
				"_name": "Boccalone"
			},
			{
				"_id": "4031347478",
				"_name": "Boccalone★"
			},
			{
				"_id": "2059632369",
				"_name": "Salmone"
			},
			{
				"_id": "3263109524",
				"_name": "Salmone★"
			},
			{
				"_id": "1072835813",
				"_name": "Hucho h. gigante"
			},
			{
				"_id": "2270055296",
				"_name": "Hucho h. gig.★"
			},
			{
				"_id": "178883198",
				"_name": "Sardina"
			},
			{
				"_id": "2987781403",
				"_name": "Sardina★"
			},
			{
				"_id": "950003964",
				"_name": "Sgombro"
			},
			{
				"_id": "2149814169",
				"_name": "Sgombro★"
			},
			{
				"_id": "4208008714",
				"_name": "Lanzardo"
			},
			{
				"_id": "1114470767",
				"_name": "Lanzardo★"
			},
			{
				"_id": "2379624092",
				"_name": "Attinopterigio"
			},
			{
				"_id": "896158201",
				"_name": "Attinopterigio★"
			},
			{
				"_id": "3683420442",
				"_name": "Barracuda"
			},
			{
				"_id": "1664151167",
				"_name": "Barracuda★"
			},
			{
				"_id": "2327571077",
				"_name": "Pesce rondine"
			},
			{
				"_id": "839355872",
				"_name": "Pesce rondine★"
			},
			{
				"_id": "1335416938",
				"_name": "Testa di serpente"
			},
			{
				"_id": "4146380559",
				"_name": "Testa di serpente★"
			},
			{
				"_id": "3481974929",
				"_name": "Scorfano di fondale"
			},
			{
				"_id": "2000084980",
				"_name": "Scorf. di fonda.★"
			},
			{
				"_id": "1537141217",
				"_name": "Boccaporporina"
			},
			{
				"_id": "3810692740",
				"_name": "Boccaporporina★"
			},
			{
				"_id": "1559440888",
				"_name": "Spigola"
			},
			{
				"_id": "3830401693",
				"_name": "Spigola★"
			},
			{
				"_id": "2884009365",
				"_name": "Pesce nero"
			},
			{
				"_id": "324672240",
				"_name": "Pesce nero★"
			},
			{
				"_id": "3977357177",
				"_name": "Monacantide"
			},
			{
				"_id": "1437450268",
				"_name": "Monacantide★"
			},
			{
				"_id": "1689619369",
				"_name": "Halibut"
			},
			{
				"_id": "3691637964",
				"_name": "Halibut★"
			},
			{
				"_id": "3264723035",
				"_name": "Platessa"
			},
			{
				"_id": "2049695550",
				"_name": "Platessa★"
			},
			{
				"_id": "2820732269",
				"_name": "Snapper rosso"
			},
			{
				"_id": "278696456",
				"_name": "Snapper rosso★"
			},
			{
				"_id": "1451485483",
				"_name": "Ishidai"
			},
			{
				"_id": "3997142606",
				"_name": "Ishidai★"
			},
			{
				"_id": "3705752835",
				"_name": "Dentice"
			},
			{
				"_id": "1683827302",
				"_name": "Dentice★"
			},
			{
				"_id": "330480447",
				"_name": "Ricciola"
			},
			{
				"_id": "2869877850",
				"_name": "Ricciola★"
			},
			{
				"_id": "4257012243",
				"_name": "Pesce istrice"
			},
			{
				"_id": "1157676406",
				"_name": "Pesce istrice★"
			},
			{
				"_id": "562354621",
				"_name": "Cobite di stagno"
			},
			{
				"_id": "2570632920",
				"_name": "Cobite di stagno★"
			},
			{
				"_id": "737418606",
				"_name": "Pesce coltello"
			},
			{
				"_id": "2471000587",
				"_name": "Pesce coltello★"
			},
			{
				"_id": "3836210002",
				"_name": "Conger"
			},
			{
				"_id": "1545309239",
				"_name": "Conger★"
			},
			{
				"_id": "3821678411",
				"_name": "Anguilla"
			},
			{
				"_id": "1534478382",
				"_name": "Anguilla★"
			},
			{
				"_id": "3096283143",
				"_name": "Pesce gatto"
			},
			{
				"_id": "3272546",
				"_name": "Pesce gatto★"
			},
			{
				"_id": "3370613896",
				"_name": "Medusa"
			},
			{
				"_id": "1885019117",
				"_name": "Medusa★"
			},
			{
				"_id": "1675120560",
				"_name": "Polpo"
			},
			{
				"_id": "3680774357",
				"_name": "Polpo★"
			},
			{
				"_id": "2894838156",
				"_name": "Calamaro corallino"
			},
			{
				"_id": "339205865",
				"_name": "Calamaro corallino★"
			},
			{
				"_id": "4094334520",
				"_name": "Seppia"
			},
			{
				"_id": "1287057757",
				"_name": "Seppia★"
			},
			{
				"_id": "1374563634",
				"_name": "Calamaro lucciola"
			},
			{
				"_id": "3914484311",
				"_name": "Calamaro lucciola★"
			},
			{
				"_id": "3046148301",
				"_name": "Calamaro"
			},
			{
				"_id": "221048744",
				"_name": "Calamaro★"
			},
			{
				"_id": "897771574",
				"_name": "Totano"
			},
			{
				"_id": "2369687379",
				"_name": "Totano★"
			},
			{
				"_id": "1116068000",
				"_name": "Rana pescatrice"
			},
			{
				"_id": "4198088645",
				"_name": "Rana pescatrice★"
			},
			{
				"_id": "2585171951",
				"_name": "Pastinaca"
			},
			{
				"_id": "581628042",
				"_name": "Pastinaca★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "123480955",
				"_name": "Marlin★"
			},
			{
				"_id": "2198709934",
				"_name": "Tonno"
			},
			{
				"_id": "1001505227",
				"_name": "Tonno★"
			}
		]
	}
}
