xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Bracc. consum."
			},
			{
				"_id": "3681894277",
				"_name": "Bracciale modesto"
			},
			{
				"_id": "3692624796",
				"_name": "Bracciale chiodato"
			},
			{
				"_id": "2893156115",
				"_name": "Bracciale del potere"
			},
			{
				"_id": "2870987530",
				"_name": "Bracciale brutale"
			},
			{
				"_id": "1020072578",
				"_name": "Bracciale sublime"
			},
			{
				"_id": "897277609",
				"_name": "Braccialetto solare"
			},
			{
				"_id": "1271538196",
				"_name": "Bracciale cometa"
			},
			{
				"_id": "1115450943",
				"_name": "Bracciale malvagio"
			},
			{
				"_id": "722316273",
				"_name": "Bracciale epico"
			},
			{
				"_id": "1154727953",
				"_name": "Anello arrugginito"
			},
			{
				"_id": "3669448114",
				"_name": "Anello brutto"
			},
			{
				"_id": "3722088875",
				"_name": "Anello grazioso"
			},
			{
				"_id": "2914018596",
				"_name": "Anello arcobaleno"
			},
			{
				"_id": "2866651453",
				"_name": "Anello illusorio"
			},
			{
				"_id": "1024424117",
				"_name": "Anello fatato"
			},
			{
				"_id": "884552862",
				"_name": "Anello lunare"
			},
			{
				"_id": "1242056739",
				"_name": "Anello del destino"
			},
			{
				"_id": "1136526344",
				"_name": "Anello malvagio"
			},
			{
				"_id": "718258630",
				"_name": "Anello leggendario"
			},
			{
				"_id": "1184202312",
				"_name": "Amuleto antico"
			},
			{
				"_id": "3639733227",
				"_name": "Amuleto vecchio"
			},
			{
				"_id": "3751555058",
				"_name": "Amuleto runico"
			},
			{
				"_id": "2952190845",
				"_name": "Amuleto protettivo"
			},
			{
				"_id": "2828738404",
				"_name": "Amuleto corazzato"
			},
			{
				"_id": "1061799660",
				"_name": "Amuleto fortuna"
			},
			{
				"_id": "922716871",
				"_name": "Amuleto galattico"
			},
			{
				"_id": "1213134458",
				"_name": "Amuleto della terra"
			},
			{
				"_id": "1106819665",
				"_name": "Amuleto malvagio"
			},
			{
				"_id": "680099743",
				"_name": "Amuleto epico"
			},
			{
				"_id": "1196889215",
				"_name": "Stemma semplice"
			},
			{
				"_id": "3644031452",
				"_name": "Stemma nero"
			},
			{
				"_id": "3730720197",
				"_name": "Stemma brillante"
			},
			{
				"_id": "2922688842",
				"_name": "Stemma carino"
			},
			{
				"_id": "2841212243",
				"_name": "Stemma di Ermete"
			},
			{
				"_id": "1049341147",
				"_name": "Stemma dell'aurora"
			},
			{
				"_id": "926802160",
				"_name": "Stemma meteora"
			},
			{
				"_id": "1233951821",
				"_name": "Stemma del fulmine"
			},
			{
				"_id": "1077596262",
				"_name": "Stemma malvagio"
			},
			{
				"_id": "692786600",
				"_name": "Stemma epico"
			},
			{
				"_id": "1108869882",
				"_name": "Spada cicala"
			},
			{
				"_id": "3675345728",
				"_name": "Campana robusta"
			},
			{
				"_id": "2887148502",
				"_name": "Campana magica"
			},
			{
				"_id": "846394997",
				"_name": "Campana spessa"
			},
			{
				"_id": "1165346531",
				"_name": "Campana veloce"
			},
			{
				"_id": "3699152729",
				"_name": "Bottiglia infinita"
			},
			{
				"_id": "2877007823",
				"_name": "Ventaglio tengu"
			},
			{
				"_id": "1002748510",
				"_name": "Giacca allegra"
			},
			{
				"_id": "1287883464",
				"_name": "Mazza chiodata"
			},
			{
				"_id": "1550776226",
				"_name": "Bacchette"
			},
			{
				"_id": "3311904280",
				"_name": "Robovitamina E"
			},
			{
				"_id": "2992674446",
				"_name": "Polsiera di Kuadro"
			},
			{
				"_id": "585075487",
				"_name": "Campanella ricordo"
			},
			{
				"_id": "3037549207",
				"_name": "Fascia dello spirito"
			},
			{
				"_id": "728352564",
				"_name": "Fascia dell'anima"
			},
			{
				"_id": "738460461",
				"_name": "Invertispada"
			},
			{
				"_id": "1526936507",
				"_name": "Invertigemme"
			},
			{
				"_id": "3255460353",
				"_name": "Riflettore"
			},
			{
				"_id": "1440267145",
				"_name": "Sfera paradisiaca"
			},
			{
				"_id": "1138387149",
				"_name": "Appunto sinistro"
			},
			{
				"_id": "3671275895",
				"_name": "Spada maledetta"
			},
			{
				"_id": "2916354529",
				"_name": "Bastone maledetto"
			},
			{
				"_id": "867212354",
				"_name": "Scudo maledetto"
			},
			{
				"_id": "1152888020",
				"_name": "Tunica maledetta"
			},
			{
				"_id": "1100797588",
				"_name": "Cintura della calma"
			},
			{
				"_id": "2945628088",
				"_name": "Cerchio scimm."
			},
			{
				"_id": "4256025923",
				"_name": "Medaglia generale"
			},
			{
				"_id": "1688509689",
				"_name": "Medaglia tenente"
			},
			{
				"_id": "329493615",
				"_name": "Medaglia gen. mag."
			},
			{
				"_id": "2378643916",
				"_name": "Medaglia colonn."
			},
			{
				"_id": "4206889306",
				"_name": "Medaglia maggiore"
			},
			{
				"_id": "1674139872",
				"_name": "Medaglia capitano"
			},
			{
				"_id": "349071478",
				"_name": "Medaglia comand."
			},
			{
				"_id": "2222028263",
				"_name": "Medaglia luogoten."
			}
		]
	}
}
