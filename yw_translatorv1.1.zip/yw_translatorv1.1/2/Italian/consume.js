xmlval = {
	"items": {
		"item": [
			{
				"_id": "2170728737",
				"_name": "Barr. cioccolato"
			},
			{
				"_id": "1803927674",
				"_name": "Onigiri con prugna"
			},
			{
				"_id": "4069298624",
				"_name": "Onigiri in foglia"
			},
			{
				"_id": "2240520534",
				"_name": "Onigiri con uova"
			},
			{
				"_id": "468661493",
				"_name": "Onigiri con gamberi"
			},
			{
				"_id": "1783081549",
				"_name": "Tramezzino"
			},
			{
				"_id": "4082039799",
				"_name": "Pane farcito"
			},
			{
				"_id": "1831497300",
				"_name": "Pane al curry"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Ciambellingua"
			},
			{
				"_id": "1744901140",
				"_name": "Gomma 10 cent."
			},
			{
				"_id": "4043851182",
				"_name": "Dolcetto molle"
			},
			{
				"_id": "2249159992",
				"_name": "Cracker gigante"
			},
			{
				"_id": "409723035",
				"_name": "Caramelle alla frutta"
			},
			{
				"_id": "1869402125",
				"_name": "Granita"
			},
			{
				"_id": "4133847479",
				"_name": "Mela candita"
			},
			{
				"_id": "1774419491",
				"_name": "Latte"
			},
			{
				"_id": "4039782297",
				"_name": "Caffellatte"
			},
			{
				"_id": "2278366991",
				"_name": "Latte alla frutta"
			},
			{
				"_id": "430541484",
				"_name": "Lattissimo"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Tè dell'anima"
			},
			{
				"_id": "2189560202",
				"_name": "Spiriterade Y"
			},
			{
				"_id": "484875305",
				"_name": "VoltExtremo"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Doppio hamburger"
			},
			{
				"_id": "488961566",
				"_name": "Gnam Burger"
			},
			{
				"_id": "1858787071",
				"_name": "Ramen pronto"
			},
			{
				"_id": "4156786501",
				"_name": "Ramen di maiale"
			},
			{
				"_id": "2160375763",
				"_name": "Ramen deluxe"
			},
			{
				"_id": "513811056",
				"_name": "Ramen totale"
			},
			{
				"_id": "1704366530",
				"_name": "Rotolino al cetriolo"
			},
			{
				"_id": "4238327928",
				"_name": "Sushi con gamberi"
			},
			{
				"_id": "2342056174",
				"_name": "Sushi al salmone"
			},
			{
				"_id": "368862541",
				"_name": "Sushi al tonno"
			},
			{
				"_id": "1683291125",
				"_name": "Ravioli al vapore"
			},
			{
				"_id": "4250774095",
				"_name": "Fegato alla piastra"
			},
			{
				"_id": "2321193689",
				"_name": "Omelette granc."
			},
			{
				"_id": "339611514",
				"_name": "Gamberetti piccanti"
			},
			{
				"_id": "1664696300",
				"_name": "Mabo tofu"
			},
			{
				"_id": "3539717416",
				"_name": "Carota"
			},
			{
				"_id": "1274190994",
				"_name": "Cetriolo"
			},
			{
				"_id": "1022733316",
				"_name": "Germ. di bambù"
			},
			{
				"_id": "2727426471",
				"_name": "Fungo"
			},
			{
				"_id": "3502076785",
				"_name": "Coscia di pollo"
			},
			{
				"_id": "1236542155",
				"_name": "Pezzo di pancetta"
			},
			{
				"_id": "1051923037",
				"_name": "Lingua di manzo"
			},
			{
				"_id": "2698479614",
				"_name": "Manzo prelibato"
			},
			{
				"_id": "3514767686",
				"_name": "Sgombro essiccato"
			},
			{
				"_id": "1215711484",
				"_name": "Tonno pinna gialla"
			},
			{
				"_id": "1064401002",
				"_name": "Riccio mare fres."
			},
			{
				"_id": "2702568905",
				"_name": "Tonno scelto"
			},
			{
				"_id": "3559919555",
				"_name": "Curry di pollo"
			},
			{
				"_id": "1295605369",
				"_name": "Curry di agnello"
			},
			{
				"_id": "977170159",
				"_name": "Curry di mare"
			},
			{
				"_id": "2757425996",
				"_name": "Curry abbondante"
			},
			{
				"_id": "3546139610",
				"_name": "Curry vegetariano"
			},
			{
				"_id": "3589432820",
				"_name": "Cheesecake"
			},
			{
				"_id": "1291531342",
				"_name": "Torta alla crema"
			},
			{
				"_id": "1006372056",
				"_name": "Pancake reali"
			},
			{
				"_id": "2778239355",
				"_name": "Coppa di gelato"
			},
			{
				"_id": "3533677037",
				"_name": "Tortino di riso"
			},
			{
				"_id": "1268183127",
				"_name": "Brioche dello spirito"
			},
			{
				"_id": "1016185025",
				"_name": "Brioche dell'anima"
			},
			{
				"_id": "3618954157",
				"_name": "Daikon al vapore"
			},
			{
				"_id": "1321044503",
				"_name": "Uovo sodo"
			},
			{
				"_id": "968538753",
				"_name": "Spiedini di manzo"
			},
			{
				"_id": "2816356130",
				"_name": "Oden d'alta classe"
			},
			{
				"_id": "3598102938",
				"_name": "Spaghetti soba"
			},
			{
				"_id": "3710580391",
				"_name": "Patatine"
			},
			{
				"_id": "1143187229",
				"_name": "Snack goloso"
			},
			{
				"_id": "858036107",
				"_name": "Patate al formaggio"
			},
			{
				"_id": "2906653224",
				"_name": "Snack di taccole"
			},
			{
				"_id": "2370076515",
				"_name": "ESPhera mini"
			},
			{
				"_id": "320924352",
				"_name": "ESPhera piccola"
			},
			{
				"_id": "2317990778",
				"_name": "ESPhera media"
			},
			{
				"_id": "4247686124",
				"_name": "ESPhera grande"
			},
			{
				"_id": "1665801807",
				"_name": "ESPhera mega"
			},
			{
				"_id": "340602585",
				"_name": "ESPhera sacra"
			},
			{
				"_id": "397252210",
				"_name": "Vigorium"
			},
			{
				"_id": "2393163720",
				"_name": "Vigorium alfa"
			},
			{
				"_id": "279199406",
				"_name": "Colpi nascosti"
			},
			{
				"_id": "2309844756",
				"_name": "Le tecniche migliori"
			},
			{
				"_id": "4272578434",
				"_name": "I segreti dell'anima"
			},
			{
				"_id": "469268883",
				"_name": "Una vita seria"
			},
			{
				"_id": "2196842537",
				"_name": "A tutto karate"
			},
			{
				"_id": "4126546111",
				"_name": "Usa il karate"
			},
			{
				"_id": "1804766492",
				"_name": "Tecnidario"
			},
			{
				"_id": "479575434",
				"_name": "Tecnipedia"
			},
			{
				"_id": "2241653808",
				"_name": "In guardia"
			},
			{
				"_id": "4070300838",
				"_name": "In guardia con stile"
			},
			{
				"_id": "1646575927",
				"_name": "Angelino ti cura"
			},
			{
				"_id": "354677153",
				"_name": "Ciao, Angelino"
			},
			{
				"_id": "1977907268",
				"_name": "Peste in missione"
			},
			{
				"_id": "48449746",
				"_name": "La peste perfetta"
			},
			{
				"_id": "2615810408",
				"_name": "Collabora n.7"
			},
			{
				"_id": "3974965758",
				"_name": "Collabora ed. sp."
			},
			{
				"_id": "367732779",
				"_name": "Talismano forza"
			},
			{
				"_id": "2363652497",
				"_name": "Talismano spirito"
			},
			{
				"_id": "4226107655",
				"_name": "Talismano difesa"
			},
			{
				"_id": "1703009444",
				"_name": "Talismano velocità"
			},
			{
				"_id": "338248220",
				"_name": "Medicina disgus."
			},
			{
				"_id": "2367689638",
				"_name": "Medicina amara"
			},
			{
				"_id": "4196868912",
				"_name": "Medicina potente"
			},
			{
				"_id": "376437829",
				"_name": "Bambola di fuga"
			},
			{
				"_id": "1628217366",
				"_name": "Bambola di ferro"
			},
			{
				"_id": "291919001",
				"_name": "Bambola di bronzo"
			},
			{
				"_id": "2288977187",
				"_name": "Bambola d'argento"
			},
			{
				"_id": "4285019573",
				"_name": "Bambola d'oro"
			},
			{
				"_id": "369856640",
				"_name": "Bambola di platino"
			},
			{
				"_id": "2908180302",
				"_name": "Esca da pesca"
			},
			{
				"_id": "878583540",
				"_name": "Sciroppo nero"
			},
			{
				"_id": "2895455609",
				"_name": "Stella danzante"
			},
			{
				"_id": "899445955",
				"_name": "Biglietto lotteria"
			},
			{
				"_id": "1117471829",
				"_name": "Biglietto musicale"
			},
			{
				"_id": "1535145236",
				"_name": "Etichetta di bronzo"
			},
			{
				"_id": "3320111287",
				"_name": "Etichetta d'argento"
			},
			{
				"_id": "3001274401",
				"_name": "Etichetta d'oro"
			},
			{
				"_id": "747062658",
				"_name": "Essenza del male"
			},
			{
				"_id": "440013732",
				"_name": "Lama leggendaria"
			},
			{
				"_id": "2201174558",
				"_name": "Lama maledetta"
			},
			{
				"_id": "2220787207",
				"_name": "Lama sacra"
			},
			{
				"_id": "4097077896",
				"_name": "Anima del generale"
			},
			{
				"_id": "1783686955",
				"_name": "Spaccamore"
			},
			{
				"_id": "492296125",
				"_name": "Sfera elettrica"
			},
			{
				"_id": "1676061440",
				"_name": "Anima imbattibile"
			},
			{
				"_id": "2586342239",
				"_name": "Lingotto di platino"
			},
			{
				"_id": "350329750",
				"_name": "Mantello bufera"
			},
			{
				"_id": "1948652147",
				"_name": "Scettro dell'amore"
			},
			{
				"_id": "4082742929",
				"_name": "Forcina glaciale"
			},
			{
				"_id": "52503269",
				"_name": "Bilanciere"
			},
			{
				"_id": "1934349930",
				"_name": "Frammento di male"
			},
			{
				"_id": "3979297737",
				"_name": "Polvere eterna"
			},
			{
				"_id": "2638591814",
				"_name": "Sfera del drago"
			},
			{
				"_id": "1098757352",
				"_name": "Lama furente"
			},
			{
				"_id": "913998974",
				"_name": "Completo sabbia"
			},
			{
				"_id": "2943604164",
				"_name": "Acqua eterea"
			},
			{
				"_id": "3631539538",
				"_name": "Rivista maledetta"
			},
			{
				"_id": "1221327043",
				"_name": "Clacson"
			},
			{
				"_id": "1070385237",
				"_name": "Aspira-ricordi"
			},
			{
				"_id": "156362294",
				"_name": "Perla della sirena"
			},
			{
				"_id": "1771466707",
				"_name": "Onigiri dell'amore"
			},
			{
				"_id": "2119620256",
				"_name": "Campanella rotta"
			},
			{
				"_id": "2033914553",
				"_name": "Lama consunta"
			},
			{
				"_id": "3761390339",
				"_name": "Cote grezza"
			},
			{
				"_id": "2536862613",
				"_name": "Cote inquietante"
			},
			{
				"_id": "126512644",
				"_name": "Cote sublime"
			},
			{
				"_id": "273340279",
				"_name": "Scultura d'orso"
			},
			{
				"_id": "1733158881",
				"_name": "Lanterna pesce"
			},
			{
				"_id": "4265915995",
				"_name": "Lume artigianale"
			},
			{
				"_id": "2302904013",
				"_name": "Emblema d'oro"
			},
			{
				"_id": "388436846",
				"_name": "Teglia in ghisa"
			},
			{
				"_id": "1612719096",
				"_name": "Sabbia delle dune"
			},
			{
				"_id": "4180243010",
				"_name": "Cappello vintage"
			},
			{
				"_id": "2385396436",
				"_name": "Statua di terracotta"
			},
			{
				"_id": "512843589",
				"_name": "Ibisco rosso"
			},
			{
				"_id": "3881797402",
				"_name": "Erba curativa"
			},
			{
				"_id": "2421733260",
				"_name": "Erba fetida"
			},
			{
				"_id": "238821935",
				"_name": "Erba amara"
			},
			{
				"_id": "2592718716",
				"_name": "Moneta rossa"
			},
			{
				"_id": "58781382",
				"_name": "Moneta gialla"
			},
			{
				"_id": "1955061328",
				"_name": "Moneta aranc."
			},
			{
				"_id": "3940764659",
				"_name": "Moneta rosa"
			},
			{
				"_id": "2648996709",
				"_name": "Moneta verde"
			},
			{
				"_id": "82651871",
				"_name": "Moneta blu"
			},
			{
				"_id": "1944721993",
				"_name": "Moneta viola"
			},
			{
				"_id": "3814000600",
				"_name": "Moneta azzurra"
			},
			{
				"_id": "3411442988",
				"_name": "Mon. cinque stelle"
			},
			{
				"_id": "1542021309",
				"_name": "Moneta speciale"
			},
			{
				"_id": "753815595",
				"_name": "Moneta Yo"
			},
			{
				"_id": "1277811150",
				"_name": "Moneta Kai"
			},
			{
				"_id": "992930136",
				"_name": "Moneta Evo"
			},
			{
				"_id": "2720512226",
				"_name": "Moneta Ca"
			},
			{
				"_id": "905273706",
				"_name": "Moneta fiore"
			},
			{
				"_id": "1728350733",
				"_name": "Moneta uccello"
			},
			{
				"_id": "268679835",
				"_name": "Moneta vento"
			},
			{
				"_id": "2299194145",
				"_name": "Moneta luna"
			},
			{
				"_id": "4262321079",
				"_name": "Moneta scintillante"
			},
			{
				"_id": "1617514004",
				"_name": "Moneta nord"
			},
			{
				"_id": "393117314",
				"_name": "Moneta nord-est"
			},
			{
				"_id": "2389126968",
				"_name": "Moneta est"
			},
			{
				"_id": "4183826350",
				"_name": "Moneta centro"
			},
			{
				"_id": "1776222783",
				"_name": "Moneta ovest"
			},
			{
				"_id": "517485225",
				"_name": "Moneta montagna"
			},
			{
				"_id": "2116008780",
				"_name": "Moneta sud"
			},
			{
				"_id": "152603610",
				"_name": "Moneta centro-ov."
			},
			{
				"_id": "2417089120",
				"_name": "Moneta isola"
			},
			{
				"_id": "3877038838",
				"_name": "Moneta misteriosa"
			},
			{
				"_id": "2037546837",
				"_name": "Moneta cinghiale"
			},
			{
				"_id": "242569155",
				"_name": "Moneta cervo"
			},
			{
				"_id": "2541493881",
				"_name": "Moneta farfalla"
			},
			{
				"_id": "3766169327",
				"_name": "Moneta felice"
			},
			{
				"_id": "3707752950",
				"_name": "Frammento rosso"
			},
			{
				"_id": "2885214560",
				"_name": "Frammento giallo"
			},
			{
				"_id": "854700250",
				"_name": "Frammento arancio"
			},
			{
				"_id": "1173782604",
				"_name": "Frammento rosa"
			},
			{
				"_id": "3578371549",
				"_name": "Frammento verde"
			},
			{
				"_id": "2723065163",
				"_name": "Frammento blu"
			},
			{
				"_id": "3263767726",
				"_name": "Frammento viola"
			},
			{
				"_id": "3045987384",
				"_name": "Frammento azzurro"
			},
			{
				"_id": "1200047969",
				"_name": "Cofanetto rosso"
			},
			{
				"_id": "1178938710",
				"_name": "Sfera del portale"
			},
			{
				"_id": "2285637778",
				"_name": "Sfera di Noko"
			},
			{
				"_id": "288702760",
				"_name": "Sfera di Kyubi"
			}
		]
	}
}
