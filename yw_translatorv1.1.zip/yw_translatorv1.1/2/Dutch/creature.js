xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Groene cicade"
			},
			{
				"_id": "1753366683",
				"_name": "Groene cicade★"
			},
			{
				"_id": "1228371524",
				"_name": "Bruine cicade"
			},
			{
				"_id": "4052422945",
				"_name": "Bruine cicade★"
			},
			{
				"_id": "1702355358",
				"_name": "Reuzencicade"
			},
			{
				"_id": "3721103099",
				"_name": "Reuzencicade★"
			},
			{
				"_id": "4236161060",
				"_name": "Woestijncicade"
			},
			{
				"_id": "1153619777",
				"_name": "Woestijncicade★"
			},
			{
				"_id": "1043351250",
				"_name": "Avondcicade"
			},
			{
				"_id": "2257330615",
				"_name": "Avondcicade★"
			},
			{
				"_id": "2339995826",
				"_name": "Aziatische cicade"
			},
			{
				"_id": "868607959",
				"_name": "Aziatische cicade★"
			},
			{
				"_id": "1314566749",
				"_name": "Zaagtandkever"
			},
			{
				"_id": "4142323000",
				"_name": "Zaagtandkever★"
			},
			{
				"_id": "858605080",
				"_name": "Vliegend hert"
			},
			{
				"_id": "2341544317",
				"_name": "Vliegend hert★"
			},
			{
				"_id": "354227473",
				"_name": "Miyamakever"
			},
			{
				"_id": "2913038964",
				"_name": "Miyamakever★"
			},
			{
				"_id": "3612599271",
				"_name": "Hertkever"
			},
			{
				"_id": "1877968002",
				"_name": "Hertkever★"
			},
			{
				"_id": "2689913713",
				"_name": "Neushoornkever"
			},
			{
				"_id": "417903636",
				"_name": "Neushoornkever★"
			},
			{
				"_id": "2350138539",
				"_name": "Koolwitje"
			},
			{
				"_id": "883434446",
				"_name": "Koolwitje★"
			},
			{
				"_id": "3374651071",
				"_name": "Bonte zwaluwstaart"
			},
			{
				"_id": "1905881562",
				"_name": "Bonte zwaluwstaart★"
			},
			{
				"_id": "2063668422",
				"_name": "Zwaluwstaart"
			},
			{
				"_id": "3283973027",
				"_name": "Zwaluwstaart★"
			},
			{
				"_id": "541504394",
				"_name": "Paarse vlinder"
			},
			{
				"_id": "2566575343",
				"_name": "Paarse vlinder★"
			},
			{
				"_id": "3662603053",
				"_name": "Witpuntoeverlibel"
			},
			{
				"_id": "1660060744",
				"_name": "Witpuntoeverlibel★"
			},
			{
				"_id": "2907296699",
				"_name": "Keizerlibel"
			},
			{
				"_id": "368424158",
				"_name": "Keizerlibel★"
			},
			{
				"_id": "2969153051",
				"_name": "Reuzelibel"
			},
			{
				"_id": "138791294",
				"_name": "Reuzelibel★"
			},
			{
				"_id": "3189909033",
				"_name": "Vuurvlieg"
			},
			{
				"_id": "111034700",
				"_name": "Vuurvlieg★"
			},
			{
				"_id": "3109020208",
				"_name": "Lieveheersbeest"
			},
			{
				"_id": "32736597",
				"_name": "Lieveheersbeest★"
			},
			{
				"_id": "962429643",
				"_name": "Sprinkhaan"
			},
			{
				"_id": "2179065262",
				"_name": "Sprinkhaan★"
			},
			{
				"_id": "1463911196",
				"_name": "Rijstsprinkhaan"
			},
			{
				"_id": "4026393721",
				"_name": "Rijstsprinkhaan★"
			},
			{
				"_id": "3739594700",
				"_name": "Treksprinkhaan"
			},
			{
				"_id": "1717160105",
				"_name": "Treksprinkhaan★"
			},
			{
				"_id": "2455941619",
				"_name": "Krekel"
			},
			{
				"_id": "719246998",
				"_name": "Krekel★"
			},
			{
				"_id": "2087506143",
				"_name": "Belkrekel"
			},
			{
				"_id": "3302012858",
				"_name": "Belkrekel★"
			},
			{
				"_id": "201729104",
				"_name": "Sabelsprinkhaan"
			},
			{
				"_id": "3032105781",
				"_name": "Sabelsprinkhaan★"
			},
			{
				"_id": "1563510735",
				"_name": "Bidsprinkhaan"
			},
			{
				"_id": "3851231402",
				"_name": "Bidsprinkhaan★"
			},
			{
				"_id": "2850201434",
				"_name": "Grote sprinkhaan"
			},
			{
				"_id": "291436607",
				"_name": "Grote sprinkhaan★"
			},
			{
				"_id": "1345079045",
				"_name": "Boktor"
			},
			{
				"_id": "3901759584",
				"_name": "Boktor★"
			},
			{
				"_id": "3448658526",
				"_name": "Wandelende tak"
			},
			{
				"_id": "1966226747",
				"_name": "Wandelende tak★"
			},
			{
				"_id": "3710068532",
				"_name": "Veenmol"
			},
			{
				"_id": "1704935505",
				"_name": "Veenmol★"
			},
			{
				"_id": "2614427096",
				"_name": "Pissebed"
			},
			{
				"_id": "594057917",
				"_name": "Pissebed★"
			},
			{
				"_id": "657160083",
				"_name": "Bloemkever"
			},
			{
				"_id": "2677477622",
				"_name": "Bloemkever★"
			},
			{
				"_id": "3848634725",
				"_name": "Scarabee"
			},
			{
				"_id": "1574561280",
				"_name": "Scarabee★"
			},
			{
				"_id": "2500818410",
				"_name": "Gouden tor"
			},
			{
				"_id": "766710415",
				"_name": "Gouden tor★"
			},
			{
				"_id": "3792192892",
				"_name": "Schildwants"
			},
			{
				"_id": "1521754649",
				"_name": "Schildwants★"
			},
			{
				"_id": "4123589647",
				"_name": "Watertor"
			},
			{
				"_id": "1299487594",
				"_name": "Watertor★"
			},
			{
				"_id": "3025330938",
				"_name": "Waterwants"
			},
			{
				"_id": "216958367",
				"_name": "Waterwants★"
			},
			{
				"_id": "191619145",
				"_name": "Prachtkever"
			},
			{
				"_id": "3017246508",
				"_name": "Prachtkever★"
			},
			{
				"_id": "3973303630",
				"_name": "Japanse hagedis"
			},
			{
				"_id": "1416604203",
				"_name": "Japanse hagedis★"
			},
			{
				"_id": "2854492066",
				"_name": "Hagedis"
			},
			{
				"_id": "311980231",
				"_name": "Hagedis★"
			},
			{
				"_id": "2194656409",
				"_name": "Salamander"
			},
			{
				"_id": "980659196",
				"_name": "Salamander★"
			},
			{
				"_id": "1516012502",
				"_name": "Bladpootkreeft"
			},
			{
				"_id": "3806389427",
				"_name": "Bladpootkreeft★"
			},
			{
				"_id": "708212569",
				"_name": "Poelslak"
			},
			{
				"_id": "2458521660",
				"_name": "Poelslak★"
			},
			{
				"_id": "1143633550",
				"_name": "Appelslak"
			},
			{
				"_id": "4237693419",
				"_name": "Appelslak★"
			},
			{
				"_id": "3355352717",
				"_name": "Slak"
			},
			{
				"_id": "2135095784",
				"_name": "Slak★"
			},
			{
				"_id": "3460879014",
				"_name": "Boomkikker"
			},
			{
				"_id": "1995748803",
				"_name": "Boomkikker★"
			},
			{
				"_id": "4212356157",
				"_name": "Pad"
			},
			{
				"_id": "1135547224",
				"_name": "Pad★"
			},
			{
				"_id": "3522973129",
				"_name": "Schildpad"
			},
			{
				"_id": "1765812908",
				"_name": "Schildpad★"
			},
			{
				"_id": "3325883578",
				"_name": "Weekschildpad"
			},
			{
				"_id": "2122355679",
				"_name": "Weekschildpad★"
			},
			{
				"_id": "230968935",
				"_name": "Zoetwaterkrab"
			},
			{
				"_id": "3044550914",
				"_name": "Zoetwaterkrab★"
			},
			{
				"_id": "2496471005",
				"_name": "Rivierkreeft"
			},
			{
				"_id": "745633976",
				"_name": "Rivierkreeft★"
			},
			{
				"_id": "2108603112",
				"_name": "Kreeft"
			},
			{
				"_id": "3306347917",
				"_name": "Kreeft★"
			},
			{
				"_id": "3321527362",
				"_name": "Garnaal"
			},
			{
				"_id": "2101746471",
				"_name": "Garnaal★"
			},
			{
				"_id": "3002944724",
				"_name": "Zeester"
			},
			{
				"_id": "172043185",
				"_name": "Zeester★"
			},
			{
				"_id": "350191398",
				"_name": "Zeepaardje"
			},
			{
				"_id": "2892175427",
				"_name": "Zeepaardje★"
			},
			{
				"_id": "2711009606",
				"_name": "Karper"
			},
			{
				"_id": "422239779",
				"_name": "Karper★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "1848503989",
				"_name": "Ayu★"
			},
			{
				"_id": "748280183",
				"_name": "Poon"
			},
			{
				"_id": "2485501458",
				"_name": "Poon★"
			},
			{
				"_id": "2476792772",
				"_name": "Japanse zalm"
			},
			{
				"_id": "723303585",
				"_name": "Japanse zalm★"
			},
			{
				"_id": "2973484076",
				"_name": "Koi"
			},
			{
				"_id": "159884105",
				"_name": "Koi★"
			},
			{
				"_id": "1224023155",
				"_name": "Zonnebaars"
			},
			{
				"_id": "4031347478",
				"_name": "Zonnebaars★"
			},
			{
				"_id": "2059632369",
				"_name": "Zalm"
			},
			{
				"_id": "3263109524",
				"_name": "Zalm★"
			},
			{
				"_id": "1072835813",
				"_name": "Reuzenzalm"
			},
			{
				"_id": "2270055296",
				"_name": "Reuzenzalm★"
			},
			{
				"_id": "178883198",
				"_name": "Sardine"
			},
			{
				"_id": "2987781403",
				"_name": "Sardine★"
			},
			{
				"_id": "950003964",
				"_name": "Makreel"
			},
			{
				"_id": "2149814169",
				"_name": "Makreel★"
			},
			{
				"_id": "4208008714",
				"_name": "Spaanse makreel"
			},
			{
				"_id": "1114470767",
				"_name": "Spaanse makreel★"
			},
			{
				"_id": "2379624092",
				"_name": "Wijting"
			},
			{
				"_id": "896158201",
				"_name": "Wijting★"
			},
			{
				"_id": "3683420442",
				"_name": "Barracuda"
			},
			{
				"_id": "1664151167",
				"_name": "Barracuda★"
			},
			{
				"_id": "2327571077",
				"_name": "Vliegende vis"
			},
			{
				"_id": "839355872",
				"_name": "Vliegende vis★"
			},
			{
				"_id": "1335416938",
				"_name": "Slangekopvis"
			},
			{
				"_id": "4146380559",
				"_name": "Slangekopvis★"
			},
			{
				"_id": "3481974929",
				"_name": "Schorpioenvis"
			},
			{
				"_id": "2000084980",
				"_name": "Schorpioenvis★"
			},
			{
				"_id": "1537141217",
				"_name": "Knorvis"
			},
			{
				"_id": "3810692740",
				"_name": "Knorvis★"
			},
			{
				"_id": "1559440888",
				"_name": "Zeebaars"
			},
			{
				"_id": "3830401693",
				"_name": "Zeebaars★"
			},
			{
				"_id": "2884009365",
				"_name": "Zwartvis"
			},
			{
				"_id": "324672240",
				"_name": "Zwartvis★"
			},
			{
				"_id": "3977357177",
				"_name": "Vijlvis"
			},
			{
				"_id": "1437450268",
				"_name": "Vijlvis★"
			},
			{
				"_id": "1689619369",
				"_name": "Heilbot"
			},
			{
				"_id": "3691637964",
				"_name": "Heilbot★"
			},
			{
				"_id": "3264723035",
				"_name": "Bot"
			},
			{
				"_id": "2049695550",
				"_name": "Bot★"
			},
			{
				"_id": "2820732269",
				"_name": "Rode snapper"
			},
			{
				"_id": "278696456",
				"_name": "Rode snapper★"
			},
			{
				"_id": "1451485483",
				"_name": "Ishidai"
			},
			{
				"_id": "3997142606",
				"_name": "Ishidai★"
			},
			{
				"_id": "3705752835",
				"_name": "Zeebrasem"
			},
			{
				"_id": "1683827302",
				"_name": "Zeebrasem★"
			},
			{
				"_id": "330480447",
				"_name": "Amberjack"
			},
			{
				"_id": "2869877850",
				"_name": "Amberjack★"
			},
			{
				"_id": "4257012243",
				"_name": "Egelvis"
			},
			{
				"_id": "1157676406",
				"_name": "Egelvis★"
			},
			{
				"_id": "562354621",
				"_name": "Modderkruiper"
			},
			{
				"_id": "2570632920",
				"_name": "Modderkruiper★"
			},
			{
				"_id": "737418606",
				"_name": "Haarstaartvis"
			},
			{
				"_id": "2471000587",
				"_name": "Haarstaartvis★"
			},
			{
				"_id": "3836210002",
				"_name": "Zeepaling"
			},
			{
				"_id": "1545309239",
				"_name": "Zeepaling★"
			},
			{
				"_id": "3821678411",
				"_name": "Paling"
			},
			{
				"_id": "1534478382",
				"_name": "Paling★"
			},
			{
				"_id": "3096283143",
				"_name": "Meerval"
			},
			{
				"_id": "3272546",
				"_name": "Meerval★"
			},
			{
				"_id": "3370613896",
				"_name": "Kwal"
			},
			{
				"_id": "1885019117",
				"_name": "Kwal★"
			},
			{
				"_id": "1675120560",
				"_name": "Octopus"
			},
			{
				"_id": "3680774357",
				"_name": "Octopus★"
			},
			{
				"_id": "2894838156",
				"_name": "Rifinktvis"
			},
			{
				"_id": "339205865",
				"_name": "Rifinktvis★"
			},
			{
				"_id": "4094334520",
				"_name": "Zeekat"
			},
			{
				"_id": "1287057757",
				"_name": "Zeekat★"
			},
			{
				"_id": "1374563634",
				"_name": "Vuurvlieginktvis"
			},
			{
				"_id": "3914484311",
				"_name": "Vuurvlieginktvis★"
			},
			{
				"_id": "3046148301",
				"_name": "Inktvis"
			},
			{
				"_id": "221048744",
				"_name": "Inktvis★"
			},
			{
				"_id": "897771574",
				"_name": "Pijlinktvis"
			},
			{
				"_id": "2369687379",
				"_name": "Pijlinktvis★"
			},
			{
				"_id": "1116068000",
				"_name": "Zeeduivel"
			},
			{
				"_id": "4198088645",
				"_name": "Zeeduivel★"
			},
			{
				"_id": "2585171951",
				"_name": "Pijlstaartrog"
			},
			{
				"_id": "581628042",
				"_name": "Pijlstaartrog★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlijn"
			},
			{
				"_id": "123480955",
				"_name": "Marlijn★"
			},
			{
				"_id": "2198709934",
				"_name": "Tonijn"
			},
			{
				"_id": "1001505227",
				"_name": "Tonijn★"
			}
		]
	}
}
