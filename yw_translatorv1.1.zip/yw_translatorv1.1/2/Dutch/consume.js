xmlval = {
	"items": {
		"item": [
			{
				"_id": "2170728737",
				"_name": "Chocoladereep"
			},
			{
				"_id": "1803927674",
				"_name": "Pruimenrijstbal"
			},
			{
				"_id": "4069298624",
				"_name": "Rijstbal in blad"
			},
			{
				"_id": "2240520534",
				"_name": "Kuitrijstbal"
			},
			{
				"_id": "468661493",
				"_name": "Garnalenrijstbal"
			},
			{
				"_id": "1783081549",
				"_name": "Sandwich"
			},
			{
				"_id": "4082039799",
				"_name": "Puddingbroodje"
			},
			{
				"_id": "1831497300",
				"_name": "Currybroodje"
			},
			{
				"_id": "2219428705",
				"_name": "Stokbrood"
			},
			{
				"_id": "439180994",
				"_name": "Bah-bagel"
			},
			{
				"_id": "1744901140",
				"_name": "Kauwgom"
			},
			{
				"_id": "4043851182",
				"_name": "Kauwbonbon"
			},
			{
				"_id": "2249159992",
				"_name": "Grote cracker"
			},
			{
				"_id": "409723035",
				"_name": "Fruitsnoepjes"
			},
			{
				"_id": "1869402125",
				"_name": "Geschaafd ijs"
			},
			{
				"_id": "4133847479",
				"_name": "Karamelappel"
			},
			{
				"_id": "1774419491",
				"_name": "Melk"
			},
			{
				"_id": "4039782297",
				"_name": "Koffiemelk"
			},
			{
				"_id": "2278366991",
				"_name": "Fruitmelk"
			},
			{
				"_id": "430541484",
				"_name": "Verse melk"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Zielsthee"
			},
			{
				"_id": "2189560202",
				"_name": "Inspirator Y"
			},
			{
				"_id": "484875305",
				"_name": "VoltXtreem"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Dubbele burger"
			},
			{
				"_id": "488961566",
				"_name": "Mjamburger"
			},
			{
				"_id": "1858787071",
				"_name": "Instant noedels"
			},
			{
				"_id": "4156786501",
				"_name": "Noedels met vlees"
			},
			{
				"_id": "2160375763",
				"_name": "Noedels speciaal"
			},
			{
				"_id": "513811056",
				"_name": "Noedels compleet"
			},
			{
				"_id": "1704366530",
				"_name": "Komkommerrol"
			},
			{
				"_id": "4238327928",
				"_name": "Garnalensushi"
			},
			{
				"_id": "2342056174",
				"_name": "Zalmeitjessushi"
			},
			{
				"_id": "368862541",
				"_name": "Tonijnsushi"
			},
			{
				"_id": "1683291125",
				"_name": "Dumplings"
			},
			{
				"_id": "4250774095",
				"_name": "Lever met ui"
			},
			{
				"_id": "2321193689",
				"_name": "Krabommelet"
			},
			{
				"_id": "339611514",
				"_name": "Chiligarnalen"
			},
			{
				"_id": "1664696300",
				"_name": "Mabu-tofu"
			},
			{
				"_id": "3539717416",
				"_name": "Wortel"
			},
			{
				"_id": "1274190994",
				"_name": "Komkommer"
			},
			{
				"_id": "1022733316",
				"_name": "Bamboescheut"
			},
			{
				"_id": "2727426471",
				"_name": "Matsutake"
			},
			{
				"_id": "3502076785",
				"_name": "Kippendij"
			},
			{
				"_id": "1236542155",
				"_name": "Spek"
			},
			{
				"_id": "1051923037",
				"_name": "Rundertong"
			},
			{
				"_id": "2698479614",
				"_name": "Sukadelapjes"
			},
			{
				"_id": "3514767686",
				"_name": "Gedroogde vis"
			},
			{
				"_id": "1215711484",
				"_name": "Geelvinmakreel"
			},
			{
				"_id": "1064401002",
				"_name": "Verse zee-egel"
			},
			{
				"_id": "2702568905",
				"_name": "Topkwaliteit tonijn"
			},
			{
				"_id": "3559919555",
				"_name": "Kipcurry"
			},
			{
				"_id": "1295605369",
				"_name": "Lamscurry"
			},
			{
				"_id": "977170159",
				"_name": "Viscurry"
			},
			{
				"_id": "2757425996",
				"_name": "Curry speciaal"
			},
			{
				"_id": "3546139610",
				"_name": "Groentecurry"
			},
			{
				"_id": "3589432820",
				"_name": "Kwarktaart"
			},
			{
				"_id": "1291531342",
				"_name": "Aardbeientaart"
			},
			{
				"_id": "1006372056",
				"_name": "Pannenkoeken"
			},
			{
				"_id": "2778239355",
				"_name": "Jumboparfait"
			},
			{
				"_id": "3533677037",
				"_name": "Zoete rijstcake"
			},
			{
				"_id": "1268183127",
				"_name": "Spookdonut"
			},
			{
				"_id": "1016185025",
				"_name": "Geestdonut"
			},
			{
				"_id": "3618954157",
				"_name": "Gestoomde rettich"
			},
			{
				"_id": "1321044503",
				"_name": "Gekookt ei"
			},
			{
				"_id": "968538753",
				"_name": "Malse vleesspies"
			},
			{
				"_id": "2816356130",
				"_name": "Topkwaliteit oden"
			},
			{
				"_id": "3598102938",
				"_name": "Soba-noedels"
			},
			{
				"_id": "3710580391",
				"_name": "Aardappelchips"
			},
			{
				"_id": "1143187229",
				"_name": "Lekkere hapjes"
			},
			{
				"_id": "858036107",
				"_name": "Tortillachips"
			},
			{
				"_id": "2906653224",
				"_name": "Pepermuntjes"
			},
			{
				"_id": "2370076515",
				"_name": "Minibal"
			},
			{
				"_id": "320924352",
				"_name": "Kleine bal"
			},
			{
				"_id": "2317990778",
				"_name": "Middelgrote bal"
			},
			{
				"_id": "4247686124",
				"_name": "Grote bal"
			},
			{
				"_id": "1665801807",
				"_name": "Megabal"
			},
			{
				"_id": "340602585",
				"_name": "Heilige bal"
			},
			{
				"_id": "397252210",
				"_name": "StimuXtract"
			},
			{
				"_id": "2393163720",
				"_name": "StimuXtract Alfa"
			},
			{
				"_id": "279199406",
				"_name": "Vechtgeheimen"
			},
			{
				"_id": "2309844756",
				"_name": "Toptechnieken"
			},
			{
				"_id": "4272578434",
				"_name": "Zielsgeheimen"
			},
			{
				"_id": "469268883",
				"_name": "Serieus leven"
			},
			{
				"_id": "2196842537",
				"_name": "Kopvoetkarate"
			},
			{
				"_id": "4126546111",
				"_name": "Karatepraktijken"
			},
			{
				"_id": "1804766492",
				"_name": "Techniboek"
			},
			{
				"_id": "479575434",
				"_name": "Techniclopedie"
			},
			{
				"_id": "2241653808",
				"_name": "Verdedigingsboek"
			},
			{
				"_id": "4070300838",
				"_name": "Verdedigingsbijbel"
			},
			{
				"_id": "1646575927",
				"_name": "Engeltjesboek"
			},
			{
				"_id": "354677153",
				"_name": "Tederheidsboek"
			},
			{
				"_id": "1977907268",
				"_name": "Vloekboek"
			},
			{
				"_id": "48449746",
				"_name": "Topvloekboek"
			},
			{
				"_id": "2615810408",
				"_name": "Hulpboek"
			},
			{
				"_id": "3974965758",
				"_name": "Extrahulpboek"
			},
			{
				"_id": "367732779",
				"_name": "Kra.-talisman"
			},
			{
				"_id": "2363652497",
				"_name": "Gst.-talisman"
			},
			{
				"_id": "4226107655",
				"_name": "Vdg.-talisman"
			},
			{
				"_id": "1703009444",
				"_name": "Snd.-talisman"
			},
			{
				"_id": "338248220",
				"_name": "Vies medicijn"
			},
			{
				"_id": "2367689638",
				"_name": "Bitter medicijn"
			},
			{
				"_id": "4196868912",
				"_name": "Machtig medicijn"
			},
			{
				"_id": "376437829",
				"_name": "Ontsnappingspop"
			},
			{
				"_id": "1628217366",
				"_name": "IJzeren pop"
			},
			{
				"_id": "291919001",
				"_name": "Bronzen pop"
			},
			{
				"_id": "2288977187",
				"_name": "Zilveren pop"
			},
			{
				"_id": "4285019573",
				"_name": "Gouden pop"
			},
			{
				"_id": "369856640",
				"_name": "Platina pop"
			},
			{
				"_id": "2908180302",
				"_name": "Visaas"
			},
			{
				"_id": "878583540",
				"_name": "Zwarte siroop"
			},
			{
				"_id": "2895455609",
				"_name": "Dansende ster"
			},
			{
				"_id": "899445955",
				"_name": "Lot"
			},
			{
				"_id": "1117471829",
				"_name": "Muziekkaart"
			},
			{
				"_id": "1535145236",
				"_name": "Bronzen label"
			},
			{
				"_id": "3320111287",
				"_name": "Zilveren label"
			},
			{
				"_id": "3001274401",
				"_name": "Gouden label"
			},
			{
				"_id": "747062658",
				"_name": "Essence v.h. kwaad"
			},
			{
				"_id": "440013732",
				"_name": "Epische kling"
			},
			{
				"_id": "2201174558",
				"_name": "Vervloekte kling"
			},
			{
				"_id": "2220787207",
				"_name": "Heilige kling"
			},
			{
				"_id": "4097077896",
				"_name": "Generaalsziel"
			},
			{
				"_id": "1783686955",
				"_name": "Knallende liefde"
			},
			{
				"_id": "492296125",
				"_name": "Elektrobal"
			},
			{
				"_id": "1676061440",
				"_name": "Onsterfelijke ziel"
			},
			{
				"_id": "2586342239",
				"_name": "Platinabaar"
			},
			{
				"_id": "350329750",
				"_name": "Sneeuwstormcape"
			},
			{
				"_id": "1948652147",
				"_name": "Liefdesscepter"
			},
			{
				"_id": "4082742929",
				"_name": "IJzige haarclip"
			},
			{
				"_id": "52503269",
				"_name": "Halter"
			},
			{
				"_id": "1934349930",
				"_name": "Scherf v.h. kwaad"
			},
			{
				"_id": "3979297737",
				"_name": "Verjongingspoeder"
			},
			{
				"_id": "2638591814",
				"_name": "Drakenbal"
			},
			{
				"_id": "1098757352",
				"_name": "Grimmig zwaard"
			},
			{
				"_id": "913998974",
				"_name": "Zandpak"
			},
			{
				"_id": "2943604164",
				"_name": "Wonderwater"
			},
			{
				"_id": "3631539538",
				"_name": "Vervloekt dagboek"
			},
			{
				"_id": "1221327043",
				"_name": "Hoorn"
			},
			{
				"_id": "1070385237",
				"_name": "Geheugenzuiger"
			},
			{
				"_id": "156362294",
				"_name": "Zeemeerminparel"
			},
			{
				"_id": "1771466707",
				"_name": "Liefdesrijstbal"
			},
			{
				"_id": "2119620256",
				"_name": "Kapotte bel"
			},
			{
				"_id": "2033914553",
				"_name": "Gehavend zwaard"
			},
			{
				"_id": "3761390339",
				"_name": "Ruwe wetsteen"
			},
			{
				"_id": "2536862613",
				"_name": "Sinistere wetsteen"
			},
			{
				"_id": "126512644",
				"_name": "Sublieme wetsteen"
			},
			{
				"_id": "273340279",
				"_name": "Houtsnijwerk beer"
			},
			{
				"_id": "1733158881",
				"_name": "Goudvislantaarn"
			},
			{
				"_id": "4265915995",
				"_name": "Meesterlantaarn"
			},
			{
				"_id": "2302904013",
				"_name": "Gouden embleem"
			},
			{
				"_id": "388436846",
				"_name": "Takoyaki-vorm"
			},
			{
				"_id": "1612719096",
				"_name": "Duinzand"
			},
			{
				"_id": "4180243010",
				"_name": "Klassieke parasol"
			},
			{
				"_id": "2385396436",
				"_name": "Kleifiguur"
			},
			{
				"_id": "512843589",
				"_name": "Rode hibiscus"
			},
			{
				"_id": "3881797402",
				"_name": "Helend kruid"
			},
			{
				"_id": "2421733260",
				"_name": "Stinkend kruid"
			},
			{
				"_id": "238821935",
				"_name": "Bitter kruid"
			},
			{
				"_id": "2592718716",
				"_name": "Rode munt"
			},
			{
				"_id": "58781382",
				"_name": "Gele munt"
			},
			{
				"_id": "1955061328",
				"_name": "Oranje munt"
			},
			{
				"_id": "3940764659",
				"_name": "Roze munt"
			},
			{
				"_id": "2648996709",
				"_name": "Groene munt"
			},
			{
				"_id": "82651871",
				"_name": "Blauwe munt"
			},
			{
				"_id": "1944721993",
				"_name": "Paarse munt"
			},
			{
				"_id": "3814000600",
				"_name": "Lichtblauwe munt"
			},
			{
				"_id": "3411442988",
				"_name": "Vijf-sterrenmunt"
			},
			{
				"_id": "1542021309",
				"_name": "Speciale munt"
			},
			{
				"_id": "753815595",
				"_name": "Munt (Yo)"
			},
			{
				"_id": "1277811150",
				"_name": "Munt (Kai)"
			},
			{
				"_id": "992930136",
				"_name": "Munt (Op)"
			},
			{
				"_id": "2720512226",
				"_name": "Munt (Roep)"
			},
			{
				"_id": "905273706",
				"_name": "Munt (Bloem)"
			},
			{
				"_id": "1728350733",
				"_name": "Munt (Vogel)"
			},
			{
				"_id": "268679835",
				"_name": "Munt (Wind)"
			},
			{
				"_id": "2299194145",
				"_name": "Munt (Maan)"
			},
			{
				"_id": "4262321079",
				"_name": "Glittermunt"
			},
			{
				"_id": "1617514004",
				"_name": "Munt (Noord)"
			},
			{
				"_id": "393117314",
				"_name": "Munt (Noordoost)"
			},
			{
				"_id": "2389126968",
				"_name": "Munt (Oost)"
			},
			{
				"_id": "4183826350",
				"_name": "Munt (Centraal)"
			},
			{
				"_id": "1776222783",
				"_name": "Munt (West)"
			},
			{
				"_id": "517485225",
				"_name": "Munt (Berg)"
			},
			{
				"_id": "2116008780",
				"_name": "Munt (Zuid)"
			},
			{
				"_id": "152603610",
				"_name": "Munt (M.westen)"
			},
			{
				"_id": "2417089120",
				"_name": "Munt (Eiland)"
			},
			{
				"_id": "3877038838",
				"_name": "Mysterieuze munt"
			},
			{
				"_id": "2037546837",
				"_name": "Munt (Everzwijn)"
			},
			{
				"_id": "242569155",
				"_name": "Munt (Hert)"
			},
			{
				"_id": "2541493881",
				"_name": "Munt (Vlinder)"
			},
			{
				"_id": "3766169327",
				"_name": "Opgewekte munt"
			},
			{
				"_id": "3707752950",
				"_name": "Rood muntdeel"
			},
			{
				"_id": "2885214560",
				"_name": "Geel muntdeel"
			},
			{
				"_id": "854700250",
				"_name": "Oranje muntdeel"
			},
			{
				"_id": "1173782604",
				"_name": "Roze muntdeel"
			},
			{
				"_id": "3578371549",
				"_name": "Groen muntdeel"
			},
			{
				"_id": "2723065163",
				"_name": "Blauw muntdeel"
			},
			{
				"_id": "3263767726",
				"_name": "Paars muntdeel"
			},
			{
				"_id": "3045987384",
				"_name": "Lichtbl. muntdeel"
			},
			{
				"_id": "1200047969",
				"_name": "Rood kistje"
			},
			{
				"_id": "1178938710",
				"_name": "Portaalbal"
			},
			{
				"_id": "2285637778",
				"_name": "Noko-bal"
			},
			{
				"_id": "288702760",
				"_name": "Kyubi-bal"
			}
		]
	}
}
