xmlval = {
	"items": {
		"item": [
			{
				"_id": "1",
				"_name": "Mürrisch"
			},
			{
				"_id": "2",
				"_name": "Logisch"
			},
			{
				"_id": "3",
				"_name": "Vorsichtig"
			},
			{
				"_id": "4",
				"_name": "Sanft"
			},
			{
				"_id": "5",
				"_name": "Verrückt"
			},
			{
				"_id": "6",
				"_name": "Hilfreich"
			},
			{
				"_id": "7",
				"_name": "Grob"
			},
			{
				"_id": "8",
				"_name": "Klug"
			},
			{
				"_id": "9",
				"_name": "Ruhig"
			},
			{
				"_id": "10",
				"_name": "Zärtlich"
			},
			{
				"_id": "11",
				"_name": "Gemein"
			},
			{
				"_id": "12",
				"_name": "Ergeben"
			}
		]
	}
}
