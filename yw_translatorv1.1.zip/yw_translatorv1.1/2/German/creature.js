xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Grüne Zikade"
			},
			{
				"_id": "1753366683",
				"_name": "Grüne Zikade★"
			},
			{
				"_id": "1228371524",
				"_name": "Braune Zikade"
			},
			{
				"_id": "4052422945",
				"_name": "Braune Zikade★"
			},
			{
				"_id": "1702355358",
				"_name": "Große Zikade"
			},
			{
				"_id": "3721103099",
				"_name": "Große Zikade★"
			},
			{
				"_id": "4236161060",
				"_name": "Afrikanische Zikade"
			},
			{
				"_id": "1153619777",
				"_name": "Afrikanische Zikade★"
			},
			{
				"_id": "1043351250",
				"_name": "Abendzikade"
			},
			{
				"_id": "2257330615",
				"_name": "Abendzikade★"
			},
			{
				"_id": "2339995826",
				"_name": "Asiatische Zikade"
			},
			{
				"_id": "868607959",
				"_name": "Asiatische Zikade★"
			},
			{
				"_id": "1314566749",
				"_name": "Sägz.-Hir.käfer"
			},
			{
				"_id": "4142323000",
				"_name": "Sägz-Hir.käfer★"
			},
			{
				"_id": "858605080",
				"_name": "Großer Hirschkäfer"
			},
			{
				"_id": "2341544317",
				"_name": "Großer Hirschkäfer★"
			},
			{
				"_id": "354227473",
				"_name": "Miyama-Hirschkäfer"
			},
			{
				"_id": "2913038964",
				"_name": "Miyama-Hirschkäfer★"
			},
			{
				"_id": "3612599271",
				"_name": "Dorcus-Hirschkäfer"
			},
			{
				"_id": "1877968002",
				"_name": "Dorcus-Hirschkäfer★"
			},
			{
				"_id": "2689913713",
				"_name": "Nashornkäfer"
			},
			{
				"_id": "417903636",
				"_name": "Nashornkäfer★"
			},
			{
				"_id": "2350138539",
				"_name": "Kohlweißling"
			},
			{
				"_id": "883434446",
				"_name": "Kohlweißling★"
			},
			{
				"_id": "3374651071",
				"_name": "Schw.schwanz"
			},
			{
				"_id": "1905881562",
				"_name": "Schw.schwanz★"
			},
			{
				"_id": "2063668422",
				"_name": "Pfauenauge"
			},
			{
				"_id": "3283973027",
				"_name": "Pfauenauge★"
			},
			{
				"_id": "541504394",
				"_name": "Purpurschmetterling"
			},
			{
				"_id": "2566575343",
				"_name": "Purpurschmetterling★"
			},
			{
				"_id": "3662603053",
				"_name": "Silberlibelle"
			},
			{
				"_id": "1660060744",
				"_name": "Silberlibelle★"
			},
			{
				"_id": "2907296699",
				"_name": "Königslibelle"
			},
			{
				"_id": "368424158",
				"_name": "Königslibelle★"
			},
			{
				"_id": "2969153051",
				"_name": "Riesenlibelle"
			},
			{
				"_id": "138791294",
				"_name": "Riesenlibelle★"
			},
			{
				"_id": "3189909033",
				"_name": "Leuchtkäfer"
			},
			{
				"_id": "111034700",
				"_name": "Leuchtkäfer★"
			},
			{
				"_id": "3109020208",
				"_name": "Marienkäfer"
			},
			{
				"_id": "32736597",
				"_name": "Marienkäfer★"
			},
			{
				"_id": "962429643",
				"_name": "Langkopfheuschrecke"
			},
			{
				"_id": "2179065262",
				"_name": "Langkopfheuschrecke★"
			},
			{
				"_id": "1463911196",
				"_name": "Heuschrecke"
			},
			{
				"_id": "4026393721",
				"_name": "Heuschrecke★"
			},
			{
				"_id": "3739594700",
				"_name": "Wanderheus."
			},
			{
				"_id": "1717160105",
				"_name": "Wanderheus.★"
			},
			{
				"_id": "2455941619",
				"_name": "Grille"
			},
			{
				"_id": "719246998",
				"_name": "Grille★"
			},
			{
				"_id": "2087506143",
				"_name": "Glöckchenzikade"
			},
			{
				"_id": "3302012858",
				"_name": "Glöckchenzikade★"
			},
			{
				"_id": "201729104",
				"_name": "Langhorn-Grashüpfer"
			},
			{
				"_id": "3032105781",
				"_name": "Langhorn-Grashüpfer★"
			},
			{
				"_id": "1563510735",
				"_name": "Fangheuschrecke"
			},
			{
				"_id": "3851231402",
				"_name": "Fangheuschrecke★"
			},
			{
				"_id": "2850201434",
				"_name": "Gottesanbeterin"
			},
			{
				"_id": "291436607",
				"_name": "Gottesanbeterin★"
			},
			{
				"_id": "1345079045",
				"_name": "Scheckenbock"
			},
			{
				"_id": "3901759584",
				"_name": "Scheckenbock★"
			},
			{
				"_id": "3448658526",
				"_name": "Stabheuschrecke"
			},
			{
				"_id": "1966226747",
				"_name": "Stabheuschrecke★"
			},
			{
				"_id": "3710068532",
				"_name": "Maulwurfsgrille"
			},
			{
				"_id": "1704935505",
				"_name": "Maulwurfsgrille★"
			},
			{
				"_id": "2614427096",
				"_name": "Kellerassel"
			},
			{
				"_id": "594057917",
				"_name": "Kellerassel★"
			},
			{
				"_id": "657160083",
				"_name": "Rosenkäfer"
			},
			{
				"_id": "2677477622",
				"_name": "Rosenkäfer★"
			},
			{
				"_id": "3848634725",
				"_name": "Schimmerkäfer"
			},
			{
				"_id": "1574561280",
				"_name": "Schimmerkäfer★"
			},
			{
				"_id": "2500818410",
				"_name": "Kanabun-Käfer"
			},
			{
				"_id": "766710415",
				"_name": "Kanabun-Käfer★"
			},
			{
				"_id": "3792192892",
				"_name": "Baumwanze"
			},
			{
				"_id": "1521754649",
				"_name": "Baumwanze★"
			},
			{
				"_id": "4123589647",
				"_name": "Schwimmkäfer"
			},
			{
				"_id": "1299487594",
				"_name": "Schwimmkäfer★"
			},
			{
				"_id": "3025330938",
				"_name": "Großer Wasserkäfer"
			},
			{
				"_id": "216958367",
				"_name": "Großer Wasserkäfer★"
			},
			{
				"_id": "191619145",
				"_name": "Prachtkäfer"
			},
			{
				"_id": "3017246508",
				"_name": "Prachtkäfer★"
			},
			{
				"_id": "3973303630",
				"_name": "Japanische Eidechse"
			},
			{
				"_id": "1416604203",
				"_name": "Japanische Eidechse★"
			},
			{
				"_id": "2854492066",
				"_name": "Eidechse"
			},
			{
				"_id": "311980231",
				"_name": "Eidechse★"
			},
			{
				"_id": "2194656409",
				"_name": "Feuerbauchmolch"
			},
			{
				"_id": "980659196",
				"_name": "Feuerbauchmolch★"
			},
			{
				"_id": "1516012502",
				"_name": "Schildgarnele"
			},
			{
				"_id": "3806389427",
				"_name": "Schildgarnele★"
			},
			{
				"_id": "708212569",
				"_name": "Teichschnecke"
			},
			{
				"_id": "2458521660",
				"_name": "Teichschnecke★"
			},
			{
				"_id": "1143633550",
				"_name": "Große Teichschnecke"
			},
			{
				"_id": "4237693419",
				"_name": "Große Teichschnecke★"
			},
			{
				"_id": "3355352717",
				"_name": "Schnecke"
			},
			{
				"_id": "2135095784",
				"_name": "Schnecke★"
			},
			{
				"_id": "3460879014",
				"_name": "Laubfrosch"
			},
			{
				"_id": "1995748803",
				"_name": "Laubfrosch★"
			},
			{
				"_id": "4212356157",
				"_name": "Kröte"
			},
			{
				"_id": "1135547224",
				"_name": "Kröte★"
			},
			{
				"_id": "3522973129",
				"_name": "Schildkröte"
			},
			{
				"_id": "1765812908",
				"_name": "Schildkröte★"
			},
			{
				"_id": "3325883578",
				"_name": "Weichschildkröte"
			},
			{
				"_id": "2122355679",
				"_name": "Weichschildkröte★"
			},
			{
				"_id": "230968935",
				"_name": "Flusskrabbe"
			},
			{
				"_id": "3044550914",
				"_name": "Flusskrabbe★"
			},
			{
				"_id": "2496471005",
				"_name": "Flusskrebs"
			},
			{
				"_id": "745633976",
				"_name": "Flusskrebs★"
			},
			{
				"_id": "2108603112",
				"_name": "Languste"
			},
			{
				"_id": "3306347917",
				"_name": "Languste★"
			},
			{
				"_id": "3321527362",
				"_name": "Heuschreckenkrebs"
			},
			{
				"_id": "2101746471",
				"_name": "Heuschreckenkrebs★"
			},
			{
				"_id": "3002944724",
				"_name": "Seestern"
			},
			{
				"_id": "172043185",
				"_name": "Seestern★"
			},
			{
				"_id": "350191398",
				"_name": "Seepferdchen"
			},
			{
				"_id": "2892175427",
				"_name": "Seepferdchen★"
			},
			{
				"_id": "2711009606",
				"_name": "Karpfen"
			},
			{
				"_id": "422239779",
				"_name": "Karpfen★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "1848503989",
				"_name": "Ayu★"
			},
			{
				"_id": "748280183",
				"_name": "Meeräsche"
			},
			{
				"_id": "2485501458",
				"_name": "Meeräsche★"
			},
			{
				"_id": "2476792772",
				"_name": "Yamame-Forelle"
			},
			{
				"_id": "723303585",
				"_name": "Yamame-Forelle★"
			},
			{
				"_id": "2973484076",
				"_name": "Koi"
			},
			{
				"_id": "159884105",
				"_name": "Koi★"
			},
			{
				"_id": "1224023155",
				"_name": "Schwarzbarsch"
			},
			{
				"_id": "4031347478",
				"_name": "Schwarzbarsch★"
			},
			{
				"_id": "2059632369",
				"_name": "Lachs"
			},
			{
				"_id": "3263109524",
				"_name": "Lachs★"
			},
			{
				"_id": "1072835813",
				"_name": "Huchen"
			},
			{
				"_id": "2270055296",
				"_name": "Huchen★"
			},
			{
				"_id": "178883198",
				"_name": "Sardine"
			},
			{
				"_id": "2987781403",
				"_name": "Sardine★"
			},
			{
				"_id": "950003964",
				"_name": "Makrele"
			},
			{
				"_id": "2149814169",
				"_name": "Makrele★"
			},
			{
				"_id": "4208008714",
				"_name": "Blaumakrele"
			},
			{
				"_id": "1114470767",
				"_name": "Blaumakrele★"
			},
			{
				"_id": "2379624092",
				"_name": "Weißfisch"
			},
			{
				"_id": "896158201",
				"_name": "Weißfisch★"
			},
			{
				"_id": "3683420442",
				"_name": "Barrakuda"
			},
			{
				"_id": "1664151167",
				"_name": "Barrakuda★"
			},
			{
				"_id": "2327571077",
				"_name": "Fliegender Fisch"
			},
			{
				"_id": "839355872",
				"_name": "Fliegender Fisch★"
			},
			{
				"_id": "1335416938",
				"_name": "Schl.kopffisch"
			},
			{
				"_id": "4146380559",
				"_name": "Schl.kopffisch★"
			},
			{
				"_id": "3481974929",
				"_name": "Skorpionfisch"
			},
			{
				"_id": "2000084980",
				"_name": "Skorpionfisch★"
			},
			{
				"_id": "1537141217",
				"_name": "Grunzer"
			},
			{
				"_id": "3810692740",
				"_name": "Grunzer★"
			},
			{
				"_id": "1559440888",
				"_name": "Meerbrasse"
			},
			{
				"_id": "3830401693",
				"_name": "Meerbrasse★"
			},
			{
				"_id": "2884009365",
				"_name": "Schwarzfisch"
			},
			{
				"_id": "324672240",
				"_name": "Schwarzfisch★"
			},
			{
				"_id": "3977357177",
				"_name": "Feilenfisch"
			},
			{
				"_id": "1437450268",
				"_name": "Feilenfisch★"
			},
			{
				"_id": "1689619369",
				"_name": "Heilbutt"
			},
			{
				"_id": "3691637964",
				"_name": "Heilbutt★"
			},
			{
				"_id": "3264723035",
				"_name": "Scholle"
			},
			{
				"_id": "2049695550",
				"_name": "Scholle★"
			},
			{
				"_id": "2820732269",
				"_name": "R. Schnapper"
			},
			{
				"_id": "278696456",
				"_name": "R. Schnapper★"
			},
			{
				"_id": "1451485483",
				"_name": "Papageienfisch"
			},
			{
				"_id": "3997142606",
				"_name": "Papageienfisch★"
			},
			{
				"_id": "3705752835",
				"_name": "Dunkle Meerbrasse"
			},
			{
				"_id": "1683827302",
				"_name": "Dunkle Meerbrasse★"
			},
			{
				"_id": "330480447",
				"_name": "Gelbschwanzmakrele"
			},
			{
				"_id": "2869877850",
				"_name": "Gelbschwanzmakrele★"
			},
			{
				"_id": "4257012243",
				"_name": "Igelfisch"
			},
			{
				"_id": "1157676406",
				"_name": "Igelfisch★"
			},
			{
				"_id": "562354621",
				"_name": "Schmerle"
			},
			{
				"_id": "2570632920",
				"_name": "Schmerle★"
			},
			{
				"_id": "737418606",
				"_name": "Degenfisch"
			},
			{
				"_id": "2471000587",
				"_name": "Degenfisch★"
			},
			{
				"_id": "3836210002",
				"_name": "Meeraal"
			},
			{
				"_id": "1545309239",
				"_name": "Meeraal★"
			},
			{
				"_id": "3821678411",
				"_name": "Aal"
			},
			{
				"_id": "1534478382",
				"_name": "Aal★"
			},
			{
				"_id": "3096283143",
				"_name": "Wels"
			},
			{
				"_id": "3272546",
				"_name": "Wels★"
			},
			{
				"_id": "3370613896",
				"_name": "Qualle"
			},
			{
				"_id": "1885019117",
				"_name": "Qualle★"
			},
			{
				"_id": "1675120560",
				"_name": "Oktopus"
			},
			{
				"_id": "3680774357",
				"_name": "Oktopus★"
			},
			{
				"_id": "2894838156",
				"_name": "Riffkalmar"
			},
			{
				"_id": "339205865",
				"_name": "Riffkalmar★"
			},
			{
				"_id": "4094334520",
				"_name": "Tintenfisch"
			},
			{
				"_id": "1287057757",
				"_name": "Tintenfisch★"
			},
			{
				"_id": "1374563634",
				"_name": "Leuchtkalmar"
			},
			{
				"_id": "3914484311",
				"_name": "Leuchtkalmar★"
			},
			{
				"_id": "3046148301",
				"_name": "Kalmar"
			},
			{
				"_id": "221048744",
				"_name": "Kalmar★"
			},
			{
				"_id": "897771574",
				"_name": "Lanzenkalmar"
			},
			{
				"_id": "2369687379",
				"_name": "Lanzenkalmar★"
			},
			{
				"_id": "1116068000",
				"_name": "Seeteufel"
			},
			{
				"_id": "4198088645",
				"_name": "Seeteufel★"
			},
			{
				"_id": "2585171951",
				"_name": "Rochen"
			},
			{
				"_id": "581628042",
				"_name": "Rochen★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "123480955",
				"_name": "Marlin★"
			},
			{
				"_id": "2198709934",
				"_name": "Thunfisch"
			},
			{
				"_id": "1001505227",
				"_name": "Thunfisch★"
			}
		]
	}
}
