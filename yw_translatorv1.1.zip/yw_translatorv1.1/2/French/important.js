xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "496659440",
				"_name": "Modèle zéro"
			},
			{
				"_id": "917977139",
				"_name": "Montre étrange"
			},
			{
				"_id": "1102055589",
				"_name": "Montre étrange"
			},
			{
				"_id": "2707808699",
				"_name": "Médallium des Yo-kai"
			},
			{
				"_id": "1208370318",
				"_name": "Filet à insectes"
			},
			{
				"_id": "3507426612",
				"_name": "Canne à pêche"
			},
			{
				"_id": "2785551778",
				"_name": "Ticket de musée"
			},
			{
				"_id": "1450226134",
				"_name": "Vélo du vent"
			},
			{
				"_id": "3480871020",
				"_name": "Vélo du printemps"
			},
			{
				"_id": "2270540466",
				"_name": "Vélo du couchant"
			},
			{
				"_id": "4031939108",
				"_name": "Vélo de la mer"
			},
			{
				"_id": "1626185653",
				"_name": "Vélo des cerisiers"
			},
			{
				"_id": "401256227",
				"_name": "Vélo sylvestre"
			},
			{
				"_id": "1999447750",
				"_name": "Vélo des nuages"
			},
			{
				"_id": "2758224",
				"_name": "Vélo du soleil"
			},
			{
				"_id": "2569226218",
				"_name": "Vélo splendide"
			},
			{
				"_id": "3995367292",
				"_name": "Vélo sinistre"
			},
			{
				"_id": "1883300575",
				"_name": "Vélo étincelant"
			},
			{
				"_id": "122147401",
				"_name": "Vélo du couchant"
			},
			{
				"_id": "2655945715",
				"_name": "Vélo de la mer"
			},
			{
				"_id": "3913921381",
				"_name": "Vélo des cerisiers"
			},
			{
				"_id": "2046209780",
				"_name": "Vélo sylvestre"
			},
			{
				"_id": "250715746",
				"_name": "Vélo des nuages"
			},
			{
				"_id": "4038408713",
				"_name": "Vélo du soleil"
			},
			{
				"_id": "2276592287",
				"_name": "Vélo splendide"
			},
			{
				"_id": "515595045",
				"_name": "Vélo sinistre"
			},
			{
				"_id": "1773956019",
				"_name": "Vélo étincelant"
			},
			{
				"_id": "2471723833",
				"_name": "Pile ou passe"
			},
			{
				"_id": "561480000",
				"_name": "Super pile ou passe"
			},
			{
				"_id": "2487109408",
				"_name": "Pass journalier"
			},
			{
				"_id": "2049975820",
				"_name": "Pass illimité"
			},
			{
				"_id": "323085250",
				"_name": "Carte à tamponner"
			},
			{
				"_id": "3095318778",
				"_name": "Cahier de vacances"
			},
			{
				"_id": "639255897",
				"_name": "Herbes ancestrales"
			},
			{
				"_id": "1360885199",
				"_name": "Super tournevis"
			},
			{
				"_id": "3356763253",
				"_name": "Beignets farceurs"
			},
			{
				"_id": "3205698787",
				"_name": "Beignets bouffis"
			},
			{
				"_id": "799803762",
				"_name": "Indications de Maman"
			},
			{
				"_id": "1487616484",
				"_name": "Clés de l'école"
			},
			{
				"_id": "2320020088",
				"_name": "Lettre de Komasan"
			},
			{
				"_id": "338438107",
				"_name": "Grelot félin"
			},
			{
				"_id": "1663768397",
				"_name": "Foli-pili"
			},
			{
				"_id": "4196550391",
				"_name": "Montre de luxe"
			},
			{
				"_id": "2368042593",
				"_name": "Bille mystérieuse"
			},
			{
				"_id": "1788697446",
				"_name": "Fiole de ramolline"
			},
			{
				"_id": "1543533829",
				"_name": "Capsules de lait"
			},
			{
				"_id": "721896851",
				"_name": "Cartes d'Ultramax"
			},
			{
				"_id": "3830756271",
				"_name": "Clé de cabane"
			},
			{
				"_id": "221714074",
				"_name": "Mega Watch"
			},
			{
				"_id": "1057059864",
				"_name": "Tuyau"
			},
			{
				"_id": "173724291",
				"_name": "Clé de derrière"
			},
			{
				"_id": "1682363220",
				"_name": "Jolie grande clé"
			},
			{
				"_id": "4249846510",
				"_name": "Jolie petite clé"
			},
			{
				"_id": "3812194230",
				"_name": "Clé du Yo-kai World"
			},
			{
				"_id": "75586225",
				"_name": "Clé terrifiante"
			},
			{
				"_id": "2009767659",
				"_name": "Clé sanglier"
			},
			{
				"_id": "3883238266",
				"_name": "Clé cerf"
			},
			{
				"_id": "1938188839",
				"_name": "Clé papillon"
			},
			{
				"_id": "2103304725",
				"_name": "Huile de Tendino"
			},
			{
				"_id": "3261391014",
				"_name": "Photo Next HarMIAOUny 1"
			},
			{
				"_id": "1390148919",
				"_name": "Photo Next HarMIAOUny 2"
			},
			{
				"_id": "635227553",
				"_name": "Photo Next HarMIAOUny 3"
			},
			{
				"_id": "1159414852",
				"_name": "Photo Next HarMIAOUny 4"
			},
			{
				"_id": "840725714",
				"_name": "Photo Next HarMIAOUny 5"
			},
			{
				"_id": "2870289768",
				"_name": "Photo Next HarMIAOUny 6"
			},
			{
				"_id": "3692172798",
				"_name": "Photo Next HarMIAOUny 7"
			},
			{
				"_id": "1115062365",
				"_name": "Photo Next HarMIAOUny 8"
			},
			{
				"_id": "896643275",
				"_name": "Photo Next HarMIAOUny 9"
			},
			{
				"_id": "2893603185",
				"_name": "Photo N. HarMIAOUny 10"
			},
			{
				"_id": "3682587111",
				"_name": "Dragon Popota"
			},
			{
				"_id": "1270926454",
				"_name": "Clé appartement C-302"
			},
			{
				"_id": "1019739360",
				"_name": "Clé appartement A-201"
			},
			{
				"_id": "1849038727",
				"_name": "Clé appartement A-203"
			},
			{
				"_id": "422651665",
				"_name": "Clé appartement B-102"
			},
			{
				"_id": "2151184043",
				"_name": "Clé appartement B-204"
			},
			{
				"_id": "4148119101",
				"_name": "Clé appartement B-301"
			},
			{
				"_id": "1767625630",
				"_name": "Clé appartement C-101"
			},
			{
				"_id": "509403912",
				"_name": "Clé appartement C-303"
			},
			{
				"_id": "4158193168",
				"_name": "Poster de film"
			},
			{
				"_id": "2162151046",
				"_name": "Tenue de rocker"
			},
			{
				"_id": "433495868",
				"_name": "Silhouette de héros"
			},
			{
				"_id": "1859235754",
				"_name": "Bobine de film"
			},
			{
				"_id": "4268667451",
				"_name": "Affiche de restaurant"
			},
			{
				"_id": "2305393325",
				"_name": "Robe de star"
			},
			{
				"_id": "3920497480",
				"_name": "Louloutre"
			},
			{
				"_id": "2661891038",
				"_name": "Bouteille de Y-Cola"
			},
			{
				"_id": "127953508",
				"_name": "Pot canard"
			},
			{
				"_id": "1890015986",
				"_name": "Figurine de Photortue"
			},
			{
				"_id": "4005810001",
				"_name": "Parchemin En nyavant"
			},
			{
				"_id": "2579824583",
				"_name": "Parchemin de victoire"
			},
			{
				"_id": "13479549",
				"_name": "Parchemin Miahourra"
			},
			{
				"_id": "4158121970",
				"_name": "Gâteau de l'Unité"
			},
			{
				"_id": "1860089416",
				"_name": "Documents perdus"
			},
			{
				"_id": "2277315453",
				"_name": "Glu spectrale"
			},
			{
				"_id": "4038730731",
				"_name": "Clé magnétique rouge"
			},
			{
				"_id": "1773367889",
				"_name": "Clé magnétique bleue"
			},
			{
				"_id": "515130055",
				"_name": "Clé magnétique or"
			},
			{
				"_id": "2383109974",
				"_name": "Ceinture de force"
			},
			{
				"_id": "4178341824",
				"_name": "Épée émoussée"
			},
			{
				"_id": "2580276773",
				"_name": "Robot rétro neuf"
			},
			{
				"_id": "4006401715",
				"_name": "Robot mécanique usé"
			},
			{
				"_id": "2009433865",
				"_name": "Carte au trésor"
			},
			{
				"_id": "12760991",
				"_name": "Carte détrempée"
			},
			{
				"_id": "2661687868",
				"_name": "Carte froissée"
			},
			{
				"_id": "3919647402",
				"_name": "Carte tachée"
			},
			{
				"_id": "1890075408",
				"_name": "Nouvelle carte"
			},
			{
				"_id": "128938886",
				"_name": "Clé salle du trésor"
			},
			{
				"_id": "2534436375",
				"_name": "Carte au trésor finale"
			},
			{
				"_id": "3759627905",
				"_name": "Poignée étrange"
			},
			{
				"_id": "3001464294",
				"_name": "Appareil photo N&B"
			},
			{
				"_id": "3319891312",
				"_name": "Photo d'école"
			},
			{
				"_id": "1558762698",
				"_name": "Photo du boulevard"
			},
			{
				"_id": "737141852",
				"_name": "Photo de Coloq Ness"
			},
			{
				"_id": "3045814783",
				"_name": "Autographe"
			},
			{
				"_id": "3263971689",
				"_name": "Serviette douce"
			},
			{
				"_id": "3848423452",
				"_name": "Peigne pointu"
			},
			{
				"_id": "2087393702",
				"_name": "Dance Revolution"
			},
			{
				"_id": "191637808",
				"_name": "Pass sortilège"
			},
			{
				"_id": "2500377747",
				"_name": "Ticket G. G. Land"
			},
			{
				"_id": "3792669701",
				"_name": "Ticket Bellesource"
			},
			{
				"_id": "2064047551",
				"_name": "Ticket Val Vorace"
			},
			{
				"_id": "201452841",
				"_name": "Pass Bains célest."
			},
			{
				"_id": "2629759160",
				"_name": "Pass Bains cimes"
			},
			{
				"_id": "3954819118",
				"_name": "Pass Bains tertre"
			},
			{
				"_id": "2340309451",
				"_name": "Pass Bains badaud"
			},
			{
				"_id": "4235819357",
				"_name": "Pass Bains bois"
			},
			{
				"_id": "1701849319",
				"_name": "Pass Bains chance"
			},
			{
				"_id": "309794929",
				"_name": "Pass Bains trésor"
			},
			{
				"_id": "2350091730",
				"_name": "Ceinture p.-outils"
			},
			{
				"_id": "4212440388",
				"_name": "Cape clandestinité"
			},
			{
				"_id": "1646128382",
				"_name": "Poignée de frein"
			},
			{
				"_id": "354081896",
				"_name": "Pass Entrain Exp."
			},
			{
				"_id": "2242232825",
				"_name": "Pièce B-k gagnant"
			},
			{
				"_id": "4070764911",
				"_name": "Marque d'Ultramax"
			},
			{
				"_id": "2689800712",
				"_name": "Important Item 20"
			},
			{
				"_id": "3612617374",
				"_name": "Important Item 21"
			},
			{
				"_id": "1314749220",
				"_name": "Important Item 22"
			},
			{
				"_id": "962218930",
				"_name": "Important Item 23"
			},
			{
				"_id": "2805915153",
				"_name": "Important Item 24"
			},
			{
				"_id": "3493457543",
				"_name": "Important Item 25"
			},
			{
				"_id": "3503128323",
				"_name": "Graines de melon"
			},
			{
				"_id": "2815053717",
				"_name": "Graines d'orange"
			},
			{
				"_id": "930435588",
				"_name": "Graines de kiwi"
			},
			{
				"_id": "1081238162",
				"_name": "Graines de raisin"
			},
			{
				"_id": "548793207",
				"_name": "Graines de fraise"
			},
			{
				"_id": "1471339489",
				"_name": "Graines de pastèque"
			},
			{
				"_id": "3468397147",
				"_name": "Rouage de Kappacap"
			},
			{
				"_id": "3116153549",
				"_name": "Rouage de Komasan"
			},
			{
				"_id": "668479342",
				"_name": "Rouage de Granpapéti"
			},
			{
				"_id": "1356799992",
				"_name": "Rouage de Corniot"
			},
			{
				"_id": "3386265154",
				"_name": "Rouage de Noko"
			},
			{
				"_id": "3201400532",
				"_name": "Rouage de Dracounet"
			},
			{
				"_id": "778986309",
				"_name": "Grelot de série F"
			},
			{
				"_id": "1500074963",
				"_name": "Grelot marin"
			},
			{
				"_id": "194558132",
				"_name": "Grelot masqué"
			},
			{
				"_id": "2090829858",
				"_name": "Grelot voyageur"
			},
			{
				"_id": "3851868568",
				"_name": "Grelot aérien"
			},
			{
				"_id": "2459035918",
				"_name": "Paquet spirituel"
			},
			{
				"_id": "217414829",
				"_name": "Capsule favorite"
			},
			{
				"_id": "2079476795",
				"_name": "Grelot gris"
			}
		]
	}
}
