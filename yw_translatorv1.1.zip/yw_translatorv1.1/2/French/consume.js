xmlval = {
	"items": {
		"item": [
			{
				"_id": "2170728737",
				"_name": "Barre de chocolat"
			},
			{
				"_id": "1803927674",
				"_name": "Riz à la prune"
			},
			{
				"_id": "4069298624",
				"_name": "Riz dans feuille"
			},
			{
				"_id": "2240520534",
				"_name": "Riz œufs saumon"
			},
			{
				"_id": "468661493",
				"_name": "Riz à la crevette"
			},
			{
				"_id": "1783081549",
				"_name": "Sandwich"
			},
			{
				"_id": "4082039799",
				"_name": "Patte d'ours"
			},
			{
				"_id": "1831497300",
				"_name": "Pain au curry"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Blablagel"
			},
			{
				"_id": "1744901140",
				"_name": "Chewing-gum"
			},
			{
				"_id": "4043851182",
				"_name": "Bonb. poisseux"
			},
			{
				"_id": "2249159992",
				"_name": "Chips géante"
			},
			{
				"_id": "409723035",
				"_name": "Bonbons fruits"
			},
			{
				"_id": "1869402125",
				"_name": "Granité"
			},
			{
				"_id": "4133847479",
				"_name": "Pomme d'amour"
			},
			{
				"_id": "1774419491",
				"_name": "Lait"
			},
			{
				"_id": "4039782297",
				"_name": "Café au lait"
			},
			{
				"_id": "2278366991",
				"_name": "Lait aux fruits"
			},
			{
				"_id": "430541484",
				"_name": "Lait merveilleux"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Thé de l'âme"
			},
			{
				"_id": "2189560202",
				"_name": "Spiritizer Y"
			},
			{
				"_id": "484875305",
				"_name": "VoltXtrême"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Double burger"
			},
			{
				"_id": "488961566",
				"_name": "Burger Miam"
			},
			{
				"_id": "1858787071",
				"_name": "Ramen minute"
			},
			{
				"_id": "4156786501",
				"_name": "Ramen au poulet"
			},
			{
				"_id": "2160375763",
				"_name": "Ramen deluxe"
			},
			{
				"_id": "513811056",
				"_name": "Ramen complets"
			},
			{
				"_id": "1704366530",
				"_name": "Maki concombre"
			},
			{
				"_id": "4238327928",
				"_name": "Sushi crevette"
			},
			{
				"_id": "2342056174",
				"_name": "Sushi au saumon"
			},
			{
				"_id": "368862541",
				"_name": "Sushi thon rouge"
			},
			{
				"_id": "1683291125",
				"_name": "Raviolis chinois"
			},
			{
				"_id": "4250774095",
				"_name": "Foie à l'oignon"
			},
			{
				"_id": "2321193689",
				"_name": "Omelette crabe"
			},
			{
				"_id": "339611514",
				"_name": "Crevette piment"
			},
			{
				"_id": "1664696300",
				"_name": "Ragoût de tofu"
			},
			{
				"_id": "3539717416",
				"_name": "Carotte"
			},
			{
				"_id": "1274190994",
				"_name": "Concombre"
			},
			{
				"_id": "1022733316",
				"_name": "Pousse bambou"
			},
			{
				"_id": "2727426471",
				"_name": "Matsutake"
			},
			{
				"_id": "3502076785",
				"_name": "Cuisse de poulet"
			},
			{
				"_id": "1236542155",
				"_name": "Morceau de lard"
			},
			{
				"_id": "1051923037",
				"_name": "Langue de bœuf"
			},
			{
				"_id": "2698479614",
				"_name": "Bœuf persillé"
			},
			{
				"_id": "3514767686",
				"_name": "Maquereau séché"
			},
			{
				"_id": "1215711484",
				"_name": "Sériole"
			},
			{
				"_id": "1064401002",
				"_name": "Oursin cru"
			},
			{
				"_id": "2702568905",
				"_name": "Thon 1er choix"
			},
			{
				"_id": "3559919555",
				"_name": "Curry de poulet"
			},
			{
				"_id": "1295605369",
				"_name": "Curry d'agneau"
			},
			{
				"_id": "977170159",
				"_name": "Curry de la mer"
			},
			{
				"_id": "2757425996",
				"_name": "Curry du chef"
			},
			{
				"_id": "3546139610",
				"_name": "Curry de légumes"
			},
			{
				"_id": "3589432820",
				"_name": "Cheesecake"
			},
			{
				"_id": "1291531342",
				"_name": "Fraisier"
			},
			{
				"_id": "1006372056",
				"_name": "Crêpes nappées"
			},
			{
				"_id": "2778239355",
				"_name": "Grande coupe glac."
			},
			{
				"_id": "3533677037",
				"_name": "Galette riz sucrée"
			},
			{
				"_id": "1268183127",
				"_name": "Beignet farceur"
			},
			{
				"_id": "1016185025",
				"_name": "Beignet bouffi"
			},
			{
				"_id": "3618954157",
				"_name": "Daikon à la vapeur"
			},
			{
				"_id": "1321044503",
				"_name": "Œuf à la coque"
			},
			{
				"_id": "968538753",
				"_name": "Brochettes bœuf"
			},
			{
				"_id": "2816356130",
				"_name": "Oden de luxe"
			},
			{
				"_id": "3598102938",
				"_name": "Nouilles soba"
			},
			{
				"_id": "3710580391",
				"_name": "Chips"
			},
			{
				"_id": "1143187229",
				"_name": "Grignotes"
			},
			{
				"_id": "858036107",
				"_name": "Nachos au fromage"
			},
			{
				"_id": "2906653224",
				"_name": "Petits pois neige"
			},
			{
				"_id": "2370076515",
				"_name": "Mini EXPorbe"
			},
			{
				"_id": "320924352",
				"_name": "Petit EXPorbe"
			},
			{
				"_id": "2317990778",
				"_name": "EXPorbe moyen"
			},
			{
				"_id": "4247686124",
				"_name": "Grand EXPorbe"
			},
			{
				"_id": "1665801807",
				"_name": "Méga EXPorbe"
			},
			{
				"_id": "340602585",
				"_name": "EXPorbe sacré"
			},
			{
				"_id": "397252210",
				"_name": "Staminum"
			},
			{
				"_id": "2393163720",
				"_name": "Staminum Alpha"
			},
			{
				"_id": "279199406",
				"_name": "Coups secrets"
			},
			{
				"_id": "2309844756",
				"_name": "Tech. tip-top"
			},
			{
				"_id": "4272578434",
				"_name": "Secrets de l'âme"
			},
			{
				"_id": "469268883",
				"_name": "La vie en tête"
			},
			{
				"_id": "2196842537",
				"_name": "Pensez Karaté"
			},
			{
				"_id": "4126546111",
				"_name": "Vivez Karaté"
			},
			{
				"_id": "1804766492",
				"_name": "Dico-tech"
			},
			{
				"_id": "479575434",
				"_name": "Techni-clopédie"
			},
			{
				"_id": "2241653808",
				"_name": "La déf. de A à Z"
			},
			{
				"_id": "4070300838",
				"_name": "Tout sur la déf."
			},
			{
				"_id": "1646575927",
				"_name": "Docteur Tit'ange"
			},
			{
				"_id": "354677153",
				"_name": "Au rev., Tit'ange"
			},
			{
				"_id": "1977907268",
				"_name": "Petite teigne"
			},
			{
				"_id": "48449746",
				"_name": "Teigne parfaite"
			},
			{
				"_id": "2615810408",
				"_name": "Secours mag #7"
			},
			{
				"_id": "3974965758",
				"_name": "Sec. hors-série"
			},
			{
				"_id": "367732779",
				"_name": "Talisman de force"
			},
			{
				"_id": "2363652497",
				"_name": "Talisman d'esprit"
			},
			{
				"_id": "4226107655",
				"_name": "Talisman de déf."
			},
			{
				"_id": "1703009444",
				"_name": "Talisman de vitesse"
			},
			{
				"_id": "338248220",
				"_name": "Remède infect"
			},
			{
				"_id": "2367689638",
				"_name": "Remède amer"
			},
			{
				"_id": "4196868912",
				"_name": "Remède puiss."
			},
			{
				"_id": "376437829",
				"_name": "Poupée de fuite"
			},
			{
				"_id": "1628217366",
				"_name": "Poupée de fer"
			},
			{
				"_id": "291919001",
				"_name": "Poupée bronze"
			},
			{
				"_id": "2288977187",
				"_name": "Poupée d'argent"
			},
			{
				"_id": "4285019573",
				"_name": "Poupée d'or"
			},
			{
				"_id": "369856640",
				"_name": "Poupée de platine"
			},
			{
				"_id": "2908180302",
				"_name": "Appât poissons"
			},
			{
				"_id": "878583540",
				"_name": "Mélasse"
			},
			{
				"_id": "2895455609",
				"_name": "Étoile dansante"
			},
			{
				"_id": "899445955",
				"_name": "Billet de loterie"
			},
			{
				"_id": "1117471829",
				"_name": "Carte cadeau musique"
			},
			{
				"_id": "1535145236",
				"_name": "Étiquette de bronze"
			},
			{
				"_id": "3320111287",
				"_name": "Étiquette d'argent"
			},
			{
				"_id": "3001274401",
				"_name": "Étiquette d'or"
			},
			{
				"_id": "747062658",
				"_name": "Essence maléfique"
			},
			{
				"_id": "440013732",
				"_name": "Épée légendaire"
			},
			{
				"_id": "2201174558",
				"_name": "Épée maudite"
			},
			{
				"_id": "2220787207",
				"_name": "Épée sacrée"
			},
			{
				"_id": "4097077896",
				"_name": "Âme du général"
			},
			{
				"_id": "1783686955",
				"_name": "Six-coups foudre"
			},
			{
				"_id": "492296125",
				"_name": "Orbe GHz"
			},
			{
				"_id": "1676061440",
				"_name": "Âme imbattable"
			},
			{
				"_id": "2586342239",
				"_name": "Lingot de platine"
			},
			{
				"_id": "350329750",
				"_name": "Cape de blizzard"
			},
			{
				"_id": "1948652147",
				"_name": "Sceptre d'amour"
			},
			{
				"_id": "4082742929",
				"_name": "Pince de glace"
			},
			{
				"_id": "52503269",
				"_name": "Poids"
			},
			{
				"_id": "1934349930",
				"_name": "Éclat démon."
			},
			{
				"_id": "3979297737",
				"_name": "Poudre jouvence"
			},
			{
				"_id": "2638591814",
				"_name": "Orbe de dragon"
			},
			{
				"_id": "1098757352",
				"_name": "Sabre déchaîné"
			},
			{
				"_id": "913998974",
				"_name": "Costume sable"
			},
			{
				"_id": "2943604164",
				"_name": "Eau d'outre-monde"
			},
			{
				"_id": "3631539538",
				"_name": "Revue maudite"
			},
			{
				"_id": "1221327043",
				"_name": "Assourdisseur"
			},
			{
				"_id": "1070385237",
				"_name": "Amnéspirateur"
			},
			{
				"_id": "156362294",
				"_name": "Perle de sirène"
			},
			{
				"_id": "1771466707",
				"_name": "Riz plein d'amour"
			},
			{
				"_id": "2119620256",
				"_name": "Grelot brisé"
			},
			{
				"_id": "2033914553",
				"_name": "Couteau ébréché"
			},
			{
				"_id": "3761390339",
				"_name": "Aiguisoir brut"
			},
			{
				"_id": "2536862613",
				"_name": "Aiguisoir sinistre"
			},
			{
				"_id": "126512644",
				"_name": "Aiguisoir sublime"
			},
			{
				"_id": "273340279",
				"_name": "Sculpture d'ours"
			},
			{
				"_id": "1733158881",
				"_name": "Lanterne carassin"
			},
			{
				"_id": "4265915995",
				"_name": "Lanterne du maître"
			},
			{
				"_id": "2302904013",
				"_name": "Emblème d'or"
			},
			{
				"_id": "388436846",
				"_name": "Moule à takoyaki"
			},
			{
				"_id": "1612719096",
				"_name": "Sable des dunes"
			},
			{
				"_id": "4180243010",
				"_name": "Chapeau de paille"
			},
			{
				"_id": "2385396436",
				"_name": "Statue de terre cuite"
			},
			{
				"_id": "512843589",
				"_name": "Hibiscus rouge"
			},
			{
				"_id": "3881797402",
				"_name": "Herbe médicinale"
			},
			{
				"_id": "2421733260",
				"_name": "Herbe fétide"
			},
			{
				"_id": "238821935",
				"_name": "Herbe amère"
			},
			{
				"_id": "2592718716",
				"_name": "Pièce rouge"
			},
			{
				"_id": "58781382",
				"_name": "Pièce jaune"
			},
			{
				"_id": "1955061328",
				"_name": "Pièce orange"
			},
			{
				"_id": "3940764659",
				"_name": "Pièce rose"
			},
			{
				"_id": "2648996709",
				"_name": "Pièce verte"
			},
			{
				"_id": "82651871",
				"_name": "Pièce bleue"
			},
			{
				"_id": "1944721993",
				"_name": "Pièce mauve"
			},
			{
				"_id": "3814000600",
				"_name": "Pièce bleu ciel"
			},
			{
				"_id": "3411442988",
				"_name": "Pièce 5 étoiles"
			},
			{
				"_id": "1542021309",
				"_name": "Pièce spéciale"
			},
			{
				"_id": "753815595",
				"_name": "Pièce mystère (Yo)"
			},
			{
				"_id": "1277811150",
				"_name": "Pièce mystère (Kai)"
			},
			{
				"_id": "992930136",
				"_name": "Pièce mystère (Invo)"
			},
			{
				"_id": "2720512226",
				"_name": "Pièce mystère (Quer)"
			},
			{
				"_id": "905273706",
				"_name": "Pièce frisson (fleur)"
			},
			{
				"_id": "1728350733",
				"_name": "Pièce frisson (oiseau)"
			},
			{
				"_id": "268679835",
				"_name": "Pièce frisson (vent)"
			},
			{
				"_id": "2299194145",
				"_name": "Pièce frisson (lune)"
			},
			{
				"_id": "4262321079",
				"_name": "Pièce clinquante"
			},
			{
				"_id": "1617514004",
				"_name": "Pièce du nord"
			},
			{
				"_id": "393117314",
				"_name": "Pièce du nordet"
			},
			{
				"_id": "2389126968",
				"_name": "Pièce du levant"
			},
			{
				"_id": "4183826350",
				"_name": "Pièce du centre"
			},
			{
				"_id": "1776222783",
				"_name": "Pièce du ponant"
			},
			{
				"_id": "517485225",
				"_name": "Pièce des montagnes"
			},
			{
				"_id": "2116008780",
				"_name": "Pièce du sud"
			},
			{
				"_id": "152603610",
				"_name": "Pièce du centre-ouest"
			},
			{
				"_id": "2417089120",
				"_name": "Pièce des îles"
			},
			{
				"_id": "3877038838",
				"_name": "Pièce mystère"
			},
			{
				"_id": "2037546837",
				"_name": "Pièce mys. (sanglier)"
			},
			{
				"_id": "242569155",
				"_name": "Pièce mystère (cerf)"
			},
			{
				"_id": "2541493881",
				"_name": "Pièce mys. (papillon)"
			},
			{
				"_id": "3766169327",
				"_name": "Pièce joyeuse"
			},
			{
				"_id": "3707752950",
				"_name": "Éclat de pièce rouge"
			},
			{
				"_id": "2885214560",
				"_name": "Éclat de pièce jaune"
			},
			{
				"_id": "854700250",
				"_name": "Éclat de pièce orange"
			},
			{
				"_id": "1173782604",
				"_name": "Éclat de pièce rose"
			},
			{
				"_id": "3578371549",
				"_name": "Éclat de pièce verte"
			},
			{
				"_id": "2723065163",
				"_name": "Éclat de pièce bleue"
			},
			{
				"_id": "3263767726",
				"_name": "Éclat de pièce mauve"
			},
			{
				"_id": "3045987384",
				"_name": "Éclat de pièce ciel"
			},
			{
				"_id": "1200047969",
				"_name": "Boîte rouge"
			},
			{
				"_id": "1178938710",
				"_name": "Globe de portail"
			},
			{
				"_id": "2285637778",
				"_name": "Orbe Noko"
			},
			{
				"_id": "288702760",
				"_name": "Orbe Kyubi"
			}
		]
	}
}
