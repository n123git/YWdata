xmlval = {
	"items": {
		"item": [
			{
				"_id": "1",
				"_name": "grognon"
			},
			{
				"_id": "2",
				"_name": "logique"
			},
			{
				"_id": "3",
				"_name": "prudent"
			},
			{
				"_id": "4",
				"_name": "gentil"
			},
			{
				"_id": "5",
				"_name": "bizarre"
			},
			{
				"_id": "6",
				"_name": "altruiste"
			},
			{
				"_id": "7",
				"_name": "dur"
			},
			{
				"_id": "8",
				"_name": "futé"
			},
			{
				"_id": "9",
				"_name": "calme"
			},
			{
				"_id": "10",
				"_name": "tendre"
			},
			{
				"_id": "11",
				"_name": "cruel"
			},
			{
				"_id": "12",
				"_name": "dévoué"
			}
		]
	}
}