xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Pulsera gastada"
			},
			{
				"_id": "3681894277",
				"_name": "Pulsera barata"
			},
			{
				"_id": "3692624796",
				"_name": "Pulsera punki"
			},
			{
				"_id": "2893156115",
				"_name": "Pulsera de fuego"
			},
			{
				"_id": "2870987530",
				"_name": "Pulsera de pinchos"
			},
			{
				"_id": "1020072578",
				"_name": "Pulsera excelente"
			},
			{
				"_id": "897277609",
				"_name": "Pulsera de sol"
			},
			{
				"_id": "1271538196",
				"_name": "Pulsera cometa"
			},
			{
				"_id": "1115450943",
				"_name": "Pulsera maléfica"
			},
			{
				"_id": "722316273",
				"_name": "Pulsera legendaria"
			},
			{
				"_id": "1154727953",
				"_name": "Anillo oxidado"
			},
			{
				"_id": "3669448114",
				"_name": "Anillo feo"
			},
			{
				"_id": "3722088875",
				"_name": "Anillo precioso"
			},
			{
				"_id": "2914018596",
				"_name": "Anillo arcoíris"
			},
			{
				"_id": "2866651453",
				"_name": "Anillo mágico"
			},
			{
				"_id": "1024424117",
				"_name": "Anillo de hada"
			},
			{
				"_id": "884552862",
				"_name": "Anillo lunar"
			},
			{
				"_id": "1242056739",
				"_name": "Anillo del destino"
			},
			{
				"_id": "1136526344",
				"_name": "Anillo maléfico"
			},
			{
				"_id": "718258630",
				"_name": "Anillo legendario"
			},
			{
				"_id": "1184202312",
				"_name": "Amuleto antiguo"
			},
			{
				"_id": "3639733227",
				"_name": "Amuleto vetusto"
			},
			{
				"_id": "3751555058",
				"_name": "Amuleto rúnico"
			},
			{
				"_id": "2952190845",
				"_name": "Amuleto protector"
			},
			{
				"_id": "2828738404",
				"_name": "Amuleto blindado"
			},
			{
				"_id": "1061799660",
				"_name": "Amuleto suerte"
			},
			{
				"_id": "922716871",
				"_name": "Amuleto galáctico"
			},
			{
				"_id": "1213134458",
				"_name": "Amuleto de tierra"
			},
			{
				"_id": "1106819665",
				"_name": "Amuleto maléfico"
			},
			{
				"_id": "680099743",
				"_name": "Amuleto legend."
			},
			{
				"_id": "1196889215",
				"_name": "Insignia sencilla"
			},
			{
				"_id": "3644031452",
				"_name": "Insignia negra"
			},
			{
				"_id": "3730720197",
				"_name": "Insignia brillante"
			},
			{
				"_id": "2922688842",
				"_name": "Insignia cuqui"
			},
			{
				"_id": "2841212243",
				"_name": "Insignia de Hermes"
			},
			{
				"_id": "1049341147",
				"_name": "Insignia aurora"
			},
			{
				"_id": "926802160",
				"_name": "Insignia meteórica"
			},
			{
				"_id": "1233951821",
				"_name": "Insignia del rayo"
			},
			{
				"_id": "1077596262",
				"_name": "Insignia maléfica"
			},
			{
				"_id": "692786600",
				"_name": "Insignia legendaria"
			},
			{
				"_id": "1108869882",
				"_name": "Espada cigarrera"
			},
			{
				"_id": "3675345728",
				"_name": "Campanilla fuerza"
			},
			{
				"_id": "2887148502",
				"_name": "Camp. hechicera"
			},
			{
				"_id": "846394997",
				"_name": "Campanilla dura"
			},
			{
				"_id": "1165346531",
				"_name": "Campanilla veloz"
			},
			{
				"_id": "3699152729",
				"_name": "Termo infinito"
			},
			{
				"_id": "2877007823",
				"_name": "Abanico Tengu"
			},
			{
				"_id": "1002748510",
				"_name": "Abrigo alegre"
			},
			{
				"_id": "1287883464",
				"_name": "Bate con pinchos"
			},
			{
				"_id": "1550776226",
				"_name": "Baquetas"
			},
			{
				"_id": "3311904280",
				"_name": "Robovitamina E"
			},
			{
				"_id": "2992674446",
				"_name": "Pulsera Capi"
			},
			{
				"_id": "585075487",
				"_name": "Cascabel recuerdo"
			},
			{
				"_id": "3037549207",
				"_name": "Tira Fantasqueletos"
			},
			{
				"_id": "728352564",
				"_name": "Tira Carnánimas"
			},
			{
				"_id": "738460461",
				"_name": "Espada reversible"
			},
			{
				"_id": "1526936507",
				"_name": "Tornador"
			},
			{
				"_id": "3255460353",
				"_name": "Reflectante"
			},
			{
				"_id": "1440267145",
				"_name": "Esfera paradisiaca"
			},
			{
				"_id": "1138387149",
				"_name": "Carta siniestra"
			},
			{
				"_id": "3671275895",
				"_name": "Hoja maldita"
			},
			{
				"_id": "2916354529",
				"_name": "Cetro maldito"
			},
			{
				"_id": "867212354",
				"_name": "Escudo maldito"
			},
			{
				"_id": "1152888020",
				"_name": "Toga maldita"
			},
			{
				"_id": "1100797588",
				"_name": "Cinturón control"
			},
			{
				"_id": "2945628088",
				"_name": "Diadema simio"
			},
			{
				"_id": "4256025923",
				"_name": "Medalla de general"
			},
			{
				"_id": "1688509689",
				"_name": "Medalla de coronel"
			},
			{
				"_id": "329493615",
				"_name": "Medalla de capitán"
			},
			{
				"_id": "2378643916",
				"_name": "Medalla teniente"
			},
			{
				"_id": "4206889306",
				"_name": "Medalla de alférez"
			},
			{
				"_id": "1674139872",
				"_name": "Medalla de brigada"
			},
			{
				"_id": "349071478",
				"_name": "Medalla sargento"
			},
			{
				"_id": "2222028263",
				"_name": "Medalla de cabo"
			}
		]
	}
}
