xmlval = {
	"items": {
		"item": [
			{
				"_id": "2170728737",
				"_name": "Chocobarrita"
			},
			{
				"_id": "1803927674",
				"_name": "Arroz con ciruelas"
			},
			{
				"_id": "4069298624",
				"_name": "Arroz en col"
			},
			{
				"_id": "2240520534",
				"_name": "Arroz con huevas"
			},
			{
				"_id": "468661493",
				"_name": "Arroz con gambas"
			},
			{
				"_id": "1783081549",
				"_name": "Sándwich"
			},
			{
				"_id": "4082039799",
				"_name": "Bollo con crema"
			},
			{
				"_id": "1831497300",
				"_name": "Pan de curry"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Rosca lenguaraz"
			},
			{
				"_id": "1744901140",
				"_name": "Chicle de 10"
			},
			{
				"_id": "4043851182",
				"_name": "Caramelo pegajoso"
			},
			{
				"_id": "2249159992",
				"_name": "Galleta gigante"
			},
			{
				"_id": "409723035",
				"_name": "Caram. de frutas"
			},
			{
				"_id": "1869402125",
				"_name": "Helado granizado"
			},
			{
				"_id": "4133847479",
				"_name": "Manz. caramelo"
			},
			{
				"_id": "1774419491",
				"_name": "Leche"
			},
			{
				"_id": "4039782297",
				"_name": "Café con leche"
			},
			{
				"_id": "2278366991",
				"_name": "Leche de frutas"
			},
			{
				"_id": "430541484",
				"_name": "Leche fresca"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Té relajante"
			},
			{
				"_id": "2189560202",
				"_name": "Insomnia Y"
			},
			{
				"_id": "484875305",
				"_name": "Energicina"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburguesa"
			},
			{
				"_id": "4098315051",
				"_name": "Hambur. queso"
			},
			{
				"_id": "2202035133",
				"_name": "Hambur. doble"
			},
			{
				"_id": "488961566",
				"_name": "Hamburguesa Ñam"
			},
			{
				"_id": "1858787071",
				"_name": "Vaso de ramen"
			},
			{
				"_id": "4156786501",
				"_name": "Ramen con cerdo"
			},
			{
				"_id": "2160375763",
				"_name": "Ramen deluxe"
			},
			{
				"_id": "513811056",
				"_name": "Ramen completo"
			},
			{
				"_id": "1704366530",
				"_name": "Maki de pepino"
			},
			{
				"_id": "4238327928",
				"_name": "Nigiri de gamba"
			},
			{
				"_id": "2342056174",
				"_name": "Maki de huevas"
			},
			{
				"_id": "368862541",
				"_name": "Nigiri de atún"
			},
			{
				"_id": "1683291125",
				"_name": "Empanad. chinas"
			},
			{
				"_id": "4250774095",
				"_name": "Hígado cebollino"
			},
			{
				"_id": "2321193689",
				"_name": "Tortilla de cangrejo"
			},
			{
				"_id": "339611514",
				"_name": "Gambas picantes"
			},
			{
				"_id": "1664696300",
				"_name": "Tofu con carne"
			},
			{
				"_id": "3539717416",
				"_name": "Zanahoria"
			},
			{
				"_id": "1274190994",
				"_name": "Pepino"
			},
			{
				"_id": "1022733316",
				"_name": "Brote de bambú"
			},
			{
				"_id": "2727426471",
				"_name": "Seta japonesa"
			},
			{
				"_id": "3502076785",
				"_name": "Muslo de pollo"
			},
			{
				"_id": "1236542155",
				"_name": "Panceta"
			},
			{
				"_id": "1051923037",
				"_name": "Lengua de vaca"
			},
			{
				"_id": "2698479614",
				"_name": "Carne veteada"
			},
			{
				"_id": "3514767686",
				"_name": "Caballa en salazón"
			},
			{
				"_id": "1215711484",
				"_name": "Jurel"
			},
			{
				"_id": "1064401002",
				"_name": "Erizo fresco"
			},
			{
				"_id": "2702568905",
				"_name": "Atún selecto"
			},
			{
				"_id": "3559919555",
				"_name": "Curry de pollo"
			},
			{
				"_id": "1295605369",
				"_name": "Curry de cordero"
			},
			{
				"_id": "977170159",
				"_name": "Curry de marisco"
			},
			{
				"_id": "2757425996",
				"_name": "Curry mixto"
			},
			{
				"_id": "3546139610",
				"_name": "Curry de verduras"
			},
			{
				"_id": "3589432820",
				"_name": "Tarta de queso"
			},
			{
				"_id": "1291531342",
				"_name": "Tarta de fresa"
			},
			{
				"_id": "1006372056",
				"_name": "Tortitas"
			},
			{
				"_id": "2778239355",
				"_name": "Helado con frutas"
			},
			{
				"_id": "3533677037",
				"_name": "Dulce de arroz"
			},
			{
				"_id": "1268183127",
				"_name": "Fantasquebollo"
			},
			{
				"_id": "1016185025",
				"_name": "Carnanibollo"
			},
			{
				"_id": "3618954157",
				"_name": "Daikon al vapor"
			},
			{
				"_id": "1321044503",
				"_name": "Huevo cocido"
			},
			{
				"_id": "968538753",
				"_name": "Brochetas carne"
			},
			{
				"_id": "2816356130",
				"_name": "Caldo completo"
			},
			{
				"_id": "3598102938",
				"_name": "Fideos sarracenos"
			},
			{
				"_id": "3710580391",
				"_name": "Patatas fritas"
			},
			{
				"_id": "1143187229",
				"_name": "Saladitos"
			},
			{
				"_id": "858036107",
				"_name": "Palomitas de queso"
			},
			{
				"_id": "2906653224",
				"_name": "Guisantes aperitivo"
			},
			{
				"_id": "2370076515",
				"_name": "Exporbe mini"
			},
			{
				"_id": "320924352",
				"_name": "Exporbe S"
			},
			{
				"_id": "2317990778",
				"_name": "Exporbe M"
			},
			{
				"_id": "4247686124",
				"_name": "Exporbe L"
			},
			{
				"_id": "1665801807",
				"_name": "Exporbe XL"
			},
			{
				"_id": "340602585",
				"_name": "Exporbe sagrado"
			},
			{
				"_id": "397252210",
				"_name": "Resistina"
			},
			{
				"_id": "2393163720",
				"_name": "Resistina Alfa"
			},
			{
				"_id": "279199406",
				"_name": "Golpes secretos"
			},
			{
				"_id": "2309844756",
				"_name": "Técnicas a tope"
			},
			{
				"_id": "4272578434",
				"_name": "Secretos del alma"
			},
			{
				"_id": "469268883",
				"_name": "Date vida"
			},
			{
				"_id": "2196842537",
				"_name": "Kárate va"
			},
			{
				"_id": "4126546111",
				"_name": "Kárate doy"
			},
			{
				"_id": "1804766492",
				"_name": "Tecnicedario"
			},
			{
				"_id": "479575434",
				"_name": "Tecnipedia"
			},
			{
				"_id": "2241653808",
				"_name": "En guardia"
			},
			{
				"_id": "4070300838",
				"_name": "Defensa gloriosa"
			},
			{
				"_id": "1646575927",
				"_name": "Ángel sanador"
			},
			{
				"_id": "354677153",
				"_name": "Adiós, angelito"
			},
			{
				"_id": "1977907268",
				"_name": "Cansino y paz"
			},
			{
				"_id": "48449746",
				"_name": "Código Cansino"
			},
			{
				"_id": "2615810408",
				"_name": "Cooperar hoy n.º 7"
			},
			{
				"_id": "3974965758",
				"_name": "Especial Cooperar"
			},
			{
				"_id": "367732779",
				"_name": "Talismán de fuerza"
			},
			{
				"_id": "2363652497",
				"_name": "Talismán espíritu"
			},
			{
				"_id": "4226107655",
				"_name": "Talism. defensa"
			},
			{
				"_id": "1703009444",
				"_name": "Talismán veloz"
			},
			{
				"_id": "338248220",
				"_name": "Medi. asquerosa"
			},
			{
				"_id": "2367689638",
				"_name": "Medicina amarga"
			},
			{
				"_id": "4196868912",
				"_name": "Medicina increíble"
			},
			{
				"_id": "376437829",
				"_name": "Muñeco de trapo"
			},
			{
				"_id": "1628217366",
				"_name": "Muñeco de hierro"
			},
			{
				"_id": "291919001",
				"_name": "Muñeco de bronce"
			},
			{
				"_id": "2288977187",
				"_name": "Muñeco de plata"
			},
			{
				"_id": "4285019573",
				"_name": "Muñeco de oro"
			},
			{
				"_id": "369856640",
				"_name": "Muñeco de platino"
			},
			{
				"_id": "2908180302",
				"_name": "Cebo para peces"
			},
			{
				"_id": "878583540",
				"_name": "Sirope negro"
			},
			{
				"_id": "2895455609",
				"_name": "Estrella brillante"
			},
			{
				"_id": "899445955",
				"_name": "Billete de lotería"
			},
			{
				"_id": "1117471829",
				"_name": "Tarjeta musical"
			},
			{
				"_id": "1535145236",
				"_name": "Etiqueta de bronce"
			},
			{
				"_id": "3320111287",
				"_name": "Etiqueta de plata"
			},
			{
				"_id": "3001274401",
				"_name": "Etiqueta de oro"
			},
			{
				"_id": "747062658",
				"_name": "Esencia del mal"
			},
			{
				"_id": "440013732",
				"_name": "Espada legendaria"
			},
			{
				"_id": "2201174558",
				"_name": "Espada maldita"
			},
			{
				"_id": "2220787207",
				"_name": "Espada sagrada"
			},
			{
				"_id": "4097077896",
				"_name": "Alma de general"
			},
			{
				"_id": "1783686955",
				"_name": "Poten. de amor"
			},
			{
				"_id": "492296125",
				"_name": "Orbe eléctrico"
			},
			{
				"_id": "1676061440",
				"_name": "Alma invencible"
			},
			{
				"_id": "2586342239",
				"_name": "Lingote de platino"
			},
			{
				"_id": "350329750",
				"_name": "Capa de ventisca"
			},
			{
				"_id": "1948652147",
				"_name": "Cetro del amor"
			},
			{
				"_id": "4082742929",
				"_name": "Horquilla glacial"
			},
			{
				"_id": "52503269",
				"_name": "Pesas pesadas"
			},
			{
				"_id": "1934349930",
				"_name": "Esquirla del mal"
			},
			{
				"_id": "3979297737",
				"_name": "Polvos antiedad"
			},
			{
				"_id": "2638591814",
				"_name": "Orbe del dragón"
			},
			{
				"_id": "1098757352",
				"_name": "Espada iracunda"
			},
			{
				"_id": "913998974",
				"_name": "Traje caqui"
			},
			{
				"_id": "2943604164",
				"_name": "Agua sobrenatural"
			},
			{
				"_id": "3631539538",
				"_name": "Diario maldito"
			},
			{
				"_id": "1221327043",
				"_name": "Bocina"
			},
			{
				"_id": "1070385237",
				"_name": "Aspiramemorias"
			},
			{
				"_id": "156362294",
				"_name": "Perla de sirena"
			},
			{
				"_id": "1771466707",
				"_name": "Arroz del amor"
			},
			{
				"_id": "2119620256",
				"_name": "Cascabel roto"
			},
			{
				"_id": "2033914553",
				"_name": "Espada maltrecha"
			},
			{
				"_id": "3761390339",
				"_name": "Afilador duro"
			},
			{
				"_id": "2536862613",
				"_name": "Afilador siniestro"
			},
			{
				"_id": "126512644",
				"_name": "Afilador sublime"
			},
			{
				"_id": "273340279",
				"_name": "Oso tallado"
			},
			{
				"_id": "1733158881",
				"_name": "Farolillo de pez"
			},
			{
				"_id": "4265915995",
				"_name": "Farolillo del maestro"
			},
			{
				"_id": "2302904013",
				"_name": "Emblema dorado"
			},
			{
				"_id": "388436846",
				"_name": "Plancha takoyaki"
			},
			{
				"_id": "1612719096",
				"_name": "Arena de duna"
			},
			{
				"_id": "4180243010",
				"_name": "Sombrero oriental"
			},
			{
				"_id": "2385396436",
				"_name": "Figura de terracota"
			},
			{
				"_id": "512843589",
				"_name": "Hibisco rojo"
			},
			{
				"_id": "3881797402",
				"_name": "Hierba curativa"
			},
			{
				"_id": "2421733260",
				"_name": "Hierba apestosa"
			},
			{
				"_id": "238821935",
				"_name": "Hierba amarga"
			},
			{
				"_id": "2592718716",
				"_name": "Moneda roja"
			},
			{
				"_id": "58781382",
				"_name": "Moneda amarilla"
			},
			{
				"_id": "1955061328",
				"_name": "Moneda naranja"
			},
			{
				"_id": "3940764659",
				"_name": "Moneda rosa"
			},
			{
				"_id": "2648996709",
				"_name": "Moneda verde"
			},
			{
				"_id": "82651871",
				"_name": "Moneda azul"
			},
			{
				"_id": "1944721993",
				"_name": "Moneda morada"
			},
			{
				"_id": "3814000600",
				"_name": "Moneda turquesa"
			},
			{
				"_id": "3411442988",
				"_name": "Moneda 5 estrellas"
			},
			{
				"_id": "1542021309",
				"_name": "Moneda especial"
			},
			{
				"_id": "753815595",
				"_name": "Moneda mister. (Yo)"
			},
			{
				"_id": "1277811150",
				"_name": "Moneda mister. (Kai)"
			},
			{
				"_id": "992930136",
				"_name": "Moneda mister. (in)"
			},
			{
				"_id": "2720512226",
				"_name": "Moneda mister. (vocar)"
			},
			{
				"_id": "905273706",
				"_name": "Moneda emoc. (flor)"
			},
			{
				"_id": "1728350733",
				"_name": "Moneda emoc. (pájaro)"
			},
			{
				"_id": "268679835",
				"_name": "Moneda emoc. (viento)"
			},
			{
				"_id": "2299194145",
				"_name": "Moneda emoc. (luna)"
			},
			{
				"_id": "4262321079",
				"_name": "Moneda ostentosa"
			},
			{
				"_id": "1617514004",
				"_name": "Moneda norte"
			},
			{
				"_id": "393117314",
				"_name": "Moneda noreste"
			},
			{
				"_id": "2389126968",
				"_name": "Moneda este"
			},
			{
				"_id": "4183826350",
				"_name": "Moneda centro"
			},
			{
				"_id": "1776222783",
				"_name": "Moneda oeste"
			},
			{
				"_id": "517485225",
				"_name": "Moneda montaña"
			},
			{
				"_id": "2116008780",
				"_name": "Moneda sur"
			},
			{
				"_id": "152603610",
				"_name": "Mon. centro occidental"
			},
			{
				"_id": "2417089120",
				"_name": "Moneda isla"
			},
			{
				"_id": "3877038838",
				"_name": "Moneda misterio"
			},
			{
				"_id": "2037546837",
				"_name": "Moneda mist. (jabalí)"
			},
			{
				"_id": "242569155",
				"_name": "Moneda mist. (ciervo)"
			},
			{
				"_id": "2541493881",
				"_name": "Moneda mist. (marip.)"
			},
			{
				"_id": "3766169327",
				"_name": "Moneda alegre"
			},
			{
				"_id": "3707752950",
				"_name": "Trozo de moneda roja"
			},
			{
				"_id": "2885214560",
				"_name": "Trozo moneda amarilla"
			},
			{
				"_id": "854700250",
				"_name": "Trozo moneda naranja"
			},
			{
				"_id": "1173782604",
				"_name": "Trozo de moneda rosa"
			},
			{
				"_id": "3578371549",
				"_name": "Trozo de moneda verde"
			},
			{
				"_id": "2723065163",
				"_name": "Trozo de moneda azul"
			},
			{
				"_id": "3263767726",
				"_name": "Trozo moneda morada"
			},
			{
				"_id": "3045987384",
				"_name": "Trozo moneda turquesa"
			},
			{
				"_id": "1200047969",
				"_name": "Caja roja"
			},
			{
				"_id": "1178938710",
				"_name": "Esfera del portal"
			},
			{
				"_id": "2285637778",
				"_name": "Orbe de Noko"
			},
			{
				"_id": "288702760",
				"_name": "Orbe de Kyubi"
			}
		]
	}
}
