xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "496659440",
				"_name": "Modelo Cero"
			},
			{
				"_id": "917977139",
				"_name": "Reloj curioso"
			},
			{
				"_id": "1102055589",
				"_name": "Reloj curioso"
			},
			{
				"_id": "2707808699",
				"_name": "Medálium de Yo-kai"
			},
			{
				"_id": "1208370318",
				"_name": "Cazamariposas"
			},
			{
				"_id": "3507426612",
				"_name": "Caña de pescar"
			},
			{
				"_id": "2785551778",
				"_name": "Entrada de museo"
			},
			{
				"_id": "1450226134",
				"_name": "Bici alegre"
			},
			{
				"_id": "3480871020",
				"_name": "Bici primaveral"
			},
			{
				"_id": "2270540466",
				"_name": "Bici atardecer"
			},
			{
				"_id": "4031939108",
				"_name": "Bici playera"
			},
			{
				"_id": "1626185653",
				"_name": "Bici cereza"
			},
			{
				"_id": "401256227",
				"_name": "Bici verdemar"
			},
			{
				"_id": "1999447750",
				"_name": "Bici celeste"
			},
			{
				"_id": "2758224",
				"_name": "Bici mediodía"
			},
			{
				"_id": "2569226218",
				"_name": "Bici espléndida"
			},
			{
				"_id": "3995367292",
				"_name": "Bici siniestra"
			},
			{
				"_id": "1883300575",
				"_name": "Bici reluciente"
			},
			{
				"_id": "122147401",
				"_name": "Bici atardecer"
			},
			{
				"_id": "2655945715",
				"_name": "Bici playera"
			},
			{
				"_id": "3913921381",
				"_name": "Bici cereza"
			},
			{
				"_id": "2046209780",
				"_name": "Bici verdemar"
			},
			{
				"_id": "250715746",
				"_name": "Bici celeste"
			},
			{
				"_id": "4038408713",
				"_name": "Bici mediodía"
			},
			{
				"_id": "2276592287",
				"_name": "Bici espléndida"
			},
			{
				"_id": "515595045",
				"_name": "Bici siniestra"
			},
			{
				"_id": "1773956019",
				"_name": "Bici reluciente"
			},
			{
				"_id": "2471723833",
				"_name": "Ficha"
			},
			{
				"_id": "561480000",
				"_name": "Superficha"
			},
			{
				"_id": "2487109408",
				"_name": "Pase de día"
			},
			{
				"_id": "2049975820",
				"_name": "Pase gratis"
			},
			{
				"_id": "323085250",
				"_name": "Cartilla de sellos"
			},
			{
				"_id": "3095318778",
				"_name": "Deberes de verano"
			},
			{
				"_id": "639255897",
				"_name": "Energizante ideal"
			},
			{
				"_id": "1360885199",
				"_name": "Megadestornillador"
			},
			{
				"_id": "3356763253",
				"_name": "Fantasquebollos"
			},
			{
				"_id": "3205698787",
				"_name": "Carnanibollos"
			},
			{
				"_id": "799803762",
				"_name": "Indicaciones mamá"
			},
			{
				"_id": "1487616484",
				"_name": "Llaves del colegio"
			},
			{
				"_id": "2320020088",
				"_name": "Carta de Komasan"
			},
			{
				"_id": "338438107",
				"_name": "Cascabel vueltas"
			},
			{
				"_id": "1663768397",
				"_name": "Gigapeño"
			},
			{
				"_id": "4196550391",
				"_name": "Reloj de primera"
			},
			{
				"_id": "2368042593",
				"_name": "Canica misteriosa"
			},
			{
				"_id": "1788697446",
				"_name": "Extracto de rocalla"
			},
			{
				"_id": "1543533829",
				"_name": "Tapones botellas"
			},
			{
				"_id": "721896851",
				"_name": "Baraja de Ultra"
			},
			{
				"_id": "3830756271",
				"_name": "Llave de cabaña"
			},
			{
				"_id": "221714074",
				"_name": "Mega Watch"
			},
			{
				"_id": "1057059864",
				"_name": "Manguera"
			},
			{
				"_id": "173724291",
				"_name": "Llave mansión (atrás)"
			},
			{
				"_id": "1682363220",
				"_name": "Llave mansión grande"
			},
			{
				"_id": "4249846510",
				"_name": "Llave mansión pequeña"
			},
			{
				"_id": "3812194230",
				"_name": "Llave Yo-kai World"
			},
			{
				"_id": "75586225",
				"_name": "Llave casa abandonada"
			},
			{
				"_id": "2009767659",
				"_name": "Llave jabalí"
			},
			{
				"_id": "3883238266",
				"_name": "Llave ciervo"
			},
			{
				"_id": "1938188839",
				"_name": "Llave mariposa"
			},
			{
				"_id": "2103304725",
				"_name": "Aceite de Agujeto"
			},
			{
				"_id": "3261391014",
				"_name": "Foto 1 Pussycat Miau"
			},
			{
				"_id": "1390148919",
				"_name": "Foto 2 Pussycat Miau"
			},
			{
				"_id": "635227553",
				"_name": "Foto 3 Pussycat Miau"
			},
			{
				"_id": "1159414852",
				"_name": "Foto 4 Pussycat Miau"
			},
			{
				"_id": "840725714",
				"_name": "Foto 5 Pussycat Miau"
			},
			{
				"_id": "2870289768",
				"_name": "Foto 6 Pussycat Miau"
			},
			{
				"_id": "3692172798",
				"_name": "Foto 7 Pussycat Miau"
			},
			{
				"_id": "1115062365",
				"_name": "Foto 8 Pussycat Miau"
			},
			{
				"_id": "896643275",
				"_name": "Foto 9 Pussycat Miau"
			},
			{
				"_id": "2893603185",
				"_name": "Foto 10 Pussycat Miau"
			},
			{
				"_id": "3682587111",
				"_name": "Dragón pompis"
			},
			{
				"_id": "1270926454",
				"_name": "Llave apar. C-302"
			},
			{
				"_id": "1019739360",
				"_name": "Llave apar. A-201"
			},
			{
				"_id": "1849038727",
				"_name": "Llave apar. A-203"
			},
			{
				"_id": "422651665",
				"_name": "Llave apar. B-102"
			},
			{
				"_id": "2151184043",
				"_name": "Llave apar. B-204"
			},
			{
				"_id": "4148119101",
				"_name": "Llave apar. B-301"
			},
			{
				"_id": "1767625630",
				"_name": "Llave apar. C-101"
			},
			{
				"_id": "509403912",
				"_name": "Llave apar. C-303"
			},
			{
				"_id": "4158193168",
				"_name": "Póster de serie B"
			},
			{
				"_id": "2162151046",
				"_name": "Traje de rockero"
			},
			{
				"_id": "433495868",
				"_name": "Cartel de superhéroe"
			},
			{
				"_id": "1859235754",
				"_name": "Peli antigua"
			},
			{
				"_id": "4268667451",
				"_name": "Cartel de restaurante"
			},
			{
				"_id": "2305393325",
				"_name": "Vestido de actriz"
			},
			{
				"_id": "3920497480",
				"_name": "Osita de peluche"
			},
			{
				"_id": "2661891038",
				"_name": "Botella de Y-Cola"
			},
			{
				"_id": "127953508",
				"_name": "Orinal patito"
			},
			{
				"_id": "1890015986",
				"_name": "Tortuga fotógrafa"
			},
			{
				"_id": "4005810001",
				"_name": "Pergamino ña"
			},
			{
				"_id": "2579824583",
				"_name": "Pergamino victorioso"
			},
			{
				"_id": "13479549",
				"_name": "Pergamino miauchado"
			},
			{
				"_id": "4158121970",
				"_name": "Bollito de la unidad"
			},
			{
				"_id": "1860089416",
				"_name": "Dosier importante"
			},
			{
				"_id": "2277315453",
				"_name": "Pringue fantasmal"
			},
			{
				"_id": "4038730731",
				"_name": "Tarjeta llave roja"
			},
			{
				"_id": "1773367889",
				"_name": "Tarjeta llave azul"
			},
			{
				"_id": "515130055",
				"_name": "Tarjeta llave dorada"
			},
			{
				"_id": "2383109974",
				"_name": "Cinturón superhéroe"
			},
			{
				"_id": "4178341824",
				"_name": "Espada roma"
			},
			{
				"_id": "2580276773",
				"_name": "Robot retro impoluto"
			},
			{
				"_id": "4006401715",
				"_name": "Robot retro gastado"
			},
			{
				"_id": "2009433865",
				"_name": "Mapa del tesoro"
			},
			{
				"_id": "12760991",
				"_name": "Mapa empapado"
			},
			{
				"_id": "2661687868",
				"_name": "Mapa arrugado"
			},
			{
				"_id": "3919647402",
				"_name": "Mapa manchado"
			},
			{
				"_id": "1890075408",
				"_name": "Nuevo mapa del tesoro"
			},
			{
				"_id": "128938886",
				"_name": "Llave sala del tesoro"
			},
			{
				"_id": "2534436375",
				"_name": "Mapa final del tesoro"
			},
			{
				"_id": "3759627905",
				"_name": "Mango extraño"
			},
			{
				"_id": "3001464294",
				"_name": "Cámara blanco y negro"
			},
			{
				"_id": "3319891312",
				"_name": "Foto del colegio"
			},
			{
				"_id": "1558762698",
				"_name": "Foto de calle Galería"
			},
			{
				"_id": "737141852",
				"_name": "Foto de Calabazilla"
			},
			{
				"_id": "3045814783",
				"_name": "Firma Pussycat Miau"
			},
			{
				"_id": "3263971689",
				"_name": "Toalla artesanal"
			},
			{
				"_id": "3848423452",
				"_name": "Peineta"
			},
			{
				"_id": "2087393702",
				"_name": "La fiebre del disco"
			},
			{
				"_id": "191637808",
				"_name": "Pase Maldiexprés"
			},
			{
				"_id": "2500377747",
				"_name": "Entrada Gera Gera"
			},
			{
				"_id": "3792669701",
				"_name": "Entr. termas Calma"
			},
			{
				"_id": "2064047551",
				"_name": "Pase Cocina Asesi."
			},
			{
				"_id": "201452841",
				"_name": "Tarjeta termas Divi."
			},
			{
				"_id": "2629759160",
				"_name": "Tarjeta termas Serr."
			},
			{
				"_id": "3954819118",
				"_name": "Tarjeta termas Cerr."
			},
			{
				"_id": "2340309451",
				"_name": "Tarjeta termas Viaj."
			},
			{
				"_id": "4235819357",
				"_name": "Tarjeta termas Bos."
			},
			{
				"_id": "1701849319",
				"_name": "Tarjeta termas For."
			},
			{
				"_id": "309794929",
				"_name": "Tarjeta termas Tes."
			},
			{
				"_id": "2350091730",
				"_name": "Cinturón multiusos"
			},
			{
				"_id": "4212440388",
				"_name": "Capa de ocultación"
			},
			{
				"_id": "1646128382",
				"_name": "Maneta de freno"
			},
			{
				"_id": "354081896",
				"_name": "Pas. Tranquiexprés"
			},
			{
				"_id": "2242232825",
				"_name": "Expendefic. fortuna"
			},
			{
				"_id": "4070764911",
				"_name": "Señal de Ultra"
			},
			{
				"_id": "2689800712",
				"_name": "Important Item 20"
			},
			{
				"_id": "3612617374",
				"_name": "Important Item 21"
			},
			{
				"_id": "1314749220",
				"_name": "Important Item 22"
			},
			{
				"_id": "962218930",
				"_name": "Important Item 23"
			},
			{
				"_id": "2805915153",
				"_name": "Important Item 24"
			},
			{
				"_id": "3493457543",
				"_name": "Important Item 25"
			},
			{
				"_id": "3503128323",
				"_name": "Semillas de melón"
			},
			{
				"_id": "2815053717",
				"_name": "Semillas de naranjo"
			},
			{
				"_id": "930435588",
				"_name": "Semillas de kiwi"
			},
			{
				"_id": "1081238162",
				"_name": "Semillas de vid"
			},
			{
				"_id": "548793207",
				"_name": "Semillas de fresa"
			},
			{
				"_id": "1471339489",
				"_name": "Semillas de sandía"
			},
			{
				"_id": "3468397147",
				"_name": "Engranaje Kappandante"
			},
			{
				"_id": "3116153549",
				"_name": "Engranaje Komasan"
			},
			{
				"_id": "668479342",
				"_name": "Engranaje Abuzampa"
			},
			{
				"_id": "1356799992",
				"_name": "Engranaje Cantonio"
			},
			{
				"_id": "3386265154",
				"_name": "Engranaje Noko"
			},
			{
				"_id": "3201400532",
				"_name": "Engranaje Draqui"
			},
			{
				"_id": "778986309",
				"_name": "Cascabel 2.0"
			},
			{
				"_id": "1500074963",
				"_name": "Cascabel sailor"
			},
			{
				"_id": "194558132",
				"_name": "Cascabel atigrado"
			},
			{
				"_id": "2090829858",
				"_name": "Cascabel maravilla"
			},
			{
				"_id": "3851868568",
				"_name": "Cascabel aéreo"
			},
			{
				"_id": "2459035918",
				"_name": "Fardo diabólico"
			},
			{
				"_id": "217414829",
				"_name": "Tapón apreciado"
			},
			{
				"_id": "2079476795",
				"_name": "Cascabel oscuro"
			}
		]
	}
}
