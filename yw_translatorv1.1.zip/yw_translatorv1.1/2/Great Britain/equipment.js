xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Worn Bangle"
			},
			{
				"_id": "3681894277",
				"_name": "Cheap Bracelet"
			},
			{
				"_id": "3692624796",
				"_name": "Rocker Wrist"
			},
			{
				"_id": "2893156115",
				"_name": "Power Bracelet"
			},
			{
				"_id": "2870987530",
				"_name": "Brute Bracer"
			},
			{
				"_id": "1020072578",
				"_name": "Grand Bracelet"
			},
			{
				"_id": "897277609",
				"_name": "Sun Bracelet"
			},
			{
				"_id": "1271538196",
				"_name": "Comet Bracelet"
			},
			{
				"_id": "1115450943",
				"_name": "Fiend Band"
			},
			{
				"_id": "722316273",
				"_name": "Legend Bracelet"
			},
			{
				"_id": "1154727953",
				"_name": "Rusty Ring"
			},
			{
				"_id": "3669448114",
				"_name": "Ugly Ring"
			},
			{
				"_id": "3722088875",
				"_name": "Pretty Ring"
			},
			{
				"_id": "2914018596",
				"_name": "Rainbow Ring"
			},
			{
				"_id": "2866651453",
				"_name": "Illusion Ring"
			},
			{
				"_id": "1024424117",
				"_name": "Fairy Ring"
			},
			{
				"_id": "884552862",
				"_name": "Lunar Ring"
			},
			{
				"_id": "1242056739",
				"_name": "Ring of Fate"
			},
			{
				"_id": "1136526344",
				"_name": "Fiend Ring"
			},
			{
				"_id": "718258630",
				"_name": "Legend Ring"
			},
			{
				"_id": "1184202312",
				"_name": "Aged Charm"
			},
			{
				"_id": "3639733227",
				"_name": "Old Charm"
			},
			{
				"_id": "3751555058",
				"_name": "Runic Charm"
			},
			{
				"_id": "2952190845",
				"_name": "Protective Charm"
			},
			{
				"_id": "2828738404",
				"_name": "Armor Charm"
			},
			{
				"_id": "1061799660",
				"_name": "Lucky Charm"
			},
			{
				"_id": "922716871",
				"_name": "Galaxy Charm"
			},
			{
				"_id": "1213134458",
				"_name": "Earth Charm"
			},
			{
				"_id": "1106819665",
				"_name": "Fiend Charm"
			},
			{
				"_id": "680099743",
				"_name": "Legend Charm"
			},
			{
				"_id": "1196889215",
				"_name": "Simple Badge"
			},
			{
				"_id": "3644031452",
				"_name": "Black Badge"
			},
			{
				"_id": "3730720197",
				"_name": "Shiny Badge"
			},
			{
				"_id": "2922688842",
				"_name": "Cute Badge"
			},
			{
				"_id": "2841212243",
				"_name": "Hermes Badge"
			},
			{
				"_id": "1049341147",
				"_name": "Aurora Badge"
			},
			{
				"_id": "926802160",
				"_name": "Meteor Badge"
			},
			{
				"_id": "1233951821",
				"_name": "Lightning Badge"
			},
			{
				"_id": "1077596262",
				"_name": "Fiend Badge"
			},
			{
				"_id": "692786600",
				"_name": "Legend Badge"
			},
			{
				"_id": "1108869882",
				"_name": "Cicada Sword"
			},
			{
				"_id": "3675345728",
				"_name": "Beefy Bell"
			},
			{
				"_id": "2887148502",
				"_name": "Spell Bell"
			},
			{
				"_id": "846394997",
				"_name": "Tough Bell"
			},
			{
				"_id": "1165346531",
				"_name": "Speed Bell"
			},
			{
				"_id": "3699152729",
				"_name": "Big Bottle"
			},
			{
				"_id": "2877007823",
				"_name": "Tengu Fan"
			},
			{
				"_id": "1002748510",
				"_name": "Cheery Coat"
			},
			{
				"_id": "1287883464",
				"_name": "Nail Bat"
			},
			{
				"_id": "1550776226",
				"_name": "Drumsticks"
			},
			{
				"_id": "3311904280",
				"_name": "Robovitamin E"
			},
			{
				"_id": "2992674446",
				"_name": "Burly's Wristband"
			},
			{
				"_id": "585075487",
				"_name": "Memory Chime"
			},
			{
				"_id": "3037549207",
				"_name": "Bony Band"
			},
			{
				"_id": "728352564",
				"_name": "Fleshy Band"
			},
			{
				"_id": "738460461",
				"_name": "Reversword"
			},
			{
				"_id": "1526936507",
				"_name": "Turnabeads"
			},
			{
				"_id": "3255460353",
				"_name": "Reflector"
			},
			{
				"_id": "1440267145",
				"_name": "Paradise Ball"
			},
			{
				"_id": "1138387149",
				"_name": "Sinister Screed"
			},
			{
				"_id": "3671275895",
				"_name": "Cursed Sword"
			},
			{
				"_id": "2916354529",
				"_name": "Cursed Staff"
			},
			{
				"_id": "867212354",
				"_name": "Cursed Shield"
			},
			{
				"_id": "1152888020",
				"_name": "Cursed Robe"
			},
			{
				"_id": "1100797588",
				"_name": "Restraint Belt"
			},
			{
				"_id": "2945628088",
				"_name": "Monkey Circlet"
			},
			{
				"_id": "4256025923",
				"_name": "General's Medal"
			},
			{
				"_id": "1688509689",
				"_name": "Lt. Gen's Medal"
			},
			{
				"_id": "329493615",
				"_name": "Maj. Gen. Medal"
			},
			{
				"_id": "2378643916",
				"_name": "Colonel's Medal"
			},
			{
				"_id": "4206889306",
				"_name": "Major's Medal"
			},
			{
				"_id": "1674139872",
				"_name": "Captain's Medal"
			},
			{
				"_id": "349071478",
				"_name": "CDR.'s Medal"
			},
			{
				"_id": "2222028263",
				"_name": "Lt.'s Medal"
			}
		]
	}
}
