xmlval = {
	"items": {
		"item": [
			{
				"_id": "1",
				"_name": "Grouchy"
			},
			{
				"_id": "2",
				"_name": "Logical"
			},
			{
				"_id": "3",
				"_name": "Careful"
			},
			{
				"_id": "4",
				"_name": "Gentle"
			},
			{
				"_id": "5",
				"_name": "Twisted"
			},
			{
				"_id": "6",
				"_name": "Helpful"
			},
			{
				"_id": "7",
				"_name": "Rough"
			},
			{
				"_id": "8",
				"_name": "Brainy"
			},
			{
				"_id": "9",
				"_name": "Calm"
			},
			{
				"_id": "10",
				"_name": "Tender"
			},
			{
				"_id": "11",
				"_name": "Cruel"
			},
			{
				"_id": "12",
				"_name": "Devoted"
			}
		]
	}
}