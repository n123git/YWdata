xmlval = {
	"items": {
		"item": [
			{
				"_id": "1803927674",
				"_name": "Plum Rice Ball"
			},
			{
				"_id": "4069298624",
				"_name": "Leaf Rice Ball"
			},
			{
				"_id": "2240520534",
				"_name": "Roe Rice Ball"
			},
			{
				"_id": "468661493",
				"_name": "Shrimp Rice Ball"
			},
			{
				"_id": "1783081549",
				"_name": "Sandwich"
			},
			{
				"_id": "4082039799",
				"_name": "Custard Bread"
			},
			{
				"_id": "1831497300",
				"_name": "Curry Bread"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Blehgel"
			},
			{
				"_id": "1744901140",
				"_name": "10p Gum"
			},
			{
				"_id": "4043851182",
				"_name": "Gooey Candy"
			},
			{
				"_id": "2249159992",
				"_name": "Giant Cracker"
			},
			{
				"_id": "409723035",
				"_name": "Fruit Drops"
			},
			{
				"_id": "1869402125",
				"_name": "Shaved Ice"
			},
			{
				"_id": "4133847479",
				"_name": "Candy Apple"
			},
			{
				"_id": "1774419491",
				"_name": "Milk"
			},
			{
				"_id": "4039782297",
				"_name": "Coffee Milk"
			},
			{
				"_id": "2278366991",
				"_name": "Fruit Milk"
			},
			{
				"_id": "430541484",
				"_name": "Amazing Milk"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Soul Tea"
			},
			{
				"_id": "2189560202",
				"_name": "Spiritizer Y"
			},
			{
				"_id": "484875305",
				"_name": "VoltXtreme"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Double Burger"
			},
			{
				"_id": "488961566",
				"_name": "Nom Burger"
			},
			{
				"_id": "1858787071",
				"_name": "Ramen Cup"
			},
			{
				"_id": "4156786501",
				"_name": "Pork Ramen"
			},
			{
				"_id": "2160375763",
				"_name": "Deluxe Ramen"
			},
			{
				"_id": "513811056",
				"_name": "Everything Ramen"
			},
			{
				"_id": "1683291125",
				"_name": "Pot Stickers"
			},
			{
				"_id": "4250774095",
				"_name": "Liver & Chives"
			},
			{
				"_id": "2321193689",
				"_name": "Crab Omelet"
			},
			{
				"_id": "339611514",
				"_name": "Chili Shrimp"
			},
			{
				"_id": "3539717416",
				"_name": "Carrot"
			},
			{
				"_id": "1274190994",
				"_name": "Cucumber"
			},
			{
				"_id": "1022733316",
				"_name": "Bamboo Shoot"
			},
			{
				"_id": "2727426471",
				"_name": "Matsutake"
			},
			{
				"_id": "3502076785",
				"_name": "Chicken Thigh"
			},
			{
				"_id": "1236542155",
				"_name": "Slab Bacon"
			},
			{
				"_id": "1051923037",
				"_name": "Beef Tongue"
			},
			{
				"_id": "2698479614",
				"_name": "Marbled Beef"
			},
			{
				"_id": "3514767686",
				"_name": "Dried Mackerel"
			},
			{
				"_id": "1215711484",
				"_name": "Yellowtail"
			},
			{
				"_id": "1064401002",
				"_name": "Fresh Urchin"
			},
			{
				"_id": "2702568905",
				"_name": "Choice Tuna"
			},
			{
				"_id": "320924352",
				"_name": "Small Exporb"
			},
			{
				"_id": "2317990778",
				"_name": "Medium Exporb"
			},
			{
				"_id": "4247686124",
				"_name": "Large Exporb"
			},
			{
				"_id": "1665801807",
				"_name": "Mega Exporb"
			},
			{
				"_id": "340602585",
				"_name": "Holy Exporb"
			},
			{
				"_id": "397252210",
				"_name": "Staminum"
			},
			{
				"_id": "2393163720",
				"_name": "Staminum Alpha"
			},
			{
				"_id": "279199406",
				"_name": "Hidden Hits"
			},
			{
				"_id": "2309844756",
				"_name": "Top Techniques"
			},
			{
				"_id": "4272578434",
				"_name": "Soul Secrets"
			},
			{
				"_id": "469268883",
				"_name": "A Serious Life"
			},
			{
				"_id": "2196842537",
				"_name": "Think Karate"
			},
			{
				"_id": "4126546111",
				"_name": "Use Karate"
			},
			{
				"_id": "1804766492",
				"_name": "Skill Compendium"
			},
			{
				"_id": "479575434",
				"_name": "Skill Encycloped."
			},
			{
				"_id": "2241653808",
				"_name": "Get Guarding"
			},
			{
				"_id": "4070300838",
				"_name": "Guard Gloriously"
			},
			{
				"_id": "1646575927",
				"_name": "Li'l Angel Heals"
			},
			{
				"_id": "354677153",
				"_name": "Bye, Li'l Angel"
			},
			{
				"_id": "1977907268",
				"_name": "The Pest's Quest"
			},
			{
				"_id": "48449746",
				"_name": "The Perfect Pest"
			},
			{
				"_id": "2615810408",
				"_name": "Support Life #7"
			},
			{
				"_id": "3974965758",
				"_name": "Support Special"
			},
			{
				"_id": "367732779",
				"_name": "Strength Talisman"
			},
			{
				"_id": "2363652497",
				"_name": "Spirit Talisman"
			},
			{
				"_id": "4226107655",
				"_name": "Defense Talisman"
			},
			{
				"_id": "1703009444",
				"_name": "Speed Talisman"
			},
			{
				"_id": "338248220",
				"_name": "Nasty Medicine"
			},
			{
				"_id": "2367689638",
				"_name": "Bitter Medicine"
			},
			{
				"_id": "4196868912",
				"_name": "Mighty Medicine"
			},
			{
				"_id": "376437829",
				"_name": "Getaway Plush"
			},
			{
				"_id": "291919001",
				"_name": "Bronze Doll"
			},
			{
				"_id": "2288977187",
				"_name": "Silver Doll"
			},
			{
				"_id": "4285019573",
				"_name": "Golden Doll"
			},
			{
				"_id": "2908180302",
				"_name": "Fish Bait"
			},
			{
				"_id": "878583540",
				"_name": "Black Syrup"
			},
			{
				"_id": "2592718716",
				"_name": "Red Coin"
			},
			{
				"_id": "58781382",
				"_name": "Yellow Coin"
			},
			{
				"_id": "1955061328",
				"_name": "Orange Coin"
			},
			{
				"_id": "3940764659",
				"_name": "Pink Coin"
			},
			{
				"_id": "2648996709",
				"_name": "Green Coin"
			},
			{
				"_id": "82651871",
				"_name": "Blue Coin"
			},
			{
				"_id": "1944721993",
				"_name": "Purple Coin"
			},
			{
				"_id": "3814000600",
				"_name": "Light-Blue Coin"
			},
			{
				"_id": "3141306787",
				"_name": "Sapphire Coin"
			},
			{
				"_id": "3426466101",
				"_name": "Emerald Coin"
			},
			{
				"_id": "1381969046",
				"_name": "Ruby Coin"
			},
			{
				"_id": "626531328",
				"_name": "Topaz Coin"
			},
			{
				"_id": "573954073",
				"_name": "Diamond Coin"
			},
			{
				"_id": "3159444922",
				"_name": "Excitement Coin"
			},
			{
				"_id": "3411442988",
				"_name": "Five-Star Coin"
			},
			{
				"_id": "1542021309",
				"_name": "Special Coin"
			},
			{
				"_id": "2895455609",
				"_name": "Dancing Star"
			},
			{
				"_id": "440013732",
				"_name": "Legendary Blade"
			},
			{
				"_id": "2201174558",
				"_name": "Cursed Blade"
			},
			{
				"_id": "2220787207",
				"_name": "Holy Blade"
			},
			{
				"_id": "4097077896",
				"_name": "General's Soul"
			},
			{
				"_id": "1783686955",
				"_name": "Love Buster"
			},
			{
				"_id": "492296125",
				"_name": "GHz Orb"
			},
			{
				"_id": "1676061440",
				"_name": "Unbeatable Soul"
			},
			{
				"_id": "2586342239",
				"_name": "Platinum Bar"
			},
			{
				"_id": "350329750",
				"_name": "Snowstorm Cloak"
			},
			{
				"_id": "1948652147",
				"_name": "Love Scepter"
			},
			{
				"_id": "4082742929",
				"_name": "Glacial Clip"
			},
			{
				"_id": "52503269",
				"_name": "Buff Weight"
			},
			{
				"_id": "1934349930",
				"_name": "Shard of Evil"
			},
			{
				"_id": "3979297737",
				"_name": "Ageless Powder"
			},
			{
				"_id": "3742966091",
				"_name": "Drop of Joy"
			},
			{
				"_id": "2638591814",
				"_name": "Dragon Orb"
			},
			{
				"_id": "3930228688",
				"_name": "Holy Water"
			},
			{
				"_id": "2063440449",
				"_name": "Dingy Scale"
			},
			{
				"_id": "234531543",
				"_name": "Venoct Aura"
			},
			{
				"_id": "1594573232",
				"_name": "Tattered Gauntlet"
			},
			{
				"_id": "671904038",
				"_name": "Cracked Crystal"
			},
			{
				"_id": "2969903260",
				"_name": "Crystal Shard"
			},
			{
				"_id": "3322023946",
				"_name": "Clenzall"
			},
			{
				"_id": "1483113897",
				"_name": "Yellowed Sash"
			},
			{
				"_id": "794932543",
				"_name": "Plain Ring"
			},
			{
				"_id": "3060327557",
				"_name": "Blank Charm"
			},
			{
				"_id": "3245331475",
				"_name": "Ruby"
			},
			{
				"_id": "1372637570",
				"_name": "Aquamarine"
			},
			{
				"_id": "651688212",
				"_name": "Topaz"
			},
			{
				"_id": "1175482609",
				"_name": "Tourmaline"
			},
			{
				"_id": "823607399",
				"_name": "Opal"
			},
			{
				"_id": "2820542941",
				"_name": "Emerald"
			}
		]
	}
}