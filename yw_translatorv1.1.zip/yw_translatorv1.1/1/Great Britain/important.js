xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "2707808699",
				"_name": "Yo-kai Medallium"
			},
			{
				"_id": "1057059864",
				"_name": "Blossoming Powder"
			},
			{
				"_id": "1208370318",
				"_name": "Bug Net"
			},
			{
				"_id": "3507426612",
				"_name": "Fishing Rod"
			},
			{
				"_id": "2785551778",
				"_name": "Museum Ticket"
			},
			{
				"_id": "917977139",
				"_name": "Vault Key"
			},
			{
				"_id": "1102055589",
				"_name": "Photo of Amy"
			},
			{
				"_id": "561480000",
				"_name": "Old Man Undies"
			},
			{
				"_id": "1450226134",
				"_name": "Bicycle"
			},
			{
				"_id": "3480871020",
				"_name": "Bicycle"
			},
			{
				"_id": "3095318778",
				"_name": "Watch Cog"
			},
			{
				"_id": "639255897",
				"_name": "Watch Screw"
			},
			{
				"_id": "1360885199",
				"_name": "Old Mansion Key"
			},
			{
				"_id": "3356763253",
				"_name": "Special Ring"
			},
			{
				"_id": "3205698787",
				"_name": "Dad's Papers"
			},
			{
				"_id": "799803762",
				"_name": "Pretty Rib"
			},
			{
				"_id": "1487616484",
				"_name": "School Keys"
			},
			{
				"_id": "173724291",
				"_name": "Sheet Music"
			},
			{
				"_id": "2103304725",
				"_name": "Watch Spring"
			},
			{
				"_id": "3830756271",
				"_name": "Shack Key"
			},
			{
				"_id": "2471723833",
				"_name": "Signiton Engine"
			},
			{
				"_id": "221714074",
				"_name": "Payn Oil"
			},
			{
				"_id": "2049975820",
				"_name": "Leadoni Wheel"
			},
			{
				"_id": "3812194230",
				"_name": "Yo-kai World Key"
			},
			{
				"_id": "75586225",
				"_name": "Tasty Mushroom"
			},
			{
				"_id": "1938188839",
				"_name": "Comic Book"
			},
			{
				"_id": "323085250",
				"_name": "Walkappa's Bottle"
			},
			{
				"_id": "1682363220",
				"_name": "Cracked Plate"
			},
			{
				"_id": "4249846510",
				"_name": "Shabby Charm"
			},
			{
				"_id": "2320020088",
				"_name": "Golden Tofu"
			},
			{
				"_id": "338438107",
				"_name": "Toy Missile"
			},
			{
				"_id": "1663768397",
				"_name": "Soccer Ball"
			},
			{
				"_id": "4196550391",
				"_name": "Love Poetry"
			},
			{
				"_id": "2368042593",
				"_name": "Refreshing Herbs"
			},
			{
				"_id": "496659440",
				"_name": "Betrayed Blade"
			},
			{
				"_id": "1788697446",
				"_name": "Shiny Idol Pic"
			},
			{
				"_id": "1543533829",
				"_name": "Faded Idol Pic"
			},
			{
				"_id": "721896851",
				"_name": "Rare Model Kit"
			},
			{
				"_id": "2987267113",
				"_name": "Precious Earring"
			},
			{
				"_id": "3305710783",
				"_name": "Time Capsule"
			},
			{
				"_id": "1533915420",
				"_name": "Illusion Blade"
			},
			{
				"_id": "745177482",
				"_name": "Typhoon Fan"
			},
			{
				"_id": "3043217456",
				"_name": "Forever Flower"
			},
			{
				"_id": "3261391014",
				"_name": "Slither Trophy"
			},
			{
				"_id": "1390148919",
				"_name": "Hunger Trophy"
			},
			{
				"_id": "635227553",
				"_name": "Meow Trophy"
			},
			{
				"_id": "1159414852",
				"_name": "Granny Trophy"
			},
			{
				"_id": "840725714",
				"_name": "Horse Trophy"
			},
			{
				"_id": "2870289768",
				"_name": "Mane Trophy"
			},
			{
				"_id": "3692172798",
				"_name": "Hood Trophy"
			},
			{
				"_id": "1115062365",
				"_name": "Wrinkly Trophy"
			},
			{
				"_id": "896643275",
				"_name": "Katana Trophy"
			},
			{
				"_id": "2893603185",
				"_name": "Papa Trophy"
			},
			{
				"_id": "3682587111",
				"_name": "Tengu Trophy"
			},
			{
				"_id": "1270926454",
				"_name": "Cicada Trophy"
			},
			{
				"_id": "1019739360",
				"_name": "Mochi Trophy"
			},
			{
				"_id": "1849038727",
				"_name": "Bird Trophy"
			},
			{
				"_id": "422651665",
				"_name": "Wannabe Trophy"
			},
			{
				"_id": "2151184043",
				"_name": "Gambler Trophy"
			},
			{
				"_id": "4148119101",
				"_name": "Good Job Prize"
			},
			{
				"_id": "1767625630",
				"_name": "Wild Trophy"
			},
			{
				"_id": "509403912",
				"_name": "Cool Hair Prize"
			},
			{
				"_id": "2270540466",
				"_name": "Flutter Trophy"
			},
			{
				"_id": "4031939108",
				"_name": "Shogun Trophy"
			},
			{
				"_id": "1626185653",
				"_name": "Kids' Trophy"
			},
			{
				"_id": "401256227",
				"_name": "Daze Trophy"
			},
			{
				"_id": "1999447750",
				"_name": "Sack Trophy"
			},
			{
				"_id": "2758224",
				"_name": "Kimono Trophy"
			},
			{
				"_id": "2569226218",
				"_name": "Glasses Trophy"
			},
			{
				"_id": "3995367292",
				"_name": "Buzz Trophy"
			},
			{
				"_id": "1883300575",
				"_name": "Kappa Trophy"
			},
			{
				"_id": "122147401",
				"_name": "Guardian Trophy"
			},
			{
				"_id": "2655945715",
				"_name": "Heart Trophy"
			},
			{
				"_id": "3913921381",
				"_name": "Master Trophy"
			},
			{
				"_id": "2046209780",
				"_name": "Snake Trophy"
			},
			{
				"_id": "250715746",
				"_name": "Bottle Trophy"
			},
			{
				"_id": "4038408713",
				"_name": "Lion Trophy"
			},
			{
				"_id": "2276592287",
				"_name": "Cloak Trophy"
			},
			{
				"_id": "515595045",
				"_name": "Hat Trophy"
			},
			{
				"_id": "1773956019",
				"_name": "Stilt Trophy"
			},
			{
				"_id": "4158193168",
				"_name": "Stylish Trophy"
			},
			{
				"_id": "2162151046",
				"_name": "Stag Trophy"
			},
			{
				"_id": "433495868",
				"_name": "Cupid Trophy"
			},
			{
				"_id": "1859235754",
				"_name": "Comedy Trophy"
			},
			{
				"_id": "4268667451",
				"_name": "Beetle Trophy"
			},
			{
				"_id": "2305393325",
				"_name": "Darkness Trophy"
			},
			{
				"_id": "3920497480",
				"_name": "Toothpick Trophy"
			},
			{
				"_id": "2661891038",
				"_name": "Eel Trophy"
			},
			{
				"_id": "127953508",
				"_name": "Shark Trophy"
			},
			{
				"_id": "1890015986",
				"_name": "Demon Trophy"
			},
			{
				"_id": "4005810001",
				"_name": "Seaweed Trophy"
			},
			{
				"_id": "2579824583",
				"_name": "Dragon Trophy"
			},
			{
				"_id": "13479549",
				"_name": "Shell Trophy"
			},
			{
				"_id": "2009767659",
				"_name": "Triclops Trophy"
			},
			{
				"_id": "3883238266",
				"_name": "Cyclops Trophy"
			},
			{
				"_id": "1319758496",
				"_name": "Sapphire Bell"
			},
			{
				"_id": "3617635098",
				"_name": "Emerald Bell"
			},
			{
				"_id": "2695334796",
				"_name": "Ruby Bell"
			},
			{
				"_id": "1052974639",
				"_name": "Topaz Bell"
			},
			{
				"_id": "1237593785",
				"_name": "Diamond Bell"
			},
			{
				"_id": "4158121970",
				"_name": "Composer Portrait"
			},
			{
				"_id": "1860089416",
				"_name": "Frog Anatomy"
			},
			{
				"_id": "433686238",
				"_name": "Yo-kai Guide"
			},
			{
				"_id": "2277315453",
				"_name": "Thermometer"
			},
			{
				"_id": "4038730731",
				"_name": "Principal Photo"
			},
			{
				"_id": "1773367889",
				"_name": "Noko Skin"
			},
			{
				"_id": "515130055",
				"_name": "Noko Dung"
			},
			{
				"_id": "2383109974",
				"_name": "Noko Dirt"
			},
			{
				"_id": "4178341824",
				"_name": "Detective Badge"
			},
			{
				"_id": "2580276773",
				"_name": "Cracked Plate"
			},
			{
				"_id": "4006401715",
				"_name": "Munched Cucumber"
			},
			{
				"_id": "2009433865",
				"_name": "Dusty Charm"
			},
			{
				"_id": "12760991",
				"_name": "Detective Badge+"
			},
			{
				"_id": "2661687868",
				"_name": "Detective Badge EX"
			},
			{
				"_id": "3919647402",
				"_name": "Busted Bucket"
			},
			{
				"_id": "1890075408",
				"_name": "Plastic Bottle"
			},
			{
				"_id": "128938886",
				"_name": "Old Magazine"
			},
			{
				"_id": "2534436375",
				"_name": "Super Badge"
			},
			{
				"_id": "3759627905",
				"_name": "KD Note"
			},
			{
				"_id": "3001464294",
				"_name": "Ultra Det. Badge"
			},
			{
				"_id": "3319891312",
				"_name": "Bulletin Note"
			},
			{
				"_id": "1558762698",
				"_name": "Idol Poster"
			},
			{
				"_id": "737141852",
				"_name": "Empty Can"
			},
			{
				"_id": "3045814783",
				"_name": "Empty Bottle"
			},
			{
				"_id": "3263971689",
				"_name": "Battered Boots"
			},
			{
				"_id": "1535447251",
				"_name": "Used Firework"
			},
			{
				"_id": "746725445",
				"_name": "Plastic Bag"
			}
		]
	}
}