xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Green Cicada"
			},
			{
				"_id": "3460879014",
				"_name": "★Green Cicada"
			},
			{
				"_id": "1228371524",
				"_name": "Brown Cicada"
			},
			{
				"_id": "1463911196",
				"_name": "★Brown Cicada"
			},
			{
				"_id": "1043351250",
				"_name": "Evening Cicada"
			},
			{
				"_id": "541504394",
				"_name": "★Evening Cicada"
			},
			{
				"_id": "2689913713",
				"_name": "Rhino Beetle"
			},
			{
				"_id": "2969153051",
				"_name": "★Rhino Beetle"
			},
			{
				"_id": "3612599271",
				"_name": "Dorcus Stag"
			},
			{
				"_id": "3355352717",
				"_name": "★Dorcus Stag"
			},
			{
				"_id": "1314566749",
				"_name": "Sawtooth Stag"
			},
			{
				"_id": "2500818410",
				"_name": "★Sawtooth Stag"
			},
			{
				"_id": "962429643",
				"_name": "Grasshopper"
			},
			{
				"_id": "3792192892",
				"_name": "★Grasshopper"
			},
			{
				"_id": "2850201434",
				"_name": "Praying Mantis"
			},
			{
				"_id": "2063668422",
				"_name": "★Praying Mantis"
			},
			{
				"_id": "3739594700",
				"_name": "Locust"
			},
			{
				"_id": "201729104",
				"_name": "★Locust"
			},
			{
				"_id": "3189909033",
				"_name": "Firefly"
			},
			{
				"_id": "2455941619",
				"_name": "★Firefly"
			},
			{
				"_id": "3374651071",
				"_name": "Swallowtail"
			},
			{
				"_id": "3848634725",
				"_name": "★Swallowtail"
			},
			{
				"_id": "1345079045",
				"_name": "Long-Horn"
			},
			{
				"_id": "2087506143",
				"_name": "★Long-Horn"
			},
			{
				"_id": "657160083",
				"_name": "Flower Scarab"
			},
			{
				"_id": "191619145",
				"_name": "★Flower Scarab"
			},
			{
				"_id": "3109020208",
				"_name": "Ladybug"
			},
			{
				"_id": "2614427096",
				"_name": "★Ladybug"
			},
			{
				"_id": "3522973129",
				"_name": "Turtle"
			},
			{
				"_id": "562354621",
				"_name": "★Turtle"
			},
			{
				"_id": "1224023155",
				"_name": "Black Bass"
			},
			{
				"_id": "2973484076",
				"_name": "★Black Bass"
			},
			{
				"_id": "1072835813",
				"_name": "Giant Huchen"
			},
			{
				"_id": "3325883578",
				"_name": "★Giant Huchen"
			},
			{
				"_id": "2711009606",
				"_name": "Carp"
			},
			{
				"_id": "2496471005",
				"_name": "★Carp"
			},
			{
				"_id": "3599862224",
				"_name": "Sweetfish"
			},
			{
				"_id": "3821678411",
				"_name": "★Sweetfish"
			},
			{
				"_id": "1335416938",
				"_name": "Snakehead"
			},
			{
				"_id": "2059632369",
				"_name": "★Snakehead"
			},
			{
				"_id": "950003964",
				"_name": "Mackerel"
			},
			{
				"_id": "230968935",
				"_name": "★Mackerel"
			},
			{
				"_id": "2820732269",
				"_name": "Red Snapper"
			},
			{
				"_id": "2476792772",
				"_name": "★Red Snapper"
			},
			{
				"_id": "3743925755",
				"_name": "Cowfish"
			},
			{
				"_id": "3836210002",
				"_name": "★Cowfish"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "2108603112",
				"_name": "★Marlin"
			},
			{
				"_id": "3370613896",
				"_name": "Jellyfish"
			},
			{
				"_id": "178883198",
				"_name": "★Jellyfish"
			},
			{
				"_id": "1374563634",
				"_name": "Firefly Squid"
			},
			{
				"_id": "2585171951",
				"_name": "★Firefly Squid"
			},
			{
				"_id": "652811684",
				"_name": "Anglerfish"
			},
			{
				"_id": "3977357177",
				"_name": "★Anglerfish"
			},
			{
				"_id": "3096283143",
				"_name": "Catfish"
			},
			{
				"_id": "2379624092",
				"_name": "★Catfish"
			},
			{
				"_id": "3481974929",
				"_name": "Rockfish"
			},
			{
				"_id": "4208008714",
				"_name": "★Rockfish"
			},
			{
				"_id": "1451485483",
				"_name": "Beakfish"
			},
			{
				"_id": "1675120560",
				"_name": "★Beakfish"
			}
		]
	}
}