xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Worn Bangle"
			},
			{
				"_id": "3692624796",
				"_name": "Rocker Wrist"
			},
			{
				"_id": "2870987530",
				"_name": "Brute Bracer"
			},
			{
				"_id": "897277609",
				"_name": "Sun Bracelet"
			},
			{
				"_id": "1115450943",
				"_name": "Fiend Band"
			},
			{
				"_id": "1154727953",
				"_name": "Rusty Ring"
			},
			{
				"_id": "3722088875",
				"_name": "Pretty Ring"
			},
			{
				"_id": "2866651453",
				"_name": "Illusion Ring"
			},
			{
				"_id": "884552862",
				"_name": "Lunar Ring"
			},
			{
				"_id": "1136526344",
				"_name": "Fiend Ring"
			},
			{
				"_id": "3669448114",
				"_name": "Fire Ring"
			},
			{
				"_id": "2914018596",
				"_name": "Water Ring"
			},
			{
				"_id": "1024424117",
				"_name": "Lightning Ring"
			},
			{
				"_id": "1242056739",
				"_name": "Earth Ring"
			},
			{
				"_id": "718258630",
				"_name": "Ice Ring"
			},
			{
				"_id": "1573450064",
				"_name": "Wind Ring"
			},
			{
				"_id": "1184202312",
				"_name": "Aged Charm"
			},
			{
				"_id": "3751555058",
				"_name": "Runic Charm"
			},
			{
				"_id": "2828738404",
				"_name": "Armor Charm"
			},
			{
				"_id": "922716871",
				"_name": "Galaxy Charm"
			},
			{
				"_id": "1106819665",
				"_name": "Fiend Charm"
			},
			{
				"_id": "3639733227",
				"_name": "Blaze Charm"
			},
			{
				"_id": "2952190845",
				"_name": "Flood Charm"
			},
			{
				"_id": "1061799660",
				"_name": "Bolt Charm"
			},
			{
				"_id": "1213134458",
				"_name": "Quake Charm"
			},
			{
				"_id": "680099743",
				"_name": "Frost Charm"
			},
			{
				"_id": "1603161865",
				"_name": "Storm Charm"
			},
			{
				"_id": "1196889215",
				"_name": "Simple Badge"
			},
			{
				"_id": "3730720197",
				"_name": "Shiny Badge"
			},
			{
				"_id": "2841212243",
				"_name": "Hermes Badge"
			},
			{
				"_id": "926802160",
				"_name": "Meteor Badge"
			},
			{
				"_id": "1077596262",
				"_name": "Fiend Badge"
			},
			{
				"_id": "1108869882",
				"_name": "Cicada Sword"
			},
			{
				"_id": "3675345728",
				"_name": "Beefy Bell"
			},
			{
				"_id": "2887148502",
				"_name": "Spell Bell"
			},
			{
				"_id": "846394997",
				"_name": "Tough Bell"
			},
			{
				"_id": "1165346531",
				"_name": "Speed Bell"
			},
			{
				"_id": "3699152729",
				"_name": "Big Bottle"
			},
			{
				"_id": "2877007823",
				"_name": "Tengu Fan"
			},
			{
				"_id": "1002748510",
				"_name": "Cheery Coat"
			},
			{
				"_id": "1287883464",
				"_name": "Nail Bat"
			},
			{
				"_id": "738460461",
				"_name": "Reversword"
			},
			{
				"_id": "1526936507",
				"_name": "Turnabeads"
			},
			{
				"_id": "3255460353",
				"_name": "Reflector"
			},
			{
				"_id": "1138387149",
				"_name": "Ritzy Studs"
			},
			{
				"_id": "3671275895",
				"_name": "Sleep 'n' Study"
			},
			{
				"_id": "2916354529",
				"_name": "Die of Fate"
			},
			{
				"_id": "867212354",
				"_name": "Iron Plates"
			},
			{
				"_id": "1152888020",
				"_name": "Thick Specs"
			},
			{
				"_id": "3720281454",
				"_name": "Ancient Scale"
			},
			{
				"_id": "2864303608",
				"_name": "Venoct Gauntlet"
			},
			{
				"_id": "973525097",
				"_name": "Heavenly Sash"
			},
			{
				"_id": "1291968767",
				"_name": "Ski Mask"
			},
			{
				"_id": "767977754",
				"_name": "Sticker of Hate"
			},
			{
				"_id": "1522620812",
				"_name": "Vampiric Fangs"
			},
			{
				"_id": "3284666422",
				"_name": "Crystal Ball"
			},
			{
				"_id": "3033479328",
				"_name": "Sleepillow"
			},
			{
				"_id": "1100797588",
				"_name": "Restraint Belt"
			},
			{
				"_id": "3633678126",
				"_name": "Guard Gem"
			},
			{
				"_id": "2945628088",
				"_name": "Monkey Circlet"
			}
		]
	}
}