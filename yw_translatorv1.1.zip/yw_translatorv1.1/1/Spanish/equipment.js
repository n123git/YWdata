xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Pulsera gastada"
			},
			{
				"_id": "3692624796",
				"_name": "Pulsera punki"
			},
			{
				"_id": "2870987530",
				"_name": "Pulsera pinchos"
			},
			{
				"_id": "897277609",
				"_name": "Pulsera de sol"
			},
			{
				"_id": "1115450943",
				"_name": "Pulsera maléfica"
			},
			{
				"_id": "1154727953",
				"_name": "Anillo oxidado"
			},
			{
				"_id": "3722088875",
				"_name": "Anillo precioso"
			},
			{
				"_id": "2866651453",
				"_name": "Anillo mágico"
			},
			{
				"_id": "884552862",
				"_name": "Anillo lunar"
			},
			{
				"_id": "1136526344",
				"_name": "Anillo maléfico"
			},
			{
				"_id": "3669448114",
				"_name": "Anillo de fuego"
			},
			{
				"_id": "2914018596",
				"_name": "Anillo de agua"
			},
			{
				"_id": "1024424117",
				"_name": "Anillo relámpago"
			},
			{
				"_id": "1242056739",
				"_name": "Anillo de tierra"
			},
			{
				"_id": "718258630",
				"_name": "Anillo de hielo"
			},
			{
				"_id": "1573450064",
				"_name": "Anillo de viento"
			},
			{
				"_id": "1184202312",
				"_name": "Amuleto antiguo"
			},
			{
				"_id": "3751555058",
				"_name": "Amuleto rúnico"
			},
			{
				"_id": "2828738404",
				"_name": "Amul. blindado"
			},
			{
				"_id": "922716871",
				"_name": "Amul. galáctico"
			},
			{
				"_id": "1106819665",
				"_name": "Amul. maléfico"
			},
			{
				"_id": "3639733227",
				"_name": "Antifuego"
			},
			{
				"_id": "2952190845",
				"_name": "Antinundaciones"
			},
			{
				"_id": "1061799660",
				"_name": "Pararrayos"
			},
			{
				"_id": "1213134458",
				"_name": "Antiterremotos"
			},
			{
				"_id": "680099743",
				"_name": "Antiheladas"
			},
			{
				"_id": "1603161865",
				"_name": "Antitormentas"
			},
			{
				"_id": "1196889215",
				"_name": "Insignia sencilla"
			},
			{
				"_id": "3730720197",
				"_name": "Insignia brillante"
			},
			{
				"_id": "2841212243",
				"_name": "Insignia Hermes"
			},
			{
				"_id": "926802160",
				"_name": "Insig. meteórica"
			},
			{
				"_id": "1077596262",
				"_name": "Insignia maléfica"
			},
			{
				"_id": "1108869882",
				"_name": "Espada cigarrera"
			},
			{
				"_id": "3675345728",
				"_name": "Campan. fuerza"
			},
			{
				"_id": "2887148502",
				"_name": "Camp. hechicera"
			},
			{
				"_id": "846394997",
				"_name": "Campanilla dura"
			},
			{
				"_id": "1165346531",
				"_name": "Campanilla veloz"
			},
			{
				"_id": "3699152729",
				"_name": "Termo infinito"
			},
			{
				"_id": "2877007823",
				"_name": "Abanico Tengu"
			},
			{
				"_id": "1002748510",
				"_name": "Abrigo alegre"
			},
			{
				"_id": "1287883464",
				"_name": "Bate pinchos"
			},
			{
				"_id": "738460461",
				"_name": "Esp. reversible"
			},
			{
				"_id": "1526936507",
				"_name": "Tornador"
			},
			{
				"_id": "3255460353",
				"_name": "Reflectante"
			},
			{
				"_id": "1138387149",
				"_name": "Pend. elegantes"
			},
			{
				"_id": "3671275895",
				"_name": "Estudiotrón"
			},
			{
				"_id": "2916354529",
				"_name": "Dado fortuna"
			},
			{
				"_id": "867212354",
				"_name": "Placas de acero"
			},
			{
				"_id": "1152888020",
				"_name": "Gafotas"
			},
			{
				"_id": "3720281454",
				"_name": "Esc. milenaria"
			},
			{
				"_id": "2864303608",
				"_name": "Guant. Venocto"
			},
			{
				"_id": "973525097",
				"_name": "Fajín celestial"
			},
			{
				"_id": "1291968767",
				"_name": "Pasamontañas"
			},
			{
				"_id": "767977754",
				"_name": "Pegatina odio"
			},
			{
				"_id": "1522620812",
				"_name": "Colm. vampiro"
			},
			{
				"_id": "3284666422",
				"_name": "Bola de cristal"
			},
			{
				"_id": "3033479328",
				"_name": "Almovaga"
			},
			{
				"_id": "1100797588",
				"_name": "Cinturón control"
			},
			{
				"_id": "3633678126",
				"_name": "Gema guardiana"
			},
			{
				"_id": "2945628088",
				"_name": "Diadema simio"
			}
		]
	}
}