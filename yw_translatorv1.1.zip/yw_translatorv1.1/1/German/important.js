xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "2707808699",
				"_name": "Yo-kai-Medailliu."
			},
			{
				"_id": "1057059864",
				"_name": "Plv. d. Erblühens"
			},
			{
				"_id": "1208370318",
				"_name": "Insektennetz"
			},
			{
				"_id": "3507426612",
				"_name": "Angelrute"
			},
			{
				"_id": "2785551778",
				"_name": "Museumsticket"
			},
			{
				"_id": "917977139",
				"_name": "Tresorraumschl."
			},
			{
				"_id": "1102055589",
				"_name": "Foto von Amy"
			},
			{
				"_id": "561480000",
				"_name": "Glücksunterwäs."
			},
			{
				"_id": "1450226134",
				"_name": "Fahrrad"
			},
			{
				"_id": "3480871020",
				"_name": "Fahrrad"
			},
			{
				"_id": "3095318778",
				"_name": "Uhrenzahnrad"
			},
			{
				"_id": "639255897",
				"_name": "Uhrenschraube"
			},
			{
				"_id": "1360885199",
				"_name": "Schl. (Anwesen)"
			},
			{
				"_id": "3356763253",
				"_name": "Besonderer Ring"
			},
			{
				"_id": "3205698787",
				"_name": "Papas Papiere"
			},
			{
				"_id": "799803762",
				"_name": "Schöne Rippe"
			},
			{
				"_id": "1487616484",
				"_name": "Schulschlüssel"
			},
			{
				"_id": "173724291",
				"_name": "Noten"
			},
			{
				"_id": "2103304725",
				"_name": "Uhrenfeder"
			},
			{
				"_id": "3830756271",
				"_name": "Schuppenschl."
			},
			{
				"_id": "2471723833",
				"_name": "Signalabim-Mot."
			},
			{
				"_id": "221714074",
				"_name": "Peyn-Öl"
			},
			{
				"_id": "2049975820",
				"_name": "Wirrefü.-Lenkrad"
			},
			{
				"_id": "3812194230",
				"_name": "„Yo-kai W.“-Schl."
			},
			{
				"_id": "75586225",
				"_name": "Leckerer Pilz"
			},
			{
				"_id": "1938188839",
				"_name": "Comicbuch"
			},
			{
				"_id": "323085250",
				"_name": "Wandak. Flasche"
			},
			{
				"_id": "1682363220",
				"_name": "Gespru. Teller"
			},
			{
				"_id": "4249846510",
				"_name": "Abgew. Talisman"
			},
			{
				"_id": "2320020088",
				"_name": "Goldtofu"
			},
			{
				"_id": "338438107",
				"_name": "Spielzeugrakete"
			},
			{
				"_id": "1663768397",
				"_name": "Fußball"
			},
			{
				"_id": "4196550391",
				"_name": "Liebesgedichte"
			},
			{
				"_id": "2368042593",
				"_name": "Erfrisch. Kräuter"
			},
			{
				"_id": "496659440",
				"_name": "Klinge des Betr."
			},
			{
				"_id": "1788697446",
				"_name": "Glänz. Starfoto"
			},
			{
				"_id": "1543533829",
				"_name": "Verbl. Starfoto"
			},
			{
				"_id": "721896851",
				"_name": "S. Modellbauset"
			},
			{
				"_id": "2987267113",
				"_name": "Wertv. Ohrringe"
			},
			{
				"_id": "3305710783",
				"_name": "Zeitkapsel"
			},
			{
				"_id": "1533915420",
				"_name": "Klinge der Täus."
			},
			{
				"_id": "745177482",
				"_name": "Taifunfächer"
			},
			{
				"_id": "3043217456",
				"_name": "Immerblume"
			},
			{
				"_id": "3261391014",
				"_name": "Schläng.trophäe"
			},
			{
				"_id": "1390148919",
				"_name": "Plauzentrophäe"
			},
			{
				"_id": "635227553",
				"_name": "Miautrophäe"
			},
			{
				"_id": "1159414852",
				"_name": "Quasseltrophäe"
			},
			{
				"_id": "840725714",
				"_name": "Wiehertrophäe"
			},
			{
				"_id": "2870289768",
				"_name": "Löwentrophäe"
			},
			{
				"_id": "3692172798",
				"_name": "Kapuzentrophäe"
			},
			{
				"_id": "1115062365",
				"_name": "Runzeltrophäe"
			},
			{
				"_id": "896643275",
				"_name": "Stumpfh.trophäe"
			},
			{
				"_id": "2893603185",
				"_name": "Vatertrophäe"
			},
			{
				"_id": "3682587111",
				"_name": "Tengutrophäe"
			},
			{
				"_id": "1270926454",
				"_name": "Zikadentrophäe"
			},
			{
				"_id": "1019739360",
				"_name": "Mochitrophäe"
			},
			{
				"_id": "1849038727",
				"_name": "Federtrophäe"
			},
			{
				"_id": "422651665",
				"_name": "Möchteg.trophäe"
			},
			{
				"_id": "2151184043",
				"_name": "Zinkertrophäe"
			},
			{
				"_id": "4148119101",
				"_name": "Trosttrophäe"
			},
			{
				"_id": "1767625630",
				"_name": "Wildheitstrophäe"
			},
			{
				"_id": "509403912",
				"_name": "Schmlzl.trophäe"
			},
			{
				"_id": "2270540466",
				"_name": "Flattertrophäe"
			},
			{
				"_id": "4031939108",
				"_name": "Shoguntrophäe"
			},
			{
				"_id": "1626185653",
				"_name": "Matschtrophäe"
			},
			{
				"_id": "401256227",
				"_name": "Träumertrophäe"
			},
			{
				"_id": "1999447750",
				"_name": "Neppertrophäe"
			},
			{
				"_id": "2758224",
				"_name": "Kimonotrophäe"
			},
			{
				"_id": "2569226218",
				"_name": "Hecheltrophäe"
			},
			{
				"_id": "3995367292",
				"_name": "Summtrophäe"
			},
			{
				"_id": "1883300575",
				"_name": "Kappatrophäe"
			},
			{
				"_id": "122147401",
				"_name": "Abkupfertrophäe"
			},
			{
				"_id": "2655945715",
				"_name": "Knuddeltrophäe"
			},
			{
				"_id": "3913921381",
				"_name": "Meistertrophäe"
			},
			{
				"_id": "2046209780",
				"_name": "Giftzahntrophäe"
			},
			{
				"_id": "250715746",
				"_name": "Flaschentrophäe"
			},
			{
				"_id": "4038408713",
				"_name": "Mähnentrophäe"
			},
			{
				"_id": "2276592287",
				"_name": "Zittertrophäe"
			},
			{
				"_id": "515595045",
				"_name": "Huttrophäe"
			},
			{
				"_id": "1773956019",
				"_name": "Stelzentrophäe"
			},
			{
				"_id": "4158193168",
				"_name": "Klappertrophäe"
			},
			{
				"_id": "2162151046",
				"_name": "Geweihtrophäe"
			},
			{
				"_id": "433495868",
				"_name": "Amortrophäe"
			},
			{
				"_id": "1859235754",
				"_name": "Humortrophäe"
			},
			{
				"_id": "4268667451",
				"_name": "Horntrophäe"
			},
			{
				"_id": "2305393325",
				"_name": "Schattentrophäe"
			},
			{
				"_id": "3920497480",
				"_name": "Zahnsto.trophäe"
			},
			{
				"_id": "2661891038",
				"_name": "Aaltrophäe"
			},
			{
				"_id": "127953508",
				"_name": "Haifischtrophäe"
			},
			{
				"_id": "1890015986",
				"_name": "Dämontrophäe"
			},
			{
				"_id": "4005810001",
				"_name": "Seetangtrophäe"
			},
			{
				"_id": "2579824583",
				"_name": "Drachentrophäe"
			},
			{
				"_id": "13479549",
				"_name": "Muscheltrophäe"
			},
			{
				"_id": "2009767659",
				"_name": "Trikloptrophäe"
			},
			{
				"_id": "3883238266",
				"_name": "Zyklopentrophäe"
			},
			{
				"_id": "1319758496",
				"_name": "Saphirglocke"
			},
			{
				"_id": "3617635098",
				"_name": "Smaragdglocke"
			},
			{
				"_id": "2695334796",
				"_name": "Rubinglocke"
			},
			{
				"_id": "1052974639",
				"_name": "Topasglocke"
			},
			{
				"_id": "1237593785",
				"_name": "Diamantglocke"
			},
			{
				"_id": "4158121970",
				"_name": "Kompon.porträt"
			},
			{
				"_id": "1860089416",
				"_name": "Froschanatomie"
			},
			{
				"_id": "433686238",
				"_name": "Yo-kai-Führer"
			},
			{
				"_id": "2277315453",
				"_name": "Thermometer"
			},
			{
				"_id": "4038730731",
				"_name": "Foto des Rektors"
			},
			{
				"_id": "1773367889",
				"_name": "Noko-Leder"
			},
			{
				"_id": "515130055",
				"_name": "Noko-Kot"
			},
			{
				"_id": "2383109974",
				"_name": "Noko-Spur"
			},
			{
				"_id": "4178341824",
				"_name": "Detektivabz. 1"
			},
			{
				"_id": "2580276773",
				"_name": "Zerbroch. Teller"
			},
			{
				"_id": "4006401715",
				"_name": "Angekn. Gurke"
			},
			{
				"_id": "2009433865",
				"_name": "Staubig. Amulett"
			},
			{
				"_id": "12760991",
				"_name": "Detektivabz. 2"
			},
			{
				"_id": "2661687868",
				"_name": "Detektivabz. 3"
			},
			{
				"_id": "3919647402",
				"_name": "Kaputter Eimer"
			},
			{
				"_id": "1890075408",
				"_name": "Plastikflasche"
			},
			{
				"_id": "128938886",
				"_name": "Zerfled. Magazin"
			},
			{
				"_id": "2534436375",
				"_name": "Detektivabz. 4"
			},
			{
				"_id": "3759627905",
				"_name": "KD-Notiz"
			},
			{
				"_id": "3001464294",
				"_name": "Detektivabz. 5"
			},
			{
				"_id": "3319891312",
				"_name": "Aushang"
			},
			{
				"_id": "1558762698",
				"_name": "Popstar-Poster"
			},
			{
				"_id": "737141852",
				"_name": "Leere Dose"
			},
			{
				"_id": "3045814783",
				"_name": "Leere Flasche"
			},
			{
				"_id": "3263971689",
				"_name": "Löchrige Stiefel"
			},
			{
				"_id": "1535447251",
				"_name": "Feuerwerksreste"
			},
			{
				"_id": "746725445",
				"_name": "Plastiktüte"
			}
		]
	}
}