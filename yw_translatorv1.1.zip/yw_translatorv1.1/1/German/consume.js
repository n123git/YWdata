xmlval = {
	"items": {
		"item": [
			{
				"_id": "1803927674",
				"_name": "Pflaum.-Reisball"
			},
			{
				"_id": "4069298624",
				"_name": "Senfbl.-Reisball"
			},
			{
				"_id": "2240520534",
				"_name": "Rogen-Reisball"
			},
			{
				"_id": "468661493",
				"_name": "Shrimp-Reisball"
			},
			{
				"_id": "1783081549",
				"_name": "Sandwich"
			},
			{
				"_id": "4082039799",
				"_name": "Creme-Brötchen"
			},
			{
				"_id": "1831497300",
				"_name": "Curry-Brötchen"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Bähgel"
			},
			{
				"_id": "1744901140",
				"_name": "10 ct-Kaugummi"
			},
			{
				"_id": "4043851182",
				"_name": "Zähes Bonbon"
			},
			{
				"_id": "2249159992",
				"_name": "Rie.-Reiscracker"
			},
			{
				"_id": "409723035",
				"_name": "Fruchtdrops"
			},
			{
				"_id": "1869402125",
				"_name": "Rasureis"
			},
			{
				"_id": "4133847479",
				"_name": "Kandierter Apfel"
			},
			{
				"_id": "1774419491",
				"_name": "Milch"
			},
			{
				"_id": "4039782297",
				"_name": "Kaffeemilch"
			},
			{
				"_id": "2278366991",
				"_name": "Fruchtmilch"
			},
			{
				"_id": "430541484",
				"_name": "Superfr. Milch"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Seelentee"
			},
			{
				"_id": "2189560202",
				"_name": "Inspirator Y"
			},
			{
				"_id": "484875305",
				"_name": "Volt eXtrem"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Doppelburger"
			},
			{
				"_id": "488961566",
				"_name": "Big Schmeck"
			},
			{
				"_id": "1858787071",
				"_name": "Instant-Suppe"
			},
			{
				"_id": "4156786501",
				"_name": "Nudeln in Brühe"
			},
			{
				"_id": "2160375763",
				"_name": "Deluxe-Suppe"
			},
			{
				"_id": "513811056",
				"_name": "Nudel-Allerlei"
			},
			{
				"_id": "1683291125",
				"_name": "Gyoza"
			},
			{
				"_id": "4250774095",
				"_name": "Leber mit Lauch"
			},
			{
				"_id": "2321193689",
				"_name": "Krabben-Omelett"
			},
			{
				"_id": "339611514",
				"_name": "Chili-Garnelen"
			},
			{
				"_id": "3539717416",
				"_name": "Karotte"
			},
			{
				"_id": "1274190994",
				"_name": "Gurke"
			},
			{
				"_id": "1022733316",
				"_name": "Bambussprosse"
			},
			{
				"_id": "2727426471",
				"_name": "Kiefernpilz"
			},
			{
				"_id": "3502076785",
				"_name": "Hühnerkeule"
			},
			{
				"_id": "1236542155",
				"_name": "Bauchspeck"
			},
			{
				"_id": "1051923037",
				"_name": "Rinderzunge"
			},
			{
				"_id": "2698479614",
				"_name": "Marmori. Fleisch"
			},
			{
				"_id": "3514767686",
				"_name": "Getrock. Makrele"
			},
			{
				"_id": "1215711484",
				"_name": "Glbschw.makrele"
			},
			{
				"_id": "1064401002",
				"_name": "Frischer Seeigel"
			},
			{
				"_id": "2702568905",
				"_name": "Feinst. Thunfisch"
			},
			{
				"_id": "320924352",
				"_name": "Kleine Klugel"
			},
			{
				"_id": "2317990778",
				"_name": "Mittlere Klugel"
			},
			{
				"_id": "4247686124",
				"_name": "Große Klugel"
			},
			{
				"_id": "1665801807",
				"_name": "Riesenklugel"
			},
			{
				"_id": "340602585",
				"_name": "Heilige Klugel"
			},
			{
				"_id": "397252210",
				"_name": "Maratonikum"
			},
			{
				"_id": "2393163720",
				"_name": "Maratonikum+"
			},
			{
				"_id": "279199406",
				"_name": "Angrf.almanach"
			},
			{
				"_id": "2309844756",
				"_name": "Tolle Techniken"
			},
			{
				"_id": "4272578434",
				"_name": "Spirit. Studien"
			},
			{
				"_id": "469268883",
				"_name": "Ärmel hoch"
			},
			{
				"_id": "2196842537",
				"_name": "Faust&Fuß, Bd. 1"
			},
			{
				"_id": "4126546111",
				"_name": "Faust&Fuß, Bd. 2"
			},
			{
				"_id": "1804766492",
				"_name": "Technik-Führer"
			},
			{
				"_id": "479575434",
				"_name": "Technik-Lexikon"
			},
			{
				"_id": "2241653808",
				"_name": "Besser blocken"
			},
			{
				"_id": "4070300838",
				"_name": "Alles auf Abwehr"
			},
			{
				"_id": "1646575927",
				"_name": "Heil mich, Eng."
			},
			{
				"_id": "354677153",
				"_name": "Mach's gut, Eng."
			},
			{
				"_id": "1977907268",
				"_name": "Der kl. Fiesling"
			},
			{
				"_id": "48449746",
				"_name": "So richtig fies"
			},
			{
				"_id": "2615810408",
				"_name": "Helfers Helfer #7"
			},
			{
				"_id": "3974965758",
				"_name": "Helfers Helfer S"
			},
			{
				"_id": "367732779",
				"_name": "Stärketalisman"
			},
			{
				"_id": "2363652497",
				"_name": "Geistestalisman"
			},
			{
				"_id": "4226107655",
				"_name": "Abwehrtalisman"
			},
			{
				"_id": "1703009444",
				"_name": "Tempotalisman"
			},
			{
				"_id": "338248220",
				"_name": "Fiese Medizin"
			},
			{
				"_id": "2367689638",
				"_name": "Bittere Medizin"
			},
			{
				"_id": "4196868912",
				"_name": "Mächtig. Medizin"
			},
			{
				"_id": "376437829",
				"_name": "Fluchthelferlein"
			},
			{
				"_id": "291919001",
				"_name": "Bronzepuppe"
			},
			{
				"_id": "2288977187",
				"_name": "Silberpuppe"
			},
			{
				"_id": "4285019573",
				"_name": "Goldpuppe"
			},
			{
				"_id": "2908180302",
				"_name": "Fischköder"
			},
			{
				"_id": "878583540",
				"_name": "Dunkler Sirup"
			},
			{
				"_id": "2592718716",
				"_name": "Rote Münze"
			},
			{
				"_id": "58781382",
				"_name": "Gelbe Münze"
			},
			{
				"_id": "1955061328",
				"_name": "Orange Münze"
			},
			{
				"_id": "3940764659",
				"_name": "Rosa Münze"
			},
			{
				"_id": "2648996709",
				"_name": "Grüne Münze"
			},
			{
				"_id": "82651871",
				"_name": "Blaue Münze"
			},
			{
				"_id": "1944721993",
				"_name": "Lila Münze"
			},
			{
				"_id": "3814000600",
				"_name": "Hellblaue Münze"
			},
			{
				"_id": "3141306787",
				"_name": "Saphirmünze"
			},
			{
				"_id": "3426466101",
				"_name": "Smaragdmünze"
			},
			{
				"_id": "1381969046",
				"_name": "Rubinmünze"
			},
			{
				"_id": "626531328",
				"_name": "Topasmünze"
			},
			{
				"_id": "573954073",
				"_name": "Diamantmünze"
			},
			{
				"_id": "3159444922",
				"_name": "Jubelmünze"
			},
			{
				"_id": "3411442988",
				"_name": "5-Sterne-Münze"
			},
			{
				"_id": "1542021309",
				"_name": "Spezialmünze"
			},
			{
				"_id": "2895455609",
				"_name": "Tanzsternchen"
			},
			{
				"_id": "440013732",
				"_name": "Legend. Klinge"
			},
			{
				"_id": "2201174558",
				"_name": "Verfluchte Klinge"
			},
			{
				"_id": "2220787207",
				"_name": "Heilige Klinge"
			},
			{
				"_id": "4097077896",
				"_name": "Seele d. Gener."
			},
			{
				"_id": "1783686955",
				"_name": "Liebesknaller"
			},
			{
				"_id": "492296125",
				"_name": "Elektrokugel"
			},
			{
				"_id": "1676061440",
				"_name": "Unbezw. Seele"
			},
			{
				"_id": "2586342239",
				"_name": "Platinbarren"
			},
			{
				"_id": "350329750",
				"_name": "Schneest.-Umhg"
			},
			{
				"_id": "1948652147",
				"_name": "Zepter der Liebe"
			},
			{
				"_id": "4082742929",
				"_name": "Gletsch.klammer"
			},
			{
				"_id": "52503269",
				"_name": "Trainingshanteln"
			},
			{
				"_id": "1934349930",
				"_name": "Splitter d. Bösen"
			},
			{
				"_id": "3979297737",
				"_name": "Jugendpuder"
			},
			{
				"_id": "3742966091",
				"_name": "Tropf. d. Freude"
			},
			{
				"_id": "2638591814",
				"_name": "Drachenkugel"
			},
			{
				"_id": "3930228688",
				"_name": "Weihwasser"
			},
			{
				"_id": "2063440449",
				"_name": "Schäb. Schuppe"
			},
			{
				"_id": "234531543",
				"_name": "Viptor-Aura"
			},
			{
				"_id": "1594573232",
				"_name": "Abgen. Handsch."
			},
			{
				"_id": "671904038",
				"_name": "Gespru. Kristall"
			},
			{
				"_id": "2969903260",
				"_name": "Kristallsplitter"
			},
			{
				"_id": "3322023946",
				"_name": "Sauberfix"
			},
			{
				"_id": "1483113897",
				"_name": "Vergilb. Schärpe"
			},
			{
				"_id": "794932543",
				"_name": "Schlichter Ring"
			},
			{
				"_id": "3060327557",
				"_name": "Blanker Talisman"
			},
			{
				"_id": "3245331475",
				"_name": "Rubin"
			},
			{
				"_id": "1372637570",
				"_name": "Aquamarin"
			},
			{
				"_id": "651688212",
				"_name": "Topas"
			},
			{
				"_id": "1175482609",
				"_name": "Turmalin"
			},
			{
				"_id": "823607399",
				"_name": "Opal"
			},
			{
				"_id": "2820542941",
				"_name": "Smaragd"
			}
		]
	}
}