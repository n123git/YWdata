xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Einf. Armreif"
			},
			{
				"_id": "3692624796",
				"_name": "Nietenarmband"
			},
			{
				"_id": "2870987530",
				"_name": "Abd. d. Rohlings"
			},
			{
				"_id": "897277609",
				"_name": "Arf. der Sonne"
			},
			{
				"_id": "1115450943",
				"_name": "Arf. d. Unholds"
			},
			{
				"_id": "1154727953",
				"_name": "Rostiger Ring"
			},
			{
				"_id": "3722088875",
				"_name": "Hübscher Ring"
			},
			{
				"_id": "2866651453",
				"_name": "Ring der Illusion"
			},
			{
				"_id": "884552862",
				"_name": "Ring d. Mondl."
			},
			{
				"_id": "1136526344",
				"_name": "Ring d. Unholds"
			},
			{
				"_id": "3669448114",
				"_name": "Ring des Feuers"
			},
			{
				"_id": "2914018596",
				"_name": "Ring d. Wassers"
			},
			{
				"_id": "1024424117",
				"_name": "Ring des Blitzes"
			},
			{
				"_id": "1242056739",
				"_name": "Ring der Erde"
			},
			{
				"_id": "718258630",
				"_name": "Ring des Eises"
			},
			{
				"_id": "1573450064",
				"_name": "Ring des Windes"
			},
			{
				"_id": "1184202312",
				"_name": "Altes Amulett"
			},
			{
				"_id": "3751555058",
				"_name": "Runenamulett"
			},
			{
				"_id": "2828738404",
				"_name": "Rüstungsamulett"
			},
			{
				"_id": "922716871",
				"_name": "Amu. der Galaxie"
			},
			{
				"_id": "1106819665",
				"_name": "Amu. d. Unholds"
			},
			{
				"_id": "3639733227",
				"_name": "Amu. d. Brandes"
			},
			{
				"_id": "2952190845",
				"_name": "Amulett der Flut"
			},
			{
				"_id": "1061799660",
				"_name": "Amu d. Gewitters"
			},
			{
				"_id": "1213134458",
				"_name": "Amu. d. Bebens"
			},
			{
				"_id": "680099743",
				"_name": "Amu. d. Frostes"
			},
			{
				"_id": "1603161865",
				"_name": "Amu. d. Sturms"
			},
			{
				"_id": "1196889215",
				"_name": "Einf. Emblem"
			},
			{
				"_id": "3730720197",
				"_name": "Glänz. Emblem"
			},
			{
				"_id": "2841212243",
				"_name": "Hermes-Emblem"
			},
			{
				"_id": "926802160",
				"_name": "Sterns.-Emblem"
			},
			{
				"_id": "1077596262",
				"_name": "Embl. d. Unholds"
			},
			{
				"_id": "1108869882",
				"_name": "Zikadenschwert"
			},
			{
				"_id": "3675345728",
				"_name": "Stärkungsglocke"
			},
			{
				"_id": "2887148502",
				"_name": "Geistesglocke"
			},
			{
				"_id": "846394997",
				"_name": "Schutzglocke"
			},
			{
				"_id": "1165346531",
				"_name": "Geschw.glocke"
			},
			{
				"_id": "3699152729",
				"_name": "Immerv. Flasche"
			},
			{
				"_id": "2877007823",
				"_name": "Tengu-Fächer"
			},
			{
				"_id": "1002748510",
				"_name": "Muntermantel"
			},
			{
				"_id": "1287883464",
				"_name": "Nagelkeule"
			},
			{
				"_id": "738460461",
				"_name": "Umgeschwert"
			},
			{
				"_id": "1526936507",
				"_name": "Wandelstein"
			},
			{
				"_id": "3255460353",
				"_name": "Reflektor"
			},
			{
				"_id": "1138387149",
				"_name": "Midas-Ohrringe"
			},
			{
				"_id": "3671275895",
				"_name": "Schl.-Lernomat"
			},
			{
				"_id": "2916354529",
				"_name": "Schicksalswürfel"
			},
			{
				"_id": "867212354",
				"_name": "Eisenplatten"
			},
			{
				"_id": "1152888020",
				"_name": "Dicke Brille"
			},
			{
				"_id": "3720281454",
				"_name": "Antike Schuppe"
			},
			{
				"_id": "2864303608",
				"_name": "Viptor-Handsch."
			},
			{
				"_id": "973525097",
				"_name": "Himmli. Schärpe"
			},
			{
				"_id": "1291968767",
				"_name": "Sturmhaube"
			},
			{
				"_id": "767977754",
				"_name": "Aufkl. d. Hasses"
			},
			{
				"_id": "1522620812",
				"_name": "Vampirzähne"
			},
			{
				"_id": "3284666422",
				"_name": "Kristallkugel"
			},
			{
				"_id": "3033479328",
				"_name": "Entspngs.kissen"
			},
			{
				"_id": "1100797588",
				"_name": "Zurückhalt.gürtel"
			},
			{
				"_id": "3633678126",
				"_name": "Schutzstein"
			},
			{
				"_id": "2945628088",
				"_name": "Affendiadem"
			}
		]
	}
}