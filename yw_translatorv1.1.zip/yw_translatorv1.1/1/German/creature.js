xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Grüne Zikade"
			},
			{
				"_id": "3460879014",
				"_name": "Grüne Zikade★"
			},
			{
				"_id": "1228371524",
				"_name": "Braune Zikade"
			},
			{
				"_id": "1463911196",
				"_name": "Braune Zikade★"
			},
			{
				"_id": "1043351250",
				"_name": "Abendzikade"
			},
			{
				"_id": "541504394",
				"_name": "Abendzikade★"
			},
			{
				"_id": "2689913713",
				"_name": "Nashornkäfer"
			},
			{
				"_id": "2969153051",
				"_name": "Nashornkäfer★"
			},
			{
				"_id": "3612599271",
				"_name": "Dorcus-H.käfer"
			},
			{
				"_id": "3355352717",
				"_name": "Dorcus-H.käfer★"
			},
			{
				"_id": "1314566749",
				"_name": "Sägz.-Hir.käfer"
			},
			{
				"_id": "2500818410",
				"_name": "Sägz.-Hir.käfer★"
			},
			{
				"_id": "962429643",
				"_name": "Heuschrecke"
			},
			{
				"_id": "3792192892",
				"_name": "Heuschrecke★"
			},
			{
				"_id": "2850201434",
				"_name": "Gottesanbeterin"
			},
			{
				"_id": "2063668422",
				"_name": "Gottesanbet.★"
			},
			{
				"_id": "3739594700",
				"_name": "Wanderheus."
			},
			{
				"_id": "201729104",
				"_name": "Wanderheus.★"
			},
			{
				"_id": "3189909033",
				"_name": "Leuchtkäfer"
			},
			{
				"_id": "2455941619",
				"_name": "Leuchtkäfer★"
			},
			{
				"_id": "3374651071",
				"_name": "Schw.schwanz"
			},
			{
				"_id": "3848634725",
				"_name": "Schw.schwanz★"
			},
			{
				"_id": "1345079045",
				"_name": "Scheckenbock"
			},
			{
				"_id": "2087506143",
				"_name": "Scheckenbock★"
			},
			{
				"_id": "657160083",
				"_name": "Rosenkäfer"
			},
			{
				"_id": "191619145",
				"_name": "Rosenkäfer★"
			},
			{
				"_id": "3109020208",
				"_name": "Marienkäfer"
			},
			{
				"_id": "2614427096",
				"_name": "Marienkäfer★"
			},
			{
				"_id": "3522973129",
				"_name": "Schildkröte"
			},
			{
				"_id": "562354621",
				"_name": "Schildkröte★"
			},
			{
				"_id": "1224023155",
				"_name": "Schwarzbarsch"
			},
			{
				"_id": "2973484076",
				"_name": "Schw.barsch★"
			},
			{
				"_id": "1072835813",
				"_name": "Huchen"
			},
			{
				"_id": "3325883578",
				"_name": "Huchen★"
			},
			{
				"_id": "2711009606",
				"_name": "Karpfen"
			},
			{
				"_id": "2496471005",
				"_name": "Karpfen★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "3821678411",
				"_name": "Ayu★"
			},
			{
				"_id": "1335416938",
				"_name": "Schl.kopffisch"
			},
			{
				"_id": "2059632369",
				"_name": "Schl.kopffisch★"
			},
			{
				"_id": "950003964",
				"_name": "Makrele"
			},
			{
				"_id": "230968935",
				"_name": "Makrele★"
			},
			{
				"_id": "2820732269",
				"_name": "Roter Schnapper"
			},
			{
				"_id": "2476792772",
				"_name": "R. Schnapper★"
			},
			{
				"_id": "3743925755",
				"_name": "Kofferfisch"
			},
			{
				"_id": "3836210002",
				"_name": "Kofferfisch★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "2108603112",
				"_name": "Marlin★"
			},
			{
				"_id": "3370613896",
				"_name": "Qualle"
			},
			{
				"_id": "178883198",
				"_name": "Qualle★"
			},
			{
				"_id": "1374563634",
				"_name": "Leuchtkalmar"
			},
			{
				"_id": "2585171951",
				"_name": "Leuchtkalmar★"
			},
			{
				"_id": "652811684",
				"_name": "Seeteufel"
			},
			{
				"_id": "3977357177",
				"_name": "Seeteufel★"
			},
			{
				"_id": "3096283143",
				"_name": "Wels"
			},
			{
				"_id": "2379624092",
				"_name": "Wels★"
			},
			{
				"_id": "3481974929",
				"_name": "Skorpionfisch"
			},
			{
				"_id": "4208008714",
				"_name": "Skorpionfisch★"
			},
			{
				"_id": "1451485483",
				"_name": "Papageienfisch"
			},
			{
				"_id": "1675120560",
				"_name": "Papageifisch★"
			}
		]
	}
}