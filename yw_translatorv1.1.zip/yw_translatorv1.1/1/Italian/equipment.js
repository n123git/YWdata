xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Bracc. consum."
			},
			{
				"_id": "3692624796",
				"_name": "Bracc. chiodato"
			},
			{
				"_id": "2870987530",
				"_name": "Bracciale brutale"
			},
			{
				"_id": "897277609",
				"_name": "Braccial. solare"
			},
			{
				"_id": "1115450943",
				"_name": "Bracc. malvagio"
			},
			{
				"_id": "1154727953",
				"_name": "Anello arruggin."
			},
			{
				"_id": "3722088875",
				"_name": "Anello grazioso"
			},
			{
				"_id": "2866651453",
				"_name": "Anello illusorio"
			},
			{
				"_id": "884552862",
				"_name": "Anello lunare"
			},
			{
				"_id": "1136526344",
				"_name": "Anello malvagio"
			},
			{
				"_id": "3669448114",
				"_name": "Anello fuoco"
			},
			{
				"_id": "2914018596",
				"_name": "Anello acqua"
			},
			{
				"_id": "1024424117",
				"_name": "Anello tuono"
			},
			{
				"_id": "1242056739",
				"_name": "Anello terra"
			},
			{
				"_id": "718258630",
				"_name": "Anello ghiaccio"
			},
			{
				"_id": "1573450064",
				"_name": "Anello vento"
			},
			{
				"_id": "1184202312",
				"_name": "Amuleto antico"
			},
			{
				"_id": "3751555058",
				"_name": "Amuleto runico"
			},
			{
				"_id": "2828738404",
				"_name": "Amu. corazzato"
			},
			{
				"_id": "922716871",
				"_name": "Amu. galattico"
			},
			{
				"_id": "1106819665",
				"_name": "Amu. malvagio"
			},
			{
				"_id": "3639733227",
				"_name": "Amu. anti-fiamma"
			},
			{
				"_id": "2952190845",
				"_name": "Amu. anti-acqua"
			},
			{
				"_id": "1061799660",
				"_name": "Amu. anti-fulmin."
			},
			{
				"_id": "1213134458",
				"_name": "Amu. anti-terra"
			},
			{
				"_id": "680099743",
				"_name": "Amu. anti-gelo"
			},
			{
				"_id": "1603161865",
				"_name": "Amu. anti-vento"
			},
			{
				"_id": "1196889215",
				"_name": "Stem. semplice"
			},
			{
				"_id": "3730720197",
				"_name": "Stemma brillante"
			},
			{
				"_id": "2841212243",
				"_name": "Stemma Ermete"
			},
			{
				"_id": "926802160",
				"_name": "Stemma meteora"
			},
			{
				"_id": "1077596262",
				"_name": "Stem. malvagio"
			},
			{
				"_id": "1108869882",
				"_name": "Spada cicala"
			},
			{
				"_id": "3675345728",
				"_name": "Camp. robusta"
			},
			{
				"_id": "2887148502",
				"_name": "Campana magica"
			},
			{
				"_id": "846394997",
				"_name": "Campana spessa"
			},
			{
				"_id": "1165346531",
				"_name": "Campana veloce"
			},
			{
				"_id": "3699152729",
				"_name": "Bottiglia infinita"
			},
			{
				"_id": "2877007823",
				"_name": "Ventaglio tengu"
			},
			{
				"_id": "1002748510",
				"_name": "Giacca allegra"
			},
			{
				"_id": "1287883464",
				"_name": "Mazza chiodata"
			},
			{
				"_id": "738460461",
				"_name": "Invertispada"
			},
			{
				"_id": "1526936507",
				"_name": "Invertigemme"
			},
			{
				"_id": "3255460353",
				"_name": "Riflettore"
			},
			{
				"_id": "1138387149",
				"_name": "Orecchini luss."
			},
			{
				"_id": "3671275895",
				"_name": "Sonno dello stu."
			},
			{
				"_id": "2916354529",
				"_name": "Dado del fato"
			},
			{
				"_id": "867212354",
				"_name": "Piastre di ferro"
			},
			{
				"_id": "1152888020",
				"_name": "Occhiali spessi"
			},
			{
				"_id": "3720281454",
				"_name": "Scaglia antica"
			},
			{
				"_id": "2864303608",
				"_name": "Guanto di Velen."
			},
			{
				"_id": "973525097",
				"_name": "Fascia angelica"
			},
			{
				"_id": "1291968767",
				"_name": "Passamontagna"
			},
			{
				"_id": "767977754",
				"_name": "Adesivo odio"
			},
			{
				"_id": "1522620812",
				"_name": "Zanne vampiro"
			},
			{
				"_id": "3284666422",
				"_name": "Sfera di cristallo"
			},
			{
				"_id": "3033479328",
				"_name": "Cuscisonno"
			},
			{
				"_id": "1100797588",
				"_name": "Cintura calma"
			},
			{
				"_id": "3633678126",
				"_name": "Gem. guardiana"
			},
			{
				"_id": "2945628088",
				"_name": "Cerchio scimm."
			}
		]
	}
}