xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "2707808699",
				"_name": "Medagli. Yo-kai"
			},
			{
				"_id": "1057059864",
				"_name": "Polvere boccioli"
			},
			{
				"_id": "1208370318",
				"_name": "Retino insetti"
			},
			{
				"_id": "3507426612",
				"_name": "Canna da pesca"
			},
			{
				"_id": "2785551778",
				"_name": "Bigl. del museo"
			},
			{
				"_id": "917977139",
				"_name": "Chiave sicurezza"
			},
			{
				"_id": "1102055589",
				"_name": "Foto di Amy"
			},
			{
				"_id": "561480000",
				"_name": "Mut. dell'anziano"
			},
			{
				"_id": "1450226134",
				"_name": "Bicicletta"
			},
			{
				"_id": "3480871020",
				"_name": "Bicicletta"
			},
			{
				"_id": "3095318778",
				"_name": "Rotella orologio"
			},
			{
				"_id": "639255897",
				"_name": "Vitina orologio"
			},
			{
				"_id": "1360885199",
				"_name": "Chiave vec. villa"
			},
			{
				"_id": "3356763253",
				"_name": "Anello speciale"
			},
			{
				"_id": "3205698787",
				"_name": "Doc. di papà"
			},
			{
				"_id": "799803762",
				"_name": "Costola carina"
			},
			{
				"_id": "1487616484",
				"_name": "Chiavi scuola"
			},
			{
				"_id": "173724291",
				"_name": "Spartito music."
			},
			{
				"_id": "2103304725",
				"_name": "Molla orologio"
			},
			{
				"_id": "3830756271",
				"_name": "Chiave baracca"
			},
			{
				"_id": "2471723833",
				"_name": "Mot. Amplicamp"
			},
			{
				"_id": "221714074",
				"_name": "Olio Dolorr"
			},
			{
				"_id": "2049975820",
				"_name": "Vol. Demanone"
			},
			{
				"_id": "3812194230",
				"_name": "Chiave Yo-kai W."
			},
			{
				"_id": "75586225",
				"_name": "Fungo gustoso"
			},
			{
				"_id": "1938188839",
				"_name": "Giorn. a fumetti"
			},
			{
				"_id": "323085250",
				"_name": "Bott. Cammikap."
			},
			{
				"_id": "1682363220",
				"_name": "Piatto schegg."
			},
			{
				"_id": "4249846510",
				"_name": "Amu. malridotto"
			},
			{
				"_id": "2320020088",
				"_name": "Tofu d'oro"
			},
			{
				"_id": "338438107",
				"_name": "Missile giocatt."
			},
			{
				"_id": "1663768397",
				"_name": "Pallone da calcio"
			},
			{
				"_id": "4196550391",
				"_name": "Poesie d'amore"
			},
			{
				"_id": "2368042593",
				"_name": "Erbe rinfrescanti"
			},
			{
				"_id": "496659440",
				"_name": "Lama tradita"
			},
			{
				"_id": "1788697446",
				"_name": "Foto limpida star"
			},
			{
				"_id": "1543533829",
				"_name": "Foto sbiad. star"
			},
			{
				"_id": "721896851",
				"_name": "Modellino raro"
			},
			{
				"_id": "2987267113",
				"_name": "Orecchini prez."
			},
			{
				"_id": "3305710783",
				"_name": "Capsula tempor."
			},
			{
				"_id": "1533915420",
				"_name": "Lama dell'illusio."
			},
			{
				"_id": "745177482",
				"_name": "Ventaglio tifone"
			},
			{
				"_id": "3043217456",
				"_name": "Fiore eterno"
			},
			{
				"_id": "3261391014",
				"_name": "Trofeo Rettile"
			},
			{
				"_id": "1390148919",
				"_name": "Trofeo Fame"
			},
			{
				"_id": "635227553",
				"_name": "Trofeo Gattino"
			},
			{
				"_id": "1159414852",
				"_name": "Trofeo Nonna"
			},
			{
				"_id": "840725714",
				"_name": "Trofeo Cavallo"
			},
			{
				"_id": "2870289768",
				"_name": "Trofeo Criniera"
			},
			{
				"_id": "3692172798",
				"_name": "Trof. Cappuccio"
			},
			{
				"_id": "1115062365",
				"_name": "Trofeo Rugosità"
			},
			{
				"_id": "896643275",
				"_name": "Trofeo Katana"
			},
			{
				"_id": "2893603185",
				"_name": "Trofeo Papà"
			},
			{
				"_id": "3682587111",
				"_name": "Trofeo Tengu"
			},
			{
				"_id": "1270926454",
				"_name": "Trofeo Cicala"
			},
			{
				"_id": "1019739360",
				"_name": "Trofeo Macho"
			},
			{
				"_id": "1849038727",
				"_name": "Trofeo Volatile"
			},
			{
				"_id": "422651665",
				"_name": "Trof. Vorrei tanto"
			},
			{
				"_id": "2151184043",
				"_name": "Trofeo Azzardo"
			},
			{
				"_id": "4148119101",
				"_name": "Trof. Consolaz."
			},
			{
				"_id": "1767625630",
				"_name": "Trofeo Selvaggio"
			},
			{
				"_id": "509403912",
				"_name": "Trofeo Ciuffo"
			},
			{
				"_id": "2270540466",
				"_name": "Trof. Svolazzam."
			},
			{
				"_id": "4031939108",
				"_name": "Trofeo Shogun"
			},
			{
				"_id": "1626185653",
				"_name": "Trofeo Denaro"
			},
			{
				"_id": "401256227",
				"_name": "Trofeo Ebete"
			},
			{
				"_id": "1999447750",
				"_name": "Trofeo Sacco"
			},
			{
				"_id": "2758224",
				"_name": "Trofeo Kimono"
			},
			{
				"_id": "2569226218",
				"_name": "Trofeo Cane"
			},
			{
				"_id": "3995367292",
				"_name": "Trofeo Ronzio"
			},
			{
				"_id": "1883300575",
				"_name": "Trofeo Kappa"
			},
			{
				"_id": "122147401",
				"_name": "Trof. Guardiano"
			},
			{
				"_id": "2655945715",
				"_name": "Trofeo Cuore"
			},
			{
				"_id": "3913921381",
				"_name": "Trofeo Maestro"
			},
			{
				"_id": "2046209780",
				"_name": "Trofeo Serpente"
			},
			{
				"_id": "250715746",
				"_name": "Trofeo Bottiglia"
			},
			{
				"_id": "4038408713",
				"_name": "Trofeo Leone"
			},
			{
				"_id": "2276592287",
				"_name": "Trofeo Mantello"
			},
			{
				"_id": "515595045",
				"_name": "Trofeo Cappello"
			},
			{
				"_id": "1773956019",
				"_name": "Trofeo Trampoli"
			},
			{
				"_id": "4158193168",
				"_name": "Trofeo Eleganza"
			},
			{
				"_id": "2162151046",
				"_name": "Trofeo Corna"
			},
			{
				"_id": "433495868",
				"_name": "Trofeo Cupido"
			},
			{
				"_id": "1859235754",
				"_name": "Trofeo Comicità"
			},
			{
				"_id": "4268667451",
				"_name": "Trofeo Scarabeo"
			},
			{
				"_id": "2305393325",
				"_name": "Trofeo Oscurità"
			},
			{
				"_id": "3920497480",
				"_name": "Trof. Stuzzicad."
			},
			{
				"_id": "2661891038",
				"_name": "Trofeo Anguilla"
			},
			{
				"_id": "127953508",
				"_name": "Trofeo Squalo"
			},
			{
				"_id": "1890015986",
				"_name": "Trofeo Demone"
			},
			{
				"_id": "4005810001",
				"_name": "Trofeo Alga"
			},
			{
				"_id": "2579824583",
				"_name": "Trofeo Drago"
			},
			{
				"_id": "13479549",
				"_name": "Trof. Conchiglia"
			},
			{
				"_id": "2009767659",
				"_name": "Trofeo Triciclope"
			},
			{
				"_id": "3883238266",
				"_name": "Trofeo Ciclope"
			},
			{
				"_id": "1319758496",
				"_name": "Camp. zaffiro"
			},
			{
				"_id": "3617635098",
				"_name": "Camp. smeraldo"
			},
			{
				"_id": "2695334796",
				"_name": "Camp. rubino"
			},
			{
				"_id": "1052974639",
				"_name": "Camp. topazio"
			},
			{
				"_id": "1237593785",
				"_name": "Camp. diamante"
			},
			{
				"_id": "4158121970",
				"_name": "Ritratto compos."
			},
			{
				"_id": "1860089416",
				"_name": "Anatomia di rana"
			},
			{
				"_id": "433686238",
				"_name": "Guida Yo-kai"
			},
			{
				"_id": "2277315453",
				"_name": "Termometro"
			},
			{
				"_id": "4038730731",
				"_name": "Foto del preside"
			},
			{
				"_id": "1773367889",
				"_name": "Pelle di Noko"
			},
			{
				"_id": "515130055",
				"_name": "Sterco di Noko"
			},
			{
				"_id": "2383109974",
				"_name": "Terra di Noko"
			},
			{
				"_id": "4178341824",
				"_name": "Distintivo"
			},
			{
				"_id": "2580276773",
				"_name": "Piastra rotta"
			},
			{
				"_id": "4006401715",
				"_name": "Cetriolo mastic."
			},
			{
				"_id": "2009433865",
				"_name": "Amu. impolver."
			},
			{
				"_id": "12760991",
				"_name": "Distintivo +"
			},
			{
				"_id": "2661687868",
				"_name": "Distintivo Extra"
			},
			{
				"_id": "3919647402",
				"_name": "Secchio bucato"
			},
			{
				"_id": "1890075408",
				"_name": "Bottiglia plastica"
			},
			{
				"_id": "128938886",
				"_name": "Rivista buttata"
			},
			{
				"_id": "2534436375",
				"_name": "Super distintivo"
			},
			{
				"_id": "3759627905",
				"_name": "Note minidetect."
			},
			{
				"_id": "3001464294",
				"_name": "Distintivo Ultra"
			},
			{
				"_id": "3319891312",
				"_name": "Avviso"
			},
			{
				"_id": "1558762698",
				"_name": "Poster della star"
			},
			{
				"_id": "737141852",
				"_name": "Lattina vuota"
			},
			{
				"_id": "3045814783",
				"_name": "Bottiglia vuota"
			},
			{
				"_id": "3263971689",
				"_name": "Stivali malridotti"
			},
			{
				"_id": "1535447251",
				"_name": "Fuochi artif. usati"
			},
			{
				"_id": "746725445",
				"_name": "Busta di plastica"
			}
		]
	}
}