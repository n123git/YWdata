xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Cicala verde"
			},
			{
				"_id": "3460879014",
				"_name": "Cicala verde★"
			},
			{
				"_id": "1228371524",
				"_name": "Cicala marrone"
			},
			{
				"_id": "1463911196",
				"_name": "Cicala marrone★"
			},
			{
				"_id": "1043351250",
				"_name": "Cicala serale"
			},
			{
				"_id": "541504394",
				"_name": "Cicala serale★"
			},
			{
				"_id": "2689913713",
				"_name": "Scarabeo rino."
			},
			{
				"_id": "2969153051",
				"_name": "Scarabeo rino.★"
			},
			{
				"_id": "3612599271",
				"_name": "Cervo volante"
			},
			{
				"_id": "3355352717",
				"_name": "Cervo volante★"
			},
			{
				"_id": "1314566749",
				"_name": "Scarabeo lucan."
			},
			{
				"_id": "2500818410",
				"_name": "Scarabeo luc.★"
			},
			{
				"_id": "962429643",
				"_name": "Cavalletta"
			},
			{
				"_id": "3792192892",
				"_name": "Cavalletta★"
			},
			{
				"_id": "2850201434",
				"_name": "Mantide relig."
			},
			{
				"_id": "2063668422",
				"_name": "Mantide relig.★"
			},
			{
				"_id": "3739594700",
				"_name": "Locusta"
			},
			{
				"_id": "201729104",
				"_name": "Locusta★"
			},
			{
				"_id": "3189909033",
				"_name": "Lucciola"
			},
			{
				"_id": "2455941619",
				"_name": "Lucciola★"
			},
			{
				"_id": "3374651071",
				"_name": "Coda di rondine"
			},
			{
				"_id": "3848634725",
				"_name": "Coda rondine★"
			},
			{
				"_id": "1345079045",
				"_name": "Longicorno"
			},
			{
				"_id": "2087506143",
				"_name": "Longicorno★"
			},
			{
				"_id": "657160083",
				"_name": "Scarabeo fiore"
			},
			{
				"_id": "191619145",
				"_name": "Scarabeo fiore★"
			},
			{
				"_id": "3109020208",
				"_name": "Coccinella"
			},
			{
				"_id": "2614427096",
				"_name": "Coccinella★"
			},
			{
				"_id": "3522973129",
				"_name": "Tartaruga"
			},
			{
				"_id": "562354621",
				"_name": "Tartaruga★"
			},
			{
				"_id": "1224023155",
				"_name": "Boccalone"
			},
			{
				"_id": "2973484076",
				"_name": "Boccalone★"
			},
			{
				"_id": "1072835813",
				"_name": "Hucho h. gigante"
			},
			{
				"_id": "3325883578",
				"_name": "Hucho h. gig.★"
			},
			{
				"_id": "2711009606",
				"_name": "Carpa"
			},
			{
				"_id": "2496471005",
				"_name": "Carpa★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "3821678411",
				"_name": "Ayu★"
			},
			{
				"_id": "1335416938",
				"_name": "Testa di serpen."
			},
			{
				"_id": "2059632369",
				"_name": "Testa di serp.★"
			},
			{
				"_id": "950003964",
				"_name": "Sgombro"
			},
			{
				"_id": "230968935",
				"_name": "Sgombro★"
			},
			{
				"_id": "2820732269",
				"_name": "Snapper rosso"
			},
			{
				"_id": "2476792772",
				"_name": "Snapper rosso★"
			},
			{
				"_id": "3743925755",
				"_name": "Pesce scatola"
			},
			{
				"_id": "3836210002",
				"_name": "Pesce scatola★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "2108603112",
				"_name": "Marlin★"
			},
			{
				"_id": "3370613896",
				"_name": "Medusa"
			},
			{
				"_id": "178883198",
				"_name": "Medusa★"
			},
			{
				"_id": "1374563634",
				"_name": "Calam. lucciola"
			},
			{
				"_id": "2585171951",
				"_name": "Calam. lucciola★"
			},
			{
				"_id": "652811684",
				"_name": "Rana pescatrice"
			},
			{
				"_id": "3977357177",
				"_name": "Rana pescatr.★"
			},
			{
				"_id": "3096283143",
				"_name": "Pesce gatto"
			},
			{
				"_id": "2379624092",
				"_name": "Pesce gatto★"
			},
			{
				"_id": "3481974929",
				"_name": "Scorf. di fondale"
			},
			{
				"_id": "4208008714",
				"_name": "Scorf. di fonda.★"
			},
			{
				"_id": "1451485483",
				"_name": "Ishidai"
			},
			{
				"_id": "1675120560",
				"_name": "Ishidai★"
			}
		]
	}
}