xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Bracelet usé"
			},
			{
				"_id": "3692624796",
				"_name": "Bracelet rocker"
			},
			{
				"_id": "2870987530",
				"_name": "Bracelet brute"
			},
			{
				"_id": "897277609",
				"_name": "Bracelet solaire"
			},
			{
				"_id": "1115450943",
				"_name": "Bracelet obscur"
			},
			{
				"_id": "1154727953",
				"_name": "Anneau rouillé"
			},
			{
				"_id": "3722088875",
				"_name": "Bague mimi"
			},
			{
				"_id": "2866651453",
				"_name": "Anneau illusion"
			},
			{
				"_id": "884552862",
				"_name": "Anneau lunaire"
			},
			{
				"_id": "1136526344",
				"_name": "Anneau obscur"
			},
			{
				"_id": "3669448114",
				"_name": "Anneau du feu"
			},
			{
				"_id": "2914018596",
				"_name": "Anneau de l'eau"
			},
			{
				"_id": "1024424117",
				"_name": "Anneau foudre"
			},
			{
				"_id": "1242056739",
				"_name": "Anneau terre"
			},
			{
				"_id": "718258630",
				"_name": "Anneau glace"
			},
			{
				"_id": "1573450064",
				"_name": "Anneau du vent"
			},
			{
				"_id": "1184202312",
				"_name": "Amul. vieillotte"
			},
			{
				"_id": "3751555058",
				"_name": "Amulette runique"
			},
			{
				"_id": "2828738404",
				"_name": "Amulette armure"
			},
			{
				"_id": "922716871",
				"_name": "Amulette céleste"
			},
			{
				"_id": "1106819665",
				"_name": "Amul. obscure"
			},
			{
				"_id": "3639733227",
				"_name": "Amulette antifeu"
			},
			{
				"_id": "2952190845",
				"_name": "Amul. imperm."
			},
			{
				"_id": "1061799660",
				"_name": "Amul. parafoudre"
			},
			{
				"_id": "1213134458",
				"_name": "Amul. antiterre"
			},
			{
				"_id": "680099743",
				"_name": "Amulette antigel"
			},
			{
				"_id": "1603161865",
				"_name": "Amul. coupevent"
			},
			{
				"_id": "1196889215",
				"_name": "Badge simple"
			},
			{
				"_id": "3730720197",
				"_name": "Badge brillant"
			},
			{
				"_id": "2841212243",
				"_name": "Badge d'Hermès"
			},
			{
				"_id": "926802160",
				"_name": "Badge étoiles"
			},
			{
				"_id": "1077596262",
				"_name": "Badge obscur"
			},
			{
				"_id": "1108869882",
				"_name": "Cigatana"
			},
			{
				"_id": "3675345728",
				"_name": "Clochette force"
			},
			{
				"_id": "2887148502",
				"_name": "Cloch. charme"
			},
			{
				"_id": "846394997",
				"_name": "Cloch. vigueur"
			},
			{
				"_id": "1165346531",
				"_name": "Cloch. vitesse"
			},
			{
				"_id": "3699152729",
				"_name": "Gour. sans fond"
			},
			{
				"_id": "2877007823",
				"_name": "Éventail tengu"
			},
			{
				"_id": "1002748510",
				"_name": "Manteau d'allégr."
			},
			{
				"_id": "1287883464",
				"_name": "Batte cloutée"
			},
			{
				"_id": "738460461",
				"_name": "Laméliore"
			},
			{
				"_id": "1526936507",
				"_name": "Grigrififi"
			},
			{
				"_id": "3255460353",
				"_name": "Réflector"
			},
			{
				"_id": "1138387149",
				"_name": "Boucles en or"
			},
			{
				"_id": "3671275895",
				"_name": "Noctude"
			},
			{
				"_id": "2916354529",
				"_name": "Destidé"
			},
			{
				"_id": "867212354",
				"_name": "Plastron de fer"
			},
			{
				"_id": "1152888020",
				"_name": "Lunettes épais."
			},
			{
				"_id": "3720281454",
				"_name": "Écaille ancienne"
			},
			{
				"_id": "2864303608",
				"_name": "Octorgantelet"
			},
			{
				"_id": "973525097",
				"_name": "Écharpe céleste"
			},
			{
				"_id": "1291968767",
				"_name": "Cagoule"
			},
			{
				"_id": "767977754",
				"_name": "Insigne de haine"
			},
			{
				"_id": "1522620812",
				"_name": "Dents vampire"
			},
			{
				"_id": "3284666422",
				"_name": "Boule de cristal"
			},
			{
				"_id": "3033479328",
				"_name": "Reporeiller"
			},
			{
				"_id": "1100797588",
				"_name": "Ceinture retenue"
			},
			{
				"_id": "3633678126",
				"_name": "Gemme protec."
			},
			{
				"_id": "2945628088",
				"_name": "Coiffe de singe"
			}
		]
	}
}