xmlval = {
	"items": {
		"item": [
			{
				"_id": "1803927674",
				"_name": "Riz à la prune"
			},
			{
				"_id": "4069298624",
				"_name": "Riz dans feuille"
			},
			{
				"_id": "2240520534",
				"_name": "Riz œufs saumon"
			},
			{
				"_id": "468661493",
				"_name": "Riz à la crevette"
			},
			{
				"_id": "1783081549",
				"_name": "Sandwich"
			},
			{
				"_id": "4082039799",
				"_name": "Patte d'ours"
			},
			{
				"_id": "1831497300",
				"_name": "Pain au curry"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Blablagel"
			},
			{
				"_id": "1744901140",
				"_name": "Chewing-gum"
			},
			{
				"_id": "4043851182",
				"_name": "Bonb. poisseux"
			},
			{
				"_id": "2249159992",
				"_name": "Chips géante"
			},
			{
				"_id": "409723035",
				"_name": "Bonbons fruits"
			},
			{
				"_id": "1869402125",
				"_name": "Granité"
			},
			{
				"_id": "4133847479",
				"_name": "Pomme d'amour"
			},
			{
				"_id": "1774419491",
				"_name": "Lait"
			},
			{
				"_id": "4039782297",
				"_name": "Café au lait"
			},
			{
				"_id": "2278366991",
				"_name": "Lait aux fruits"
			},
			{
				"_id": "430541484",
				"_name": "Lait merveilleux"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Thé de l'âme"
			},
			{
				"_id": "2189560202",
				"_name": "Spiritizer Y"
			},
			{
				"_id": "484875305",
				"_name": "VoltXtrême"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Double burger"
			},
			{
				"_id": "488961566",
				"_name": "Burger Miam"
			},
			{
				"_id": "1858787071",
				"_name": "Ramen minute"
			},
			{
				"_id": "4156786501",
				"_name": "Ramen au poulet"
			},
			{
				"_id": "2160375763",
				"_name": "Ramen deluxe"
			},
			{
				"_id": "513811056",
				"_name": "Ramen complets"
			},
			{
				"_id": "1683291125",
				"_name": "Raviolis chinois"
			},
			{
				"_id": "4250774095",
				"_name": "Foie à l'oignon"
			},
			{
				"_id": "2321193689",
				"_name": "Omelette crabe"
			},
			{
				"_id": "339611514",
				"_name": "Crevette piment"
			},
			{
				"_id": "3539717416",
				"_name": "Carotte"
			},
			{
				"_id": "1274190994",
				"_name": "Concombre"
			},
			{
				"_id": "1022733316",
				"_name": "Pousse bambou"
			},
			{
				"_id": "2727426471",
				"_name": "Matsutake"
			},
			{
				"_id": "3502076785",
				"_name": "Cuisse de poulet"
			},
			{
				"_id": "1236542155",
				"_name": "Morceau de lard"
			},
			{
				"_id": "1051923037",
				"_name": "Langue de bœuf"
			},
			{
				"_id": "2698479614",
				"_name": "Bœuf persillé"
			},
			{
				"_id": "3514767686",
				"_name": "Maquereau séch."
			},
			{
				"_id": "1215711484",
				"_name": "Sériole"
			},
			{
				"_id": "1064401002",
				"_name": "Oursin cru"
			},
			{
				"_id": "2702568905",
				"_name": "Thon 1er choix"
			},
			{
				"_id": "320924352",
				"_name": "Petit EXPorbe"
			},
			{
				"_id": "2317990778",
				"_name": "EXPorbe moyen"
			},
			{
				"_id": "4247686124",
				"_name": "Grand EXPorbe"
			},
			{
				"_id": "1665801807",
				"_name": "Méga EXPorbe"
			},
			{
				"_id": "340602585",
				"_name": "EXPorbe sacré"
			},
			{
				"_id": "397252210",
				"_name": "Staminum"
			},
			{
				"_id": "2393163720",
				"_name": "Staminum Alpha"
			},
			{
				"_id": "279199406",
				"_name": "Coups secrets"
			},
			{
				"_id": "2309844756",
				"_name": "Tech. tip-top"
			},
			{
				"_id": "4272578434",
				"_name": "Secrets de l'âme"
			},
			{
				"_id": "469268883",
				"_name": "La vie en tête"
			},
			{
				"_id": "2196842537",
				"_name": "Pensez Karaté"
			},
			{
				"_id": "4126546111",
				"_name": "Vivez Karaté"
			},
			{
				"_id": "1804766492",
				"_name": "Dico-tech"
			},
			{
				"_id": "479575434",
				"_name": "Techni-clopédie"
			},
			{
				"_id": "2241653808",
				"_name": "La déf. de A à Z"
			},
			{
				"_id": "4070300838",
				"_name": "Tout sur la déf."
			},
			{
				"_id": "1646575927",
				"_name": "Docteur Tit'ange"
			},
			{
				"_id": "354677153",
				"_name": "Au rev., Tit'ange"
			},
			{
				"_id": "1977907268",
				"_name": "Petite teigne"
			},
			{
				"_id": "48449746",
				"_name": "Teigne parfaite"
			},
			{
				"_id": "2615810408",
				"_name": "Secours mag #7"
			},
			{
				"_id": "3974965758",
				"_name": "Sec. hors-série"
			},
			{
				"_id": "367732779",
				"_name": "Talisman force"
			},
			{
				"_id": "2363652497",
				"_name": "Talisman d'esprit"
			},
			{
				"_id": "4226107655",
				"_name": "Talisman de déf."
			},
			{
				"_id": "1703009444",
				"_name": "Talisman vitesse"
			},
			{
				"_id": "338248220",
				"_name": "Remède infect"
			},
			{
				"_id": "2367689638",
				"_name": "Remède amer"
			},
			{
				"_id": "4196868912",
				"_name": "Remède puiss."
			},
			{
				"_id": "376437829",
				"_name": "Poupée de fuite"
			},
			{
				"_id": "291919001",
				"_name": "Poupée bronze"
			},
			{
				"_id": "2288977187",
				"_name": "Poupée d'argent"
			},
			{
				"_id": "4285019573",
				"_name": "Poupée d'or"
			},
			{
				"_id": "2908180302",
				"_name": "Appât poissons"
			},
			{
				"_id": "878583540",
				"_name": "Mélasse"
			},
			{
				"_id": "2592718716",
				"_name": "Pièce rouge"
			},
			{
				"_id": "58781382",
				"_name": "Pièce jaune"
			},
			{
				"_id": "1955061328",
				"_name": "Pièce orange"
			},
			{
				"_id": "3940764659",
				"_name": "Pièce rose"
			},
			{
				"_id": "2648996709",
				"_name": "Pièce verte"
			},
			{
				"_id": "82651871",
				"_name": "Pièce bleue"
			},
			{
				"_id": "1944721993",
				"_name": "Pièce mauve"
			},
			{
				"_id": "3814000600",
				"_name": "Pièce bleu ciel"
			},
			{
				"_id": "3141306787",
				"_name": "Pièce saphir"
			},
			{
				"_id": "3426466101",
				"_name": "Pièce émeraude"
			},
			{
				"_id": "1381969046",
				"_name": "Pièce rubis"
			},
			{
				"_id": "626531328",
				"_name": "Pièce topaze"
			},
			{
				"_id": "573954073",
				"_name": "Pièce diamant"
			},
			{
				"_id": "3159444922",
				"_name": "Pièce d'euphorie"
			},
			{
				"_id": "3411442988",
				"_name": "Pièce 5 étoiles"
			},
			{
				"_id": "1542021309",
				"_name": "Pièce spéciale"
			},
			{
				"_id": "2895455609",
				"_name": "Étoile dansante"
			},
			{
				"_id": "440013732",
				"_name": "Épée légendaire"
			},
			{
				"_id": "2201174558",
				"_name": "Épée maudite"
			},
			{
				"_id": "2220787207",
				"_name": "Épée sacrée"
			},
			{
				"_id": "4097077896",
				"_name": "Âme du général"
			},
			{
				"_id": "1783686955",
				"_name": "Six-coups foudre"
			},
			{
				"_id": "492296125",
				"_name": "Orbe GHz"
			},
			{
				"_id": "1676061440",
				"_name": "Âme imbattable"
			},
			{
				"_id": "2586342239",
				"_name": "Lingot de platine"
			},
			{
				"_id": "350329750",
				"_name": "Cape de blizzard"
			},
			{
				"_id": "1948652147",
				"_name": "Sceptre d'amour"
			},
			{
				"_id": "4082742929",
				"_name": "Pince de glace"
			},
			{
				"_id": "52503269",
				"_name": "Poids"
			},
			{
				"_id": "1934349930",
				"_name": "Éclat démon."
			},
			{
				"_id": "3979297737",
				"_name": "Poudre jouvence"
			},
			{
				"_id": "3742966091",
				"_name": "Goutte de joie"
			},
			{
				"_id": "2638591814",
				"_name": "Orbe de dragon"
			},
			{
				"_id": "3930228688",
				"_name": "Eau sacrée"
			},
			{
				"_id": "2063440449",
				"_name": "Écaille cracra"
			},
			{
				"_id": "234531543",
				"_name": "Aura Octorgone"
			},
			{
				"_id": "1594573232",
				"_name": "Gantelet abîmé"
			},
			{
				"_id": "671904038",
				"_name": "Cristal fissuré"
			},
			{
				"_id": "2969903260",
				"_name": "Éclat de cristal"
			},
			{
				"_id": "3322023946",
				"_name": "Toupropre"
			},
			{
				"_id": "1483113897",
				"_name": "Écharpe jaunie"
			},
			{
				"_id": "794932543",
				"_name": "Bague normale"
			},
			{
				"_id": "3060327557",
				"_name": "Amulette vide"
			},
			{
				"_id": "3245331475",
				"_name": "Rubis"
			},
			{
				"_id": "1372637570",
				"_name": "Aigue-marine"
			},
			{
				"_id": "651688212",
				"_name": "Topaze"
			},
			{
				"_id": "1175482609",
				"_name": "Tourmaline"
			},
			{
				"_id": "823607399",
				"_name": "Opale"
			},
			{
				"_id": "2820542941",
				"_name": "Émeraude"
			}
		]
	}
}