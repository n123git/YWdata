xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Cigale verte"
			},
			{
				"_id": "3460879014",
				"_name": "Cigale verte★"
			},
			{
				"_id": "1228371524",
				"_name": "Cigale marron"
			},
			{
				"_id": "1463911196",
				"_name": "Cigale marron★"
			},
			{
				"_id": "1043351250",
				"_name": "Cigale du soir"
			},
			{
				"_id": "541504394",
				"_name": "Cigale du soir★"
			},
			{
				"_id": "2689913713",
				"_name": "Scarabée rhino."
			},
			{
				"_id": "2969153051",
				"_name": "Scarab. rhino.★"
			},
			{
				"_id": "3612599271",
				"_name": "Petite biche"
			},
			{
				"_id": "3355352717",
				"_name": "Petite biche★"
			},
			{
				"_id": "1314566749",
				"_name": "Lucane"
			},
			{
				"_id": "2500818410",
				"_name": "Lucane★"
			},
			{
				"_id": "962429643",
				"_name": "Criquet"
			},
			{
				"_id": "3792192892",
				"_name": "Criquet★"
			},
			{
				"_id": "2850201434",
				"_name": "Mante religieuse"
			},
			{
				"_id": "2063668422",
				"_name": "Mante relig.★"
			},
			{
				"_id": "3739594700",
				"_name": "Sauterelle"
			},
			{
				"_id": "201729104",
				"_name": "Sauterelle★"
			},
			{
				"_id": "3189909033",
				"_name": "Luciole"
			},
			{
				"_id": "2455941619",
				"_name": "Luciole★"
			},
			{
				"_id": "3374651071",
				"_name": "Machaon"
			},
			{
				"_id": "3848634725",
				"_name": "Machaon★"
			},
			{
				"_id": "1345079045",
				"_name": "Longicorne"
			},
			{
				"_id": "2087506143",
				"_name": "Longicorne★"
			},
			{
				"_id": "657160083",
				"_name": "Cétoine"
			},
			{
				"_id": "191619145",
				"_name": "Cétoine★"
			},
			{
				"_id": "3109020208",
				"_name": "Coccinelle"
			},
			{
				"_id": "2614427096",
				"_name": "Coccinelle★"
			},
			{
				"_id": "3522973129",
				"_name": "Tortue"
			},
			{
				"_id": "562354621",
				"_name": "Tortue★"
			},
			{
				"_id": "1224023155",
				"_name": "Perche noire"
			},
			{
				"_id": "2973484076",
				"_name": "Perche noire★"
			},
			{
				"_id": "1072835813",
				"_name": "Huchon géant"
			},
			{
				"_id": "3325883578",
				"_name": "Huchon géant★"
			},
			{
				"_id": "2711009606",
				"_name": "Carpe"
			},
			{
				"_id": "2496471005",
				"_name": "Carpe★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "3821678411",
				"_name": "Ayu★"
			},
			{
				"_id": "1335416938",
				"_name": "Têtes-de-serp."
			},
			{
				"_id": "2059632369",
				"_name": "Têtes-de-serp.★"
			},
			{
				"_id": "950003964",
				"_name": "Maquereau"
			},
			{
				"_id": "230968935",
				"_name": "Maquereau★"
			},
			{
				"_id": "2820732269",
				"_name": "Vivaneau rouge"
			},
			{
				"_id": "2476792772",
				"_name": "Vivan. rouge★"
			},
			{
				"_id": "3743925755",
				"_name": "Poisson-vache"
			},
			{
				"_id": "3836210002",
				"_name": "Poisson-vache★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "2108603112",
				"_name": "Marlin★"
			},
			{
				"_id": "3370613896",
				"_name": "Méduse"
			},
			{
				"_id": "178883198",
				"_name": "Méduse★"
			},
			{
				"_id": "1374563634",
				"_name": "Calamar-luciole"
			},
			{
				"_id": "2585171951",
				"_name": "Calamar-luc.★"
			},
			{
				"_id": "652811684",
				"_name": "Poiss.-pêcheur"
			},
			{
				"_id": "3977357177",
				"_name": "Poiss.-pêcheur★"
			},
			{
				"_id": "3096283143",
				"_name": "Poisson-chat"
			},
			{
				"_id": "2379624092",
				"_name": "Poisson-chat★"
			},
			{
				"_id": "3481974929",
				"_name": "Rascasse"
			},
			{
				"_id": "4208008714",
				"_name": "Rascasse★"
			},
			{
				"_id": "1451485483",
				"_name": "Daurade rayée"
			},
			{
				"_id": "1675120560",
				"_name": "Daurade rayée★"
			}
		]
	}
}