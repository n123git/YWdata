xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "2707808699",
				"_name": "Médall. Yo-kai"
			},
			{
				"_id": "1057059864",
				"_name": "Poudre floraison"
			},
			{
				"_id": "1208370318",
				"_name": "Filet à insectes"
			},
			{
				"_id": "3507426612",
				"_name": "Canne à pêche"
			},
			{
				"_id": "2785551778",
				"_name": "Ticket de musée"
			},
			{
				"_id": "917977139",
				"_name": "Clé de ch. forte"
			},
			{
				"_id": "1102055589",
				"_name": "Photo d'Amélie"
			},
			{
				"_id": "561480000",
				"_name": "Sous-vêt. usés"
			},
			{
				"_id": "1450226134",
				"_name": "Vélo"
			},
			{
				"_id": "3480871020",
				"_name": "Vélo"
			},
			{
				"_id": "3095318778",
				"_name": "Roue de montre"
			},
			{
				"_id": "639255897",
				"_name": "Vis de montre"
			},
			{
				"_id": "1360885199",
				"_name": "Clé vieux manoir"
			},
			{
				"_id": "3356763253",
				"_name": "Bague spéciale"
			},
			{
				"_id": "3205698787",
				"_name": "Dossier de papa"
			},
			{
				"_id": "799803762",
				"_name": "Jolie côte"
			},
			{
				"_id": "1487616484",
				"_name": "Clés de l'école"
			},
			{
				"_id": "173724291",
				"_name": "Partition"
			},
			{
				"_id": "2103304725",
				"_name": "Ressort montre"
			},
			{
				"_id": "3830756271",
				"_name": "Clé de cabane"
			},
			{
				"_id": "2471723833",
				"_name": "Moteur Émettor"
			},
			{
				"_id": "221714074",
				"_name": "Huile de Tendino"
			},
			{
				"_id": "2049975820",
				"_name": "Volant d'Égaroni"
			},
			{
				"_id": "3812194230",
				"_name": "Clé Yo-kai World"
			},
			{
				"_id": "75586225",
				"_name": "Champignon sav."
			},
			{
				"_id": "1938188839",
				"_name": "Manga"
			},
			{
				"_id": "323085250",
				"_name": "Gour. Kappacap"
			},
			{
				"_id": "1682363220",
				"_name": "Assiette fêlée"
			},
			{
				"_id": "4249846510",
				"_name": "Amul. miteuse"
			},
			{
				"_id": "2320020088",
				"_name": "Tofu d'or"
			},
			{
				"_id": "338438107",
				"_name": "Missile plastique"
			},
			{
				"_id": "1663768397",
				"_name": "Ballon de foot"
			},
			{
				"_id": "4196550391",
				"_name": "Poèmes romant."
			},
			{
				"_id": "2368042593",
				"_name": "Herbes lucidité"
			},
			{
				"_id": "496659440",
				"_name": "Lame trahison"
			},
			{
				"_id": "1788697446",
				"_name": "Photo de star"
			},
			{
				"_id": "1543533829",
				"_name": "Photo star ternie"
			},
			{
				"_id": "721896851",
				"_name": "Maquette rare"
			},
			{
				"_id": "2987267113",
				"_name": "Boucles préc."
			},
			{
				"_id": "3305710783",
				"_name": "Capsule temp."
			},
			{
				"_id": "1533915420",
				"_name": "Lame d'illusion"
			},
			{
				"_id": "745177482",
				"_name": "Éventail typhon"
			},
			{
				"_id": "3043217456",
				"_name": "Fleur éternelle"
			},
			{
				"_id": "3261391014",
				"_name": "Trophée Reptile"
			},
			{
				"_id": "1390148919",
				"_name": "Trophée Fringale"
			},
			{
				"_id": "635227553",
				"_name": "Trophée Miaou"
			},
			{
				"_id": "1159414852",
				"_name": "Troph. Gd-mère"
			},
			{
				"_id": "840725714",
				"_name": "Trophée Cheval"
			},
			{
				"_id": "2870289768",
				"_name": "Trophée Crinière"
			},
			{
				"_id": "3692172798",
				"_name": "Troph. Capuche"
			},
			{
				"_id": "1115062365",
				"_name": "Trophée Rides"
			},
			{
				"_id": "896643275",
				"_name": "Trophée Katana"
			},
			{
				"_id": "2893603185",
				"_name": "Trophée Tonton"
			},
			{
				"_id": "3682587111",
				"_name": "Trophée Tengu"
			},
			{
				"_id": "1270926454",
				"_name": "Trophée Cigale"
			},
			{
				"_id": "1019739360",
				"_name": "Trophée Mochi"
			},
			{
				"_id": "1849038727",
				"_name": "Trophée Volatile"
			},
			{
				"_id": "422651665",
				"_name": "Troph. Ambition"
			},
			{
				"_id": "2151184043",
				"_name": "Trophée Joueur"
			},
			{
				"_id": "4148119101",
				"_name": "Trophée Consol."
			},
			{
				"_id": "1767625630",
				"_name": "Trophée Sauvag."
			},
			{
				"_id": "509403912",
				"_name": "Trophée Coiffure"
			},
			{
				"_id": "2270540466",
				"_name": "Trophée Ailes"
			},
			{
				"_id": "4031939108",
				"_name": "Trophée Shogun"
			},
			{
				"_id": "1626185653",
				"_name": "Trophée Enfant"
			},
			{
				"_id": "401256227",
				"_name": "Troph. Confusion"
			},
			{
				"_id": "1999447750",
				"_name": "Trophée Sac"
			},
			{
				"_id": "2758224",
				"_name": "Trophée Kimono"
			},
			{
				"_id": "2569226218",
				"_name": "Troph. Binocles"
			},
			{
				"_id": "3995367292",
				"_name": "Trophée Bzzz"
			},
			{
				"_id": "1883300575",
				"_name": "Trophée Kappa"
			},
			{
				"_id": "122147401",
				"_name": "Trophée Gardien"
			},
			{
				"_id": "2655945715",
				"_name": "Trophée Cœur"
			},
			{
				"_id": "3913921381",
				"_name": "Trophée Maître"
			},
			{
				"_id": "2046209780",
				"_name": "Trophée Serpent"
			},
			{
				"_id": "250715746",
				"_name": "Trophée Gourde"
			},
			{
				"_id": "4038408713",
				"_name": "Trophée Lion"
			},
			{
				"_id": "2276592287",
				"_name": "Trophée Cape"
			},
			{
				"_id": "515595045",
				"_name": "Troph. Chapeau"
			},
			{
				"_id": "1773956019",
				"_name": "Troph. Échassier"
			},
			{
				"_id": "4158193168",
				"_name": "Trophée Style"
			},
			{
				"_id": "2162151046",
				"_name": "Trophée Cervidé"
			},
			{
				"_id": "433495868",
				"_name": "Troph. Cupidon"
			},
			{
				"_id": "1859235754",
				"_name": "Troph. Comédie"
			},
			{
				"_id": "4268667451",
				"_name": "Troph. Scarabée"
			},
			{
				"_id": "2305393325",
				"_name": "Troph. Ténèbres"
			},
			{
				"_id": "3920497480",
				"_name": "Troph. Cure-dent"
			},
			{
				"_id": "2661891038",
				"_name": "Trophée Murène"
			},
			{
				"_id": "127953508",
				"_name": "Trophée Requin"
			},
			{
				"_id": "1890015986",
				"_name": "Trophée Démon"
			},
			{
				"_id": "4005810001",
				"_name": "Trophée Algue"
			},
			{
				"_id": "2579824583",
				"_name": "Trophée Dragon"
			},
			{
				"_id": "13479549",
				"_name": "Troph. Coquill."
			},
			{
				"_id": "2009767659",
				"_name": "Trophée Triclope"
			},
			{
				"_id": "3883238266",
				"_name": "Trophée Cyclope"
			},
			{
				"_id": "1319758496",
				"_name": "Grelot saphir"
			},
			{
				"_id": "3617635098",
				"_name": "Grelot émeraude"
			},
			{
				"_id": "2695334796",
				"_name": "Grelot rubis"
			},
			{
				"_id": "1052974639",
				"_name": "Grelot topaze"
			},
			{
				"_id": "1237593785",
				"_name": "Grelot diamant"
			},
			{
				"_id": "4158121970",
				"_name": "Portrait musicien"
			},
			{
				"_id": "1860089416",
				"_name": "Corps grenouille"
			},
			{
				"_id": "433686238",
				"_name": "Guide des Yo-kai"
			},
			{
				"_id": "2277315453",
				"_name": "Thermomètre"
			},
			{
				"_id": "4038730731",
				"_name": "Photo proviseur"
			},
			{
				"_id": "1773367889",
				"_name": "Peau de Noko"
			},
			{
				"_id": "515130055",
				"_name": "Crotte de Noko"
			},
			{
				"_id": "2383109974",
				"_name": "Trace de Noko"
			},
			{
				"_id": "4178341824",
				"_name": "Badge Détective"
			},
			{
				"_id": "2580276773",
				"_name": "Assiette fêlée"
			},
			{
				"_id": "4006401715",
				"_name": "Concom. entamé"
			},
			{
				"_id": "2009433865",
				"_name": "Amulette sale"
			},
			{
				"_id": "12760991",
				"_name": "Badge Détec+"
			},
			{
				"_id": "2661687868",
				"_name": "Badge Détec. EX"
			},
			{
				"_id": "3919647402",
				"_name": "Seau troué"
			},
			{
				"_id": "1890075408",
				"_name": "Bouteille plast."
			},
			{
				"_id": "128938886",
				"_name": "Magazine abîmé"
			},
			{
				"_id": "2534436375",
				"_name": "B. Super Détec."
			},
			{
				"_id": "3759627905",
				"_name": "Note Pts détec."
			},
			{
				"_id": "3001464294",
				"_name": "B. Ultra Détec."
			},
			{
				"_id": "3319891312",
				"_name": "Annonce"
			},
			{
				"_id": "1558762698",
				"_name": "Poster de star"
			},
			{
				"_id": "737141852",
				"_name": "Cannette vide"
			},
			{
				"_id": "3045814783",
				"_name": "Bouteille vide"
			},
			{
				"_id": "3263971689",
				"_name": "Bottes usées"
			},
			{
				"_id": "1535447251",
				"_name": "Vieux feu artifice"
			},
			{
				"_id": "746725445",
				"_name": "Sac en plastique"
			}
		]
	}
}