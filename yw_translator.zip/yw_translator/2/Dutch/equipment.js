xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Gebruikte armband"
			},
			{
				"_id": "3681894277",
				"_name": "Goedkope armband"
			},
			{
				"_id": "3692624796",
				"_name": "Punkarmband"
			},
			{
				"_id": "2893156115",
				"_name": "Krachtarmband"
			},
			{
				"_id": "2870987530",
				"_name": "Brute armband"
			},
			{
				"_id": "1020072578",
				"_name": "Grote armband"
			},
			{
				"_id": "897277609",
				"_name": "Zonarmband"
			},
			{
				"_id": "1271538196",
				"_name": "Komeetarmband"
			},
			{
				"_id": "1115450943",
				"_name": "Duivelse armband"
			},
			{
				"_id": "722316273",
				"_name": "Epische armband"
			},
			{
				"_id": "1154727953",
				"_name": "Roestige ring"
			},
			{
				"_id": "3669448114",
				"_name": "Lelijke ring"
			},
			{
				"_id": "3722088875",
				"_name": "Mooie ring"
			},
			{
				"_id": "2914018596",
				"_name": "Regenboogring"
			},
			{
				"_id": "2866651453",
				"_name": "Illusiering"
			},
			{
				"_id": "1024424117",
				"_name": "Feeënring"
			},
			{
				"_id": "884552862",
				"_name": "Maanring"
			},
			{
				"_id": "1242056739",
				"_name": "Lotsring"
			},
			{
				"_id": "1136526344",
				"_name": "Duivelse ring"
			},
			{
				"_id": "718258630",
				"_name": "Epische ring"
			},
			{
				"_id": "1184202312",
				"_name": "Antieke amulet"
			},
			{
				"_id": "3639733227",
				"_name": "Oud amulet"
			},
			{
				"_id": "3751555058",
				"_name": "Runenamulet"
			},
			{
				"_id": "2952190845",
				"_name": "Beschermamulet"
			},
			{
				"_id": "2828738404",
				"_name": "Pantseramulet"
			},
			{
				"_id": "1061799660",
				"_name": "Geluksamulet"
			},
			{
				"_id": "922716871",
				"_name": "Galactische amulet"
			},
			{
				"_id": "1213134458",
				"_name": "Aardamulet"
			},
			{
				"_id": "1106819665",
				"_name": "Duivelse amulet"
			},
			{
				"_id": "680099743",
				"_name": "Episch amulet"
			},
			{
				"_id": "1196889215",
				"_name": "Simpel insigne"
			},
			{
				"_id": "3644031452",
				"_name": "Zwart insigne"
			},
			{
				"_id": "3730720197",
				"_name": "Glanzend insigne"
			},
			{
				"_id": "2922688842",
				"_name": "Schattig insigne"
			},
			{
				"_id": "2841212243",
				"_name": "Hermesinsigne"
			},
			{
				"_id": "1049341147",
				"_name": "Aurora-insigne"
			},
			{
				"_id": "926802160",
				"_name": "Meteoreninsigne"
			},
			{
				"_id": "1233951821",
				"_name": "Blikseminsigne"
			},
			{
				"_id": "1077596262",
				"_name": "Duivels insigne"
			},
			{
				"_id": "692786600",
				"_name": "Episch insigne"
			},
			{
				"_id": "1108869882",
				"_name": "Cicadezwaard"
			},
			{
				"_id": "3675345728",
				"_name": "Versterkingsbel"
			},
			{
				"_id": "2887148502",
				"_name": "Spreukbel"
			},
			{
				"_id": "846394997",
				"_name": "Bikkelbel"
			},
			{
				"_id": "1165346531",
				"_name": "Snelheidsbel"
			},
			{
				"_id": "3699152729",
				"_name": "Bodemloze beker"
			},
			{
				"_id": "2877007823",
				"_name": "Tengu-waaier"
			},
			{
				"_id": "1002748510",
				"_name": "Montere mantel"
			},
			{
				"_id": "1287883464",
				"_name": "Morgenster"
			},
			{
				"_id": "1550776226",
				"_name": "Drumsticks"
			},
			{
				"_id": "3311904280",
				"_name": "Robovitamine E"
			},
			{
				"_id": "2992674446",
				"_name": "Burly's armband"
			},
			{
				"_id": "585075487",
				"_name": "Geheugenbel"
			},
			{
				"_id": "3037549207",
				"_name": "Spookband"
			},
			{
				"_id": "728352564",
				"_name": "Geestband"
			},
			{
				"_id": "738460461",
				"_name": "Keerzwaard"
			},
			{
				"_id": "1526936507",
				"_name": "Keerstenen"
			},
			{
				"_id": "3255460353",
				"_name": "Reflector"
			},
			{
				"_id": "1440267145",
				"_name": "Paradijsbel"
			},
			{
				"_id": "1138387149",
				"_name": "Sinistere brief"
			},
			{
				"_id": "3671275895",
				"_name": "Vervloekt zwaard"
			},
			{
				"_id": "2916354529",
				"_name": "Vervloekte staf"
			},
			{
				"_id": "867212354",
				"_name": "Vervloekt schild"
			},
			{
				"_id": "1152888020",
				"_name": "Vervloekte kleding"
			},
			{
				"_id": "1100797588",
				"_name": "Bedwingriem"
			},
			{
				"_id": "2945628088",
				"_name": "Apenkrans"
			},
			{
				"_id": "4256025923",
				"_name": "Gen.-medaille"
			},
			{
				"_id": "1688509689",
				"_name": "Lt.-Gen.-medaille"
			},
			{
				"_id": "329493615",
				"_name": "Gen.-Maj.-medaille"
			},
			{
				"_id": "2378643916",
				"_name": "Kol.-medaille"
			},
			{
				"_id": "4206889306",
				"_name": "Maj.-medaille"
			},
			{
				"_id": "1674139872",
				"_name": "Kap.-medaille"
			},
			{
				"_id": "349071478",
				"_name": "Adm.-medaille"
			},
			{
				"_id": "2222028263",
				"_name": "Lt.-medaille"
			}
		]
	}
}
