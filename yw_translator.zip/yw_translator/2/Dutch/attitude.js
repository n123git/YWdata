xmlval = {
	"items": {
		"item": [
			{
				"_id": "1",
				"_name": "Humeurig"
			},
			{
				"_id": "2",
				"_name": "Logisch"
			},
			{
				"_id": "3",
				"_name": "Aarzelend"
			},
			{
				"_id": "4",
				"_name": "Lieflijk"
			},
			{
				"_id": "5",
				"_name": "Verknipt"
			},
			{
				"_id": "6",
				"_name": "Dienstig"
			},
			{
				"_id": "7",
				"_name": "Ruig"
			},
			{
				"_id": "8",
				"_name": "Slim"
			},
			{
				"_id": "9",
				"_name": "Kalm"
			},
			{
				"_id": "10",
				"_name": "Gevoelig"
			},
			{
				"_id": "11",
				"_name": "Wreed"
			},
			{
				"_id": "12",
				"_name": "Toegewijd"
			}
		]
	}
}
