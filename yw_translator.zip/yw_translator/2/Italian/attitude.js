xmlval = {
	"items": {
		"item": [
			{
				"_id": "1",
				"_name": "Burbero"
			},
			{
				"_id": "2",
				"_name": "Razionale"
			},
			{
				"_id": "3",
				"_name": "Attento"
			},
			{
				"_id": "4",
				"_name": "Delicato"
			},
			{
				"_id": "5",
				"_name": "Contorto"
			},
			{
				"_id": "6",
				"_name": "Solidale"
			},
			{
				"_id": "7",
				"_name": "Brusco"
			},
			{
				"_id": "8",
				"_name": "Astuto"
			},
			{
				"_id": "9",
				"_name": "Calmo"
			},
			{
				"_id": "10",
				"_name": "Tenero"
			},
			{
				"_id": "11",
				"_name": "Crudele"
			},
			{
				"_id": "12",
				"_name": "Fedele"
			}
		]
	}
}