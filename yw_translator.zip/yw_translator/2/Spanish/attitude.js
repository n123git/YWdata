xmlval = {
	"items": {
		"item": [
			{
				"_id": "1",
				"_name": "Gruñón"
			},
			{
				"_id": "2",
				"_name": "Sensato"
			},
			{
				"_id": "3",
				"_name": "Cuidadoso"
			},
			{
				"_id": "4",
				"_name": "Gentil"
			},
			{
				"_id": "5",
				"_name": "Retorcido"
			},
			{
				"_id": "6",
				"_name": "Servicial"
			},
			{
				"_id": "7",
				"_name": "Duro"
			},
			{
				"_id": "8",
				"_name": "Listo"
			},
			{
				"_id": "9",
				"_name": "Sereno"
			},
			{
				"_id": "10",
				"_name": "Tierno"
			},
			{
				"_id": "11",
				"_name": "Cruel"
			},
			{
				"_id": "12",
				"_name": "Leal"
			}
		]
	}
}
