xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "496659440",
				"_name": "Model Zero"
			},
			{
				"_id": "917977139",
				"_name": "Curious Clock"
			},
			{
				"_id": "1102055589",
				"_name": "Curious Clock"
			},
			{
				"_id": "2707808699",
				"_name": "Yo-kai Medallium"
			},
			{
				"_id": "1208370318",
				"_name": "Bug Net"
			},
			{
				"_id": "3507426612",
				"_name": "Fishing Rod"
			},
			{
				"_id": "2785551778",
				"_name": "Museum Ticket"
			},
			{
				"_id": "1450226134",
				"_name": "Breeze Cycle"
			},
			{
				"_id": "3480871020",
				"_name": "Spring Cycle"
			},
			{
				"_id": "2270540466",
				"_name": "Sunset Cycle"
			},
			{
				"_id": "4031939108",
				"_name": "Seaside Cycle"
			},
			{
				"_id": "1626185653",
				"_name": "Sakura Cycle"
			},
			{
				"_id": "401256227",
				"_name": "Forest Cycle"
			},
			{
				"_id": "1999447750",
				"_name": "Cirrus Cycle"
			},
			{
				"_id": "2758224",
				"_name": "Sunshine Cycle"
			},
			{
				"_id": "2569226218",
				"_name": "Splendid Cycle"
			},
			{
				"_id": "3995367292",
				"_name": "Sinister Cycle"
			},
			{
				"_id": "1883300575",
				"_name": "Sparkling Cycle"
			},
			{
				"_id": "122147401",
				"_name": "Sunset Cycle"
			},
			{
				"_id": "2655945715",
				"_name": "Seaside Cycle"
			},
			{
				"_id": "3913921381",
				"_name": "Sakura Cycle"
			},
			{
				"_id": "2046209780",
				"_name": "Forest Cycle"
			},
			{
				"_id": "250715746",
				"_name": "Cirrus Cycle"
			},
			{
				"_id": "4038408713",
				"_name": "Sunshine Cycle"
			},
			{
				"_id": "2276592287",
				"_name": "Splendid Cycle"
			},
			{
				"_id": "515595045",
				"_name": "Sinister Cycle"
			},
			{
				"_id": "1773956019",
				"_name": "Sparkling Cycle"
			},
			{
				"_id": "2471723833",
				"_name": "Select-A-Coin"
			},
			{
				"_id": "561480000",
				"_name": "Select-A-Coin +"
			},
			{
				"_id": "2487109408",
				"_name": "Day Pass"
			},
			{
				"_id": "2049975820",
				"_name": "Free 'n' Easy Pass"
			},
			{
				"_id": "323085250",
				"_name": "Stamp Card"
			},
			{
				"_id": "3095318778",
				"_name": "Extra Homework"
			},
			{
				"_id": "639255897",
				"_name": "Ancient Herbs"
			},
			{
				"_id": "1360885199",
				"_name": "Pro Screwdriver"
			},
			{
				"_id": "3356763253",
				"_name": "Spirit Doughnuts"
			},
			{
				"_id": "3205698787",
				"_name": "Soul Doughnuts"
			},
			{
				"_id": "799803762",
				"_name": "Mom's Directions"
			},
			{
				"_id": "1487616484",
				"_name": "School Keys"
			},
			{
				"_id": "2320020088",
				"_name": "Komasan's Letter"
			},
			{
				"_id": "338438107",
				"_name": "Swirly Bell"
			},
			{
				"_id": "1663768397",
				"_name": "Heckapeño"
			},
			{
				"_id": "4196550391",
				"_name": "Top-Notch Watch"
			},
			{
				"_id": "2368042593",
				"_name": "Mysterious Marble"
			},
			{
				"_id": "1788697446",
				"_name": "Rockaway Extract"
			},
			{
				"_id": "1543533829",
				"_name": "Milk Bottle Tops"
			},
			{
				"_id": "721896851",
				"_name": "Moximous Game"
			},
			{
				"_id": "3830756271",
				"_name": "Shack Key"
			},
			{
				"_id": "221714074",
				"_name": "Mega Watch"
			},
			{
				"_id": "1057059864",
				"_name": "Hose"
			},
			{
				"_id": "173724291",
				"_name": "Back Door Key"
			},
			{
				"_id": "1682363220",
				"_name": "Large Fancy Key"
			},
			{
				"_id": "4249846510",
				"_name": "Small Fancy Key"
			},
			{
				"_id": "3812194230",
				"_name": "Yo-kai World Key"
			},
			{
				"_id": "75586225",
				"_name": "Spooky Key"
			},
			{
				"_id": "2009767659",
				"_name": "Boar Key"
			},
			{
				"_id": "3883238266",
				"_name": "Deer Key"
			},
			{
				"_id": "1938188839",
				"_name": "Butterfly Key"
			},
			{
				"_id": "2103304725",
				"_name": "Payn Oil"
			},
			{
				"_id": "3261391014",
				"_name": "Next HarMEOWny Pic 1"
			},
			{
				"_id": "1390148919",
				"_name": "Next HarMEOWny Pic 2"
			},
			{
				"_id": "635227553",
				"_name": "Next HarMEOWny Pic 3"
			},
			{
				"_id": "1159414852",
				"_name": "Next HarMEOWny Pic 4"
			},
			{
				"_id": "840725714",
				"_name": "Next HarMEOWny Pic 5"
			},
			{
				"_id": "2870289768",
				"_name": "Next HarMEOWny Pic 6"
			},
			{
				"_id": "3692172798",
				"_name": "Next HarMEOWny Pic 7"
			},
			{
				"_id": "1115062365",
				"_name": "Next HarMEOWny Pic 8"
			},
			{
				"_id": "896643275",
				"_name": "Next HarMEOWny Pic 9"
			},
			{
				"_id": "2893603185",
				"_name": "Next HarMEOWny Pic 10"
			},
			{
				"_id": "3682587111",
				"_name": "Derriera Dragon"
			},
			{
				"_id": "1270926454",
				"_name": "Key to Apt. C-302"
			},
			{
				"_id": "1019739360",
				"_name": "Key to Apt. A-201"
			},
			{
				"_id": "1849038727",
				"_name": "Key to Apt. A-203"
			},
			{
				"_id": "422651665",
				"_name": "Key to Apt. B-102"
			},
			{
				"_id": "2151184043",
				"_name": "Key to Apt. B-204"
			},
			{
				"_id": "4148119101",
				"_name": "Key to Apt. B-301"
			},
			{
				"_id": "1767625630",
				"_name": "Key to Apt. C-101"
			},
			{
				"_id": "509403912",
				"_name": "Key to Apt. C-303"
			},
			{
				"_id": "4158193168",
				"_name": "Movie Poster"
			},
			{
				"_id": "2162151046",
				"_name": "Rockin' Jumpsuit"
			},
			{
				"_id": "433495868",
				"_name": "Hero Cutout"
			},
			{
				"_id": "1859235754",
				"_name": "Film Reel"
			},
			{
				"_id": "4268667451",
				"_name": "Curry-Shop Sign"
			},
			{
				"_id": "2305393325",
				"_name": "Famous Frock"
			},
			{
				"_id": "3920497480",
				"_name": "Otterina"
			},
			{
				"_id": "2661891038",
				"_name": "Y-Cola Bottle"
			},
			{
				"_id": "127953508",
				"_name": "Waddle Potty"
			},
			{
				"_id": "1890015986",
				"_name": "Snap-Turtle Doll"
			},
			{
				"_id": "4005810001",
				"_name": "Nyaight Scroll"
			},
			{
				"_id": "2579824583",
				"_name": "Victory Scroll"
			},
			{
				"_id": "13479549",
				"_name": "Nyext Scroll"
			},
			{
				"_id": "4158121970",
				"_name": "Bun of Oneness"
			},
			{
				"_id": "1860089416",
				"_name": "Critical Lost Item"
			},
			{
				"_id": "2277315453",
				"_name": "Ghostly Goo"
			},
			{
				"_id": "4038730731",
				"_name": "Red Card Key"
			},
			{
				"_id": "1773367889",
				"_name": "Blue Card Key"
			},
			{
				"_id": "515130055",
				"_name": "Gold Card Key"
			},
			{
				"_id": "2383109974",
				"_name": "Muscle Belt"
			},
			{
				"_id": "4178341824",
				"_name": "Blunt Sword"
			},
			{
				"_id": "2580276773",
				"_name": "New Retro Robot"
			},
			{
				"_id": "4006401715",
				"_name": "Old Retro Robot"
			},
			{
				"_id": "2009433865",
				"_name": "Treasure Map"
			},
			{
				"_id": "12760991",
				"_name": "Soggy Map"
			},
			{
				"_id": "2661687868",
				"_name": "Crumpled Map"
			},
			{
				"_id": "3919647402",
				"_name": "Stained Map"
			},
			{
				"_id": "1890075408",
				"_name": "New Treasure Map"
			},
			{
				"_id": "128938886",
				"_name": "Treasure Room Key"
			},
			{
				"_id": "2534436375",
				"_name": "Final Treasure Map"
			},
			{
				"_id": "3759627905",
				"_name": "Strange Handle"
			},
			{
				"_id": "3001464294",
				"_name": "B&W Camera"
			},
			{
				"_id": "3319891312",
				"_name": "School Photo"
			},
			{
				"_id": "1558762698",
				"_name": "Galleria Blvd Pic"
			},
			{
				"_id": "737141852",
				"_name": "Gourdzilla Photo"
			},
			{
				"_id": "3045814783",
				"_name": "Autograph Card"
			},
			{
				"_id": "3263971689",
				"_name": "Fluffy Towel"
			},
			{
				"_id": "3848423452",
				"_name": "Sharp-Toothed Comb"
			},
			{
				"_id": "2087393702",
				"_name": "Dance Revolution"
			},
			{
				"_id": "191637808",
				"_name": "Hexpress Pass"
			},
			{
				"_id": "2500377747",
				"_name": "Gera Gera Land Ticket"
			},
			{
				"_id": "3792669701",
				"_name": "Paradise Springs Ticket"
			},
			{
				"_id": "2064047551",
				"_name": "Wolfit Down Ticket"
			},
			{
				"_id": "201452841",
				"_name": "Heavenly Bath Pass"
			},
			{
				"_id": "2629759160",
				"_name": "Mountain Bath Pass"
			},
			{
				"_id": "3954819118",
				"_name": "Hill Bath Pass"
			},
			{
				"_id": "2340309451",
				"_name": "Wanderer's Bath Pass"
			},
			{
				"_id": "4235819357",
				"_name": "Forest Bath Pass"
			},
			{
				"_id": "1701849319",
				"_name": "Lucky Bath Pass"
			},
			{
				"_id": "309794929",
				"_name": "Treasure Bath Pass"
			},
			{
				"_id": "2350091730",
				"_name": "Utility Belt"
			},
			{
				"_id": "4212440388",
				"_name": "Cloak of Secrecy"
			},
			{
				"_id": "1646128382",
				"_name": "Brake Handle"
			},
			{
				"_id": "354081896",
				"_name": "Happy-Go-Lucky Pass"
			},
			{
				"_id": "2242232825",
				"_name": "Lucky Crank-a-Coin"
			},
			{
				"_id": "4070764911",
				"_name": "Moxie Mark"
			},
			{
				"_id": "2689800712",
				"_name": "Important Item 20"
			},
			{
				"_id": "3612617374",
				"_name": "Important Item 21"
			},
			{
				"_id": "1314749220",
				"_name": "Important Item 22"
			},
			{
				"_id": "962218930",
				"_name": "Important Item 23"
			},
			{
				"_id": "2805915153",
				"_name": "Important Item 24"
			},
			{
				"_id": "3493457543",
				"_name": "Important Item 25"
			},
			{
				"_id": "3503128323",
				"_name": "Melon Seeds"
			},
			{
				"_id": "2815053717",
				"_name": "Orange Seeds"
			},
			{
				"_id": "930435588",
				"_name": "Kiwi Seeds"
			},
			{
				"_id": "1081238162",
				"_name": "Grape Seeds"
			},
			{
				"_id": "548793207",
				"_name": "Berry Seeds"
			},
			{
				"_id": "1471339489",
				"_name": "Watermelon Sds."
			},
			{
				"_id": "3468397147",
				"_name": "Walkappa Cog"
			},
			{
				"_id": "3116153549",
				"_name": "Komasan Cog"
			},
			{
				"_id": "668479342",
				"_name": "Hungramps Cog"
			},
			{
				"_id": "1356799992",
				"_name": "Manjimutt Cog"
			},
			{
				"_id": "3386265154",
				"_name": "Noko Cog"
			},
			{
				"_id": "3201400532",
				"_name": "Draggie Cog"
			},
			{
				"_id": "778986309",
				"_name": "F-Series Bell"
			},
			{
				"_id": "1500074963",
				"_name": "Sailor Bell"
			},
			{
				"_id": "194558132",
				"_name": "Macho Bell"
			},
			{
				"_id": "2090829858",
				"_name": "Wonderer's Bell"
			},
			{
				"_id": "3851868568",
				"_name": "Jet Bell"
			},
			{
				"_id": "2459035918",
				"_name": "Boo Bundle"
			},
			{
				"_id": "217414829",
				"_name": "Keepsake Cap"
			},
			{
				"_id": "2079476795",
				"_name": "Dark Bell"
			}
		]
	}
}
