xmlval = {
	"items": {
		"item": [
			{
				"_id": "2170728737",
				"_name": "Chocobar"
			},
			{
				"_id": "1803927674",
				"_name": "Plum Rice Ball"
			},
			{
				"_id": "4069298624",
				"_name": "Leaf Rice Ball"
			},
			{
				"_id": "2240520534",
				"_name": "Roe Rice Ball"
			},
			{
				"_id": "468661493",
				"_name": "Shrimp Rice Ball"
			},
			{
				"_id": "1783081549",
				"_name": "Sandwich"
			},
			{
				"_id": "4082039799",
				"_name": "Custard Bread"
			},
			{
				"_id": "1831497300",
				"_name": "Curry Bread"
			},
			{
				"_id": "2219428705",
				"_name": "Baguette"
			},
			{
				"_id": "439180994",
				"_name": "Blehgel"
			},
			{
				"_id": "1744901140",
				"_name": "10p Gum"
			},
			{
				"_id": "4043851182",
				"_name": "Gooey Candy"
			},
			{
				"_id": "2249159992",
				"_name": "Giant Cracker"
			},
			{
				"_id": "409723035",
				"_name": "Fruit Drops"
			},
			{
				"_id": "1869402125",
				"_name": "Shaved Ice"
			},
			{
				"_id": "4133847479",
				"_name": "Candy Apple"
			},
			{
				"_id": "1774419491",
				"_name": "Milk"
			},
			{
				"_id": "4039782297",
				"_name": "Coffee Milk"
			},
			{
				"_id": "2278366991",
				"_name": "Fruit Milk"
			},
			{
				"_id": "430541484",
				"_name": "Amazing Milk"
			},
			{
				"_id": "1821141158",
				"_name": "Y-Cola"
			},
			{
				"_id": "4119148828",
				"_name": "Soul Tea"
			},
			{
				"_id": "2189560202",
				"_name": "Spiritizer Y"
			},
			{
				"_id": "484875305",
				"_name": "VoltXtreme"
			},
			{
				"_id": "1833829009",
				"_name": "Hamburger"
			},
			{
				"_id": "4098315051",
				"_name": "Cheeseburger"
			},
			{
				"_id": "2202035133",
				"_name": "Double Burger"
			},
			{
				"_id": "488961566",
				"_name": "Nom Burger"
			},
			{
				"_id": "1858787071",
				"_name": "Ramen Cup"
			},
			{
				"_id": "4156786501",
				"_name": "Pork Ramen"
			},
			{
				"_id": "2160375763",
				"_name": "Deluxe Ramen"
			},
			{
				"_id": "513811056",
				"_name": "Everything Ramen"
			},
			{
				"_id": "1704366530",
				"_name": "Cucumber Roll"
			},
			{
				"_id": "4238327928",
				"_name": "Shrimp Sushi"
			},
			{
				"_id": "2342056174",
				"_name": "Salmon Sushi"
			},
			{
				"_id": "368862541",
				"_name": "Fatty Tuna Sushi"
			},
			{
				"_id": "1683291125",
				"_name": "Pot Stickers"
			},
			{
				"_id": "4250774095",
				"_name": "Liver & Chives"
			},
			{
				"_id": "2321193689",
				"_name": "Crab Omelet"
			},
			{
				"_id": "339611514",
				"_name": "Chili Shrimp"
			},
			{
				"_id": "1664696300",
				"_name": "Mapo Tofu"
			},
			{
				"_id": "3539717416",
				"_name": "Carrot"
			},
			{
				"_id": "1274190994",
				"_name": "Cucumber"
			},
			{
				"_id": "1022733316",
				"_name": "Bamboo Shoot"
			},
			{
				"_id": "2727426471",
				"_name": "Matsutake"
			},
			{
				"_id": "3502076785",
				"_name": "Chicken Thigh"
			},
			{
				"_id": "1236542155",
				"_name": "Slab Bacon"
			},
			{
				"_id": "1051923037",
				"_name": "Beef Tongue"
			},
			{
				"_id": "2698479614",
				"_name": "Marbled Beef"
			},
			{
				"_id": "3514767686",
				"_name": "Dried Mackerel"
			},
			{
				"_id": "1215711484",
				"_name": "Yellowtail"
			},
			{
				"_id": "1064401002",
				"_name": "Fresh Urchin"
			},
			{
				"_id": "2702568905",
				"_name": "Choice Tuna"
			},
			{
				"_id": "3559919555",
				"_name": "Chicken Curry"
			},
			{
				"_id": "1295605369",
				"_name": "Lamb Curry"
			},
			{
				"_id": "977170159",
				"_name": "Seafood Curry"
			},
			{
				"_id": "2757425996",
				"_name": "Buster Curry"
			},
			{
				"_id": "3546139610",
				"_name": "Veggie Curry"
			},
			{
				"_id": "3589432820",
				"_name": "Cheesecake"
			},
			{
				"_id": "1291531342",
				"_name": "Shortcake"
			},
			{
				"_id": "1006372056",
				"_name": "Royal Pancakes"
			},
			{
				"_id": "2778239355",
				"_name": "Jumbo Parfait"
			},
			{
				"_id": "3533677037",
				"_name": "Sweet Rice Cake"
			},
			{
				"_id": "1268183127",
				"_name": "Spirit Doughnut"
			},
			{
				"_id": "1016185025",
				"_name": "Soul Doughnut"
			},
			{
				"_id": "3618954157",
				"_name": "Steamed Daikon"
			},
			{
				"_id": "1321044503",
				"_name": "Boiled Egg"
			},
			{
				"_id": "968538753",
				"_name": "Beef Skewers"
			},
			{
				"_id": "2816356130",
				"_name": "Top-Class Oden"
			},
			{
				"_id": "3598102938",
				"_name": "Soba Noodles"
			},
			{
				"_id": "3710580391",
				"_name": "Potato Chips"
			},
			{
				"_id": "1143187229",
				"_name": "Tasty Nibbles"
			},
			{
				"_id": "858036107",
				"_name": "Cheesy Chips"
			},
			{
				"_id": "2906653224",
				"_name": "Snow-Pea Snack"
			},
			{
				"_id": "2370076515",
				"_name": "Mini Exporb"
			},
			{
				"_id": "320924352",
				"_name": "Small Exporb"
			},
			{
				"_id": "2317990778",
				"_name": "Medium Exporb"
			},
			{
				"_id": "4247686124",
				"_name": "Large Exporb"
			},
			{
				"_id": "1665801807",
				"_name": "Mega Exporb"
			},
			{
				"_id": "340602585",
				"_name": "Holy Exporb"
			},
			{
				"_id": "397252210",
				"_name": "Staminum"
			},
			{
				"_id": "2393163720",
				"_name": "Staminum Alpha"
			},
			{
				"_id": "279199406",
				"_name": "Hidden Hits"
			},
			{
				"_id": "2309844756",
				"_name": "Top Techniques"
			},
			{
				"_id": "4272578434",
				"_name": "Soul Secrets"
			},
			{
				"_id": "469268883",
				"_name": "A Serious Life"
			},
			{
				"_id": "2196842537",
				"_name": "Think Karate"
			},
			{
				"_id": "4126546111",
				"_name": "Use Karate"
			},
			{
				"_id": "1804766492",
				"_name": "Skill Compendium"
			},
			{
				"_id": "479575434",
				"_name": "Skill Encyclopedia"
			},
			{
				"_id": "2241653808",
				"_name": "Get Guarding"
			},
			{
				"_id": "4070300838",
				"_name": "Guard Gloriously"
			},
			{
				"_id": "1646575927",
				"_name": "Li'l Angel Heals"
			},
			{
				"_id": "354677153",
				"_name": "Bye, Li'l Angel"
			},
			{
				"_id": "1977907268",
				"_name": "The Pest's Quest"
			},
			{
				"_id": "48449746",
				"_name": "The Perfect Pest"
			},
			{
				"_id": "2615810408",
				"_name": "Support Life #7"
			},
			{
				"_id": "3974965758",
				"_name": "Support Special"
			},
			{
				"_id": "367732779",
				"_name": "Str. Talisman"
			},
			{
				"_id": "2363652497",
				"_name": "Spirit Talisman"
			},
			{
				"_id": "4226107655",
				"_name": "Def. Talisman"
			},
			{
				"_id": "1703009444",
				"_name": "Speed Talisman"
			},
			{
				"_id": "338248220",
				"_name": "Nasty Medicine"
			},
			{
				"_id": "2367689638",
				"_name": "Bitter Medicine"
			},
			{
				"_id": "4196868912",
				"_name": "Mighty Medicine"
			},
			{
				"_id": "376437829",
				"_name": "Getaway Plush"
			},
			{
				"_id": "1628217366",
				"_name": "Iron Doll"
			},
			{
				"_id": "291919001",
				"_name": "Bronze Doll"
			},
			{
				"_id": "2288977187",
				"_name": "Silver Doll"
			},
			{
				"_id": "4285019573",
				"_name": "Golden Doll"
			},
			{
				"_id": "369856640",
				"_name": "Platinum Doll"
			},
			{
				"_id": "2908180302",
				"_name": "Fish Bait"
			},
			{
				"_id": "878583540",
				"_name": "Black Syrup"
			},
			{
				"_id": "2895455609",
				"_name": "Dancing Star"
			},
			{
				"_id": "899445955",
				"_name": "Lottery Ticket"
			},
			{
				"_id": "1117471829",
				"_name": "Music Card"
			},
			{
				"_id": "1535145236",
				"_name": "Bronze Tag"
			},
			{
				"_id": "3320111287",
				"_name": "Silver Tag"
			},
			{
				"_id": "3001274401",
				"_name": "Gold Tag"
			},
			{
				"_id": "747062658",
				"_name": "Essence of Evil"
			},
			{
				"_id": "440013732",
				"_name": "Legendary Blade"
			},
			{
				"_id": "2201174558",
				"_name": "Cursed Blade"
			},
			{
				"_id": "2220787207",
				"_name": "Holy Blade"
			},
			{
				"_id": "4097077896",
				"_name": "General's Soul"
			},
			{
				"_id": "1783686955",
				"_name": "Love Buster"
			},
			{
				"_id": "492296125",
				"_name": "GHz Orb"
			},
			{
				"_id": "1676061440",
				"_name": "Unbeatable Soul"
			},
			{
				"_id": "2586342239",
				"_name": "Platinum Bar"
			},
			{
				"_id": "350329750",
				"_name": "Snowstorm Cloak"
			},
			{
				"_id": "1948652147",
				"_name": "Love Scepter"
			},
			{
				"_id": "4082742929",
				"_name": "Glacial Clip"
			},
			{
				"_id": "52503269",
				"_name": "Buff Weight"
			},
			{
				"_id": "1934349930",
				"_name": "Shard of Evil"
			},
			{
				"_id": "3979297737",
				"_name": "Ageless Powder"
			},
			{
				"_id": "2638591814",
				"_name": "Dragon Orb"
			},
			{
				"_id": "1098757352",
				"_name": "Raging Blade"
			},
			{
				"_id": "913998974",
				"_name": "Sand Suit"
			},
			{
				"_id": "2943604164",
				"_name": "Ethereal Water"
			},
			{
				"_id": "3631539538",
				"_name": "Cursed Journal"
			},
			{
				"_id": "1221327043",
				"_name": "Horn"
			},
			{
				"_id": "1070385237",
				"_name": "Mem-o-Vac"
			},
			{
				"_id": "156362294",
				"_name": "Mermaid Pearl"
			},
			{
				"_id": "1771466707",
				"_name": "Love-Packed Rice Ball"
			},
			{
				"_id": "2119620256",
				"_name": "Broken Bell"
			},
			{
				"_id": "2033914553",
				"_name": "Battered Blade"
			},
			{
				"_id": "3761390339",
				"_name": "Rough Whetstone"
			},
			{
				"_id": "2536862613",
				"_name": "Sinister Whetstone"
			},
			{
				"_id": "126512644",
				"_name": "Sublime Whetstone"
			},
			{
				"_id": "273340279",
				"_name": "Carved Bear"
			},
			{
				"_id": "1733158881",
				"_name": "Goldfish Lantern"
			},
			{
				"_id": "4265915995",
				"_name": "Master's Lantern"
			},
			{
				"_id": "2302904013",
				"_name": "Gold Emblem"
			},
			{
				"_id": "388436846",
				"_name": "Takoyaki Tray"
			},
			{
				"_id": "1612719096",
				"_name": "Dune Sand"
			},
			{
				"_id": "4180243010",
				"_name": "Vintage Parasol"
			},
			{
				"_id": "2385396436",
				"_name": "Terracotta Figure"
			},
			{
				"_id": "512843589",
				"_name": "Red Hibiscus"
			},
			{
				"_id": "3881797402",
				"_name": "Healing Herb"
			},
			{
				"_id": "2421733260",
				"_name": "Stinky Herb"
			},
			{
				"_id": "238821935",
				"_name": "Bitter Herb"
			},
			{
				"_id": "2592718716",
				"_name": "Red Coin"
			},
			{
				"_id": "58781382",
				"_name": "Yellow Coin"
			},
			{
				"_id": "1955061328",
				"_name": "Orange Coin"
			},
			{
				"_id": "3940764659",
				"_name": "Pink Coin"
			},
			{
				"_id": "2648996709",
				"_name": "Green Coin"
			},
			{
				"_id": "82651871",
				"_name": "Blue Coin"
			},
			{
				"_id": "1944721993",
				"_name": "Purple Coin"
			},
			{
				"_id": "3814000600",
				"_name": "Light-Blue Coin"
			},
			{
				"_id": "3411442988",
				"_name": "Five-Star Coin"
			},
			{
				"_id": "1542021309",
				"_name": "Special Coin"
			},
			{
				"_id": "753815595",
				"_name": "Yo Mystery Coin"
			},
			{
				"_id": "1277811150",
				"_name": "Kai Mystery Coin"
			},
			{
				"_id": "992930136",
				"_name": "Sum Mystery Coin"
			},
			{
				"_id": "2720512226",
				"_name": "Mon Mystery Coin"
			},
			{
				"_id": "905273706",
				"_name": "Flower Excitement Coin"
			},
			{
				"_id": "1728350733",
				"_name": "Bird Excitement Coin"
			},
			{
				"_id": "268679835",
				"_name": "Wind Excitement Coin"
			},
			{
				"_id": "2299194145",
				"_name": "Moon Excitement Coin"
			},
			{
				"_id": "4262321079",
				"_name": "Glitzy Coin"
			},
			{
				"_id": "1617514004",
				"_name": "Traveler's Coin North"
			},
			{
				"_id": "393117314",
				"_name": "Traveler's Coin Northeast"
			},
			{
				"_id": "2389126968",
				"_name": "Traveler's Coin East"
			},
			{
				"_id": "4183826350",
				"_name": "Traveler's Coin Central"
			},
			{
				"_id": "1776222783",
				"_name": "Traveler's Coin West"
			},
			{
				"_id": "517485225",
				"_name": "Traveler's Coin Mountain"
			},
			{
				"_id": "2116008780",
				"_name": "Traveler's Coin South"
			},
			{
				"_id": "152603610",
				"_name": "Traveler's Coin Midwest"
			},
			{
				"_id": "2417089120",
				"_name": "Traveler's Coin Island"
			},
			{
				"_id": "3877038838",
				"_name": "Mystery Coin"
			},
			{
				"_id": "2037546837",
				"_name": "Boar Mystery Coin"
			},
			{
				"_id": "242569155",
				"_name": "Deer Mystery Coin"
			},
			{
				"_id": "2541493881",
				"_name": "Butterfly Mystery Coin"
			},
			{
				"_id": "3766169327",
				"_name": "Cheerful Coin"
			},
			{
				"_id": "3707752950",
				"_name": "Red Coin Fragment"
			},
			{
				"_id": "2885214560",
				"_name": "Yellow Coin Fragment"
			},
			{
				"_id": "854700250",
				"_name": "Orange Coin Fragment"
			},
			{
				"_id": "1173782604",
				"_name": "Pink Coin Fragment"
			},
			{
				"_id": "3578371549",
				"_name": "Green Coin Fragment"
			},
			{
				"_id": "2723065163",
				"_name": "Blue Coin Fragment"
			},
			{
				"_id": "3263767726",
				"_name": "Purple Coin Fragment"
			},
			{
				"_id": "3045987384",
				"_name": "Light-Blue Fragment"
			},
			{
				"_id": "1200047969",
				"_name": "Red Box"
			},
			{
				"_id": "1178938710",
				"_name": "Gate Globe"
			},
			{
				"_id": "2285637778",
				"_name": "Noko Orb"
			},
			{
				"_id": "288702760",
				"_name": "Kyubi Orb"
			}
		]
	}
}
