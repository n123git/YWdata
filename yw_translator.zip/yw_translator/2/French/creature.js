xmlval = {
	"items": {
		"item": [
			{
				"_id": "3493734398",
				"_name": "Cigale verte"
			},
			{
				"_id": "1753366683",
				"_name": "Cigale verte★"
			},
			{
				"_id": "1228371524",
				"_name": "Cigale marron"
			},
			{
				"_id": "4052422945",
				"_name": "Cigale marron★"
			},
			{
				"_id": "1702355358",
				"_name": "Grosse cigale"
			},
			{
				"_id": "3721103099",
				"_name": "Grosse cigale★"
			},
			{
				"_id": "4236161060",
				"_name": "Cigale d'Afrique"
			},
			{
				"_id": "1153619777",
				"_name": "Cigale d'Afrique★"
			},
			{
				"_id": "1043351250",
				"_name": "Cigale du soir"
			},
			{
				"_id": "2257330615",
				"_name": "Cigale du soir★"
			},
			{
				"_id": "2339995826",
				"_name": "Cigale d'Asie"
			},
			{
				"_id": "868607959",
				"_name": "Cigale d'Asie★"
			},
			{
				"_id": "1314566749",
				"_name": "Lucane"
			},
			{
				"_id": "4142323000",
				"_name": "Lucane★"
			},
			{
				"_id": "858605080",
				"_name": "Lucane cerf-volant"
			},
			{
				"_id": "2341544317",
				"_name": "Lucane cerf-vol.★"
			},
			{
				"_id": "354227473",
				"_name": "Lucane du Japon"
			},
			{
				"_id": "2913038964",
				"_name": "Lucane du Japon★"
			},
			{
				"_id": "3612599271",
				"_name": "Petite biche"
			},
			{
				"_id": "1877968002",
				"_name": "Petite biche★"
			},
			{
				"_id": "2689913713",
				"_name": "Scarabée rhino."
			},
			{
				"_id": "417903636",
				"_name": "Scarab. rhino.★"
			},
			{
				"_id": "2350138539",
				"_name": "Phalène blanche"
			},
			{
				"_id": "883434446",
				"_name": "Phalène blanche★"
			},
			{
				"_id": "3374651071",
				"_name": "Machaon"
			},
			{
				"_id": "1905881562",
				"_name": "Machaon★"
			},
			{
				"_id": "2063668422",
				"_name": "Papillon paon"
			},
			{
				"_id": "3283973027",
				"_name": "Papillon paon★"
			},
			{
				"_id": "541504394",
				"_name": "Papillon mauve"
			},
			{
				"_id": "2566575343",
				"_name": "Papillon mauve★"
			},
			{
				"_id": "3662603053",
				"_name": "Libellule lydienne"
			},
			{
				"_id": "1660060744",
				"_name": "Libellule lydienne★"
			},
			{
				"_id": "2907296699",
				"_name": "Anax empereur"
			},
			{
				"_id": "368424158",
				"_name": "Anax empereur★"
			},
			{
				"_id": "2969153051",
				"_name": "Libellule géante"
			},
			{
				"_id": "138791294",
				"_name": "Libellule géante★"
			},
			{
				"_id": "3189909033",
				"_name": "Luciole"
			},
			{
				"_id": "111034700",
				"_name": "Luciole★"
			},
			{
				"_id": "3109020208",
				"_name": "Coccinelle"
			},
			{
				"_id": "32736597",
				"_name": "Coccinelle★"
			},
			{
				"_id": "962429643",
				"_name": "Criquet"
			},
			{
				"_id": "2179065262",
				"_name": "Criquet★"
			},
			{
				"_id": "1463911196",
				"_name": "Criquet du riz"
			},
			{
				"_id": "4026393721",
				"_name": "Criquet du riz★"
			},
			{
				"_id": "3739594700",
				"_name": "Sauterelle"
			},
			{
				"_id": "1717160105",
				"_name": "Sauterelle★"
			},
			{
				"_id": "2455941619",
				"_name": "Grillon"
			},
			{
				"_id": "719246998",
				"_name": "Grillon★"
			},
			{
				"_id": "2087506143",
				"_name": "Grillon du Japon"
			},
			{
				"_id": "3302012858",
				"_name": "Grillon du Japon★"
			},
			{
				"_id": "201729104",
				"_name": "Sauterelle verte"
			},
			{
				"_id": "3032105781",
				"_name": "Sauterelle verte★"
			},
			{
				"_id": "1563510735",
				"_name": "Mante d'Asie"
			},
			{
				"_id": "3851231402",
				"_name": "Mante d'Asie★"
			},
			{
				"_id": "2850201434",
				"_name": "Mante religieuse"
			},
			{
				"_id": "291436607",
				"_name": "Mante religieuse★"
			},
			{
				"_id": "1345079045",
				"_name": "Longicorne"
			},
			{
				"_id": "3901759584",
				"_name": "Longicorne★"
			},
			{
				"_id": "3448658526",
				"_name": "Phasme"
			},
			{
				"_id": "1966226747",
				"_name": "Phasme★"
			},
			{
				"_id": "3710068532",
				"_name": "Courtilière"
			},
			{
				"_id": "1704935505",
				"_name": "Courtilière★"
			},
			{
				"_id": "2614427096",
				"_name": "Cloporte"
			},
			{
				"_id": "594057917",
				"_name": "Cloporte★"
			},
			{
				"_id": "657160083",
				"_name": "Cétoine"
			},
			{
				"_id": "2677477622",
				"_name": "Cétoine★"
			},
			{
				"_id": "3848634725",
				"_name": "Scarabée commun"
			},
			{
				"_id": "1574561280",
				"_name": "Scarab. commun★"
			},
			{
				"_id": "2500818410",
				"_name": "Scarabée du Japon"
			},
			{
				"_id": "766710415",
				"_name": "Scarab. du Japon★"
			},
			{
				"_id": "3792192892",
				"_name": "Punaise"
			},
			{
				"_id": "1521754649",
				"_name": "Punaise★"
			},
			{
				"_id": "4123589647",
				"_name": "Dytique"
			},
			{
				"_id": "1299487594",
				"_name": "Dytique★"
			},
			{
				"_id": "3025330938",
				"_name": "Punaise d'eau"
			},
			{
				"_id": "216958367",
				"_name": "Punaise d'eau★"
			},
			{
				"_id": "191619145",
				"_name": "Bupreste"
			},
			{
				"_id": "3017246508",
				"_name": "Bupreste★"
			},
			{
				"_id": "3973303630",
				"_name": "Lézard du Japon"
			},
			{
				"_id": "1416604203",
				"_name": "Lézard du Japon★"
			},
			{
				"_id": "2854492066",
				"_name": "Lézard"
			},
			{
				"_id": "311980231",
				"_name": "Lézard★"
			},
			{
				"_id": "2194656409",
				"_name": "Triton cynops"
			},
			{
				"_id": "980659196",
				"_name": "Triton cynops★"
			},
			{
				"_id": "1516012502",
				"_name": "Crevette à bouclier"
			},
			{
				"_id": "3806389427",
				"_name": "Crev. à bouclier★"
			},
			{
				"_id": "708212569",
				"_name": "Limnée"
			},
			{
				"_id": "2458521660",
				"_name": "Limnée★"
			},
			{
				"_id": "1143633550",
				"_name": "Escargot-pomme"
			},
			{
				"_id": "4237693419",
				"_name": "Escargot-pomme★"
			},
			{
				"_id": "3355352717",
				"_name": "Escargot"
			},
			{
				"_id": "2135095784",
				"_name": "Escargot★"
			},
			{
				"_id": "3460879014",
				"_name": "Grenouille arbor."
			},
			{
				"_id": "1995748803",
				"_name": "Grenouille arbor.★"
			},
			{
				"_id": "4212356157",
				"_name": "Crapaud"
			},
			{
				"_id": "1135547224",
				"_name": "Crapaud★"
			},
			{
				"_id": "3522973129",
				"_name": "Tortue"
			},
			{
				"_id": "1765812908",
				"_name": "Tortue★"
			},
			{
				"_id": "3325883578",
				"_name": "Tortue molle"
			},
			{
				"_id": "2122355679",
				"_name": "Tortue molle★"
			},
			{
				"_id": "230968935",
				"_name": "Crabe"
			},
			{
				"_id": "3044550914",
				"_name": "Crabe★"
			},
			{
				"_id": "2496471005",
				"_name": "Écrevisse"
			},
			{
				"_id": "745633976",
				"_name": "Écrevisse★"
			},
			{
				"_id": "2108603112",
				"_name": "Homard"
			},
			{
				"_id": "3306347917",
				"_name": "Homard★"
			},
			{
				"_id": "3321527362",
				"_name": "Crevette"
			},
			{
				"_id": "2101746471",
				"_name": "Crevette★"
			},
			{
				"_id": "3002944724",
				"_name": "Étoile de mer"
			},
			{
				"_id": "172043185",
				"_name": "Étoile de mer★"
			},
			{
				"_id": "350191398",
				"_name": "Hippocampe"
			},
			{
				"_id": "2892175427",
				"_name": "Hippocampe★"
			},
			{
				"_id": "2711009606",
				"_name": "Carpe"
			},
			{
				"_id": "422239779",
				"_name": "Carpe★"
			},
			{
				"_id": "3599862224",
				"_name": "Ayu"
			},
			{
				"_id": "1848503989",
				"_name": "Ayu★"
			},
			{
				"_id": "748280183",
				"_name": "Mulet"
			},
			{
				"_id": "2485501458",
				"_name": "Mulet★"
			},
			{
				"_id": "2476792772",
				"_name": "Saumon du Japon"
			},
			{
				"_id": "723303585",
				"_name": "Saum. du Japon★"
			},
			{
				"_id": "2973484076",
				"_name": "Carpe koï"
			},
			{
				"_id": "159884105",
				"_name": "Carpe koï★"
			},
			{
				"_id": "1224023155",
				"_name": "Perche noire"
			},
			{
				"_id": "4031347478",
				"_name": "Perche noire★"
			},
			{
				"_id": "2059632369",
				"_name": "Saumon"
			},
			{
				"_id": "3263109524",
				"_name": "Saumon★"
			},
			{
				"_id": "1072835813",
				"_name": "Huchon géant"
			},
			{
				"_id": "2270055296",
				"_name": "Huchon géant★"
			},
			{
				"_id": "178883198",
				"_name": "Sardine"
			},
			{
				"_id": "2987781403",
				"_name": "Sardine★"
			},
			{
				"_id": "950003964",
				"_name": "Maquereau"
			},
			{
				"_id": "2149814169",
				"_name": "Maquereau★"
			},
			{
				"_id": "4208008714",
				"_name": "Lisette"
			},
			{
				"_id": "1114470767",
				"_name": "Lisette★"
			},
			{
				"_id": "2379624092",
				"_name": "Sillago"
			},
			{
				"_id": "896158201",
				"_name": "Sillago★"
			},
			{
				"_id": "3683420442",
				"_name": "Barracuda"
			},
			{
				"_id": "1664151167",
				"_name": "Barracuda★"
			},
			{
				"_id": "2327571077",
				"_name": "Poisson volant"
			},
			{
				"_id": "839355872",
				"_name": "Poisson volant★"
			},
			{
				"_id": "1335416938",
				"_name": "Têtes-de-serp."
			},
			{
				"_id": "4146380559",
				"_name": "Têtes-de-serp.★"
			},
			{
				"_id": "3481974929",
				"_name": "Rascasse"
			},
			{
				"_id": "2000084980",
				"_name": "Rascasse★"
			},
			{
				"_id": "1537141217",
				"_name": "Maigre"
			},
			{
				"_id": "3810692740",
				"_name": "Maigre★"
			},
			{
				"_id": "1559440888",
				"_name": "Bar"
			},
			{
				"_id": "3830401693",
				"_name": "Bar★"
			},
			{
				"_id": "2884009365",
				"_name": "Brème noire"
			},
			{
				"_id": "324672240",
				"_name": "Brème noire★"
			},
			{
				"_id": "3977357177",
				"_name": "Monacanthe"
			},
			{
				"_id": "1437450268",
				"_name": "Monacanthe★"
			},
			{
				"_id": "1689619369",
				"_name": "Flétan"
			},
			{
				"_id": "3691637964",
				"_name": "Flétan★"
			},
			{
				"_id": "3264723035",
				"_name": "Flet"
			},
			{
				"_id": "2049695550",
				"_name": "Flet★"
			},
			{
				"_id": "2820732269",
				"_name": "Vivaneau rouge"
			},
			{
				"_id": "278696456",
				"_name": "Vivaneau rouge★"
			},
			{
				"_id": "1451485483",
				"_name": "Daurade rayée"
			},
			{
				"_id": "3997142606",
				"_name": "Daurade rayée★"
			},
			{
				"_id": "3705752835",
				"_name": "Marbré"
			},
			{
				"_id": "1683827302",
				"_name": "Marbré★"
			},
			{
				"_id": "330480447",
				"_name": "Sériole"
			},
			{
				"_id": "2869877850",
				"_name": "Sériole★"
			},
			{
				"_id": "4257012243",
				"_name": "Poisson-lune"
			},
			{
				"_id": "1157676406",
				"_name": "Poisson-lune★"
			},
			{
				"_id": "562354621",
				"_name": "Silure"
			},
			{
				"_id": "2570632920",
				"_name": "Silure★"
			},
			{
				"_id": "737418606",
				"_name": "Sabre argenté"
			},
			{
				"_id": "2471000587",
				"_name": "Sabre argenté★"
			},
			{
				"_id": "3836210002",
				"_name": "Congre"
			},
			{
				"_id": "1545309239",
				"_name": "Congre★"
			},
			{
				"_id": "3821678411",
				"_name": "Anguille"
			},
			{
				"_id": "1534478382",
				"_name": "Anguille★"
			},
			{
				"_id": "3096283143",
				"_name": "Poisson-chat"
			},
			{
				"_id": "3272546",
				"_name": "Poisson-chat★"
			},
			{
				"_id": "3370613896",
				"_name": "Méduse"
			},
			{
				"_id": "1885019117",
				"_name": "Méduse★"
			},
			{
				"_id": "1675120560",
				"_name": "Pieuvre"
			},
			{
				"_id": "3680774357",
				"_name": "Pieuvre★"
			},
			{
				"_id": "2894838156",
				"_name": "Calamar de récif"
			},
			{
				"_id": "339205865",
				"_name": "Calmar de récif★"
			},
			{
				"_id": "4094334520",
				"_name": "Seiche"
			},
			{
				"_id": "1287057757",
				"_name": "Seiche★"
			},
			{
				"_id": "1374563634",
				"_name": "Calamar-luciole"
			},
			{
				"_id": "3914484311",
				"_name": "Calamar-luciole★"
			},
			{
				"_id": "3046148301",
				"_name": "Encornet"
			},
			{
				"_id": "221048744",
				"_name": "Encornet★"
			},
			{
				"_id": "897771574",
				"_name": "Calamar totam"
			},
			{
				"_id": "2369687379",
				"_name": "Calmar totam★"
			},
			{
				"_id": "1116068000",
				"_name": "Poiss.-pêcheur"
			},
			{
				"_id": "4198088645",
				"_name": "Poiss.-pêcheur★"
			},
			{
				"_id": "2585171951",
				"_name": "Raie"
			},
			{
				"_id": "581628042",
				"_name": "Raie★"
			},
			{
				"_id": "3219147806",
				"_name": "Marlin"
			},
			{
				"_id": "123480955",
				"_name": "Marlin★"
			},
			{
				"_id": "2198709934",
				"_name": "Thon"
			},
			{
				"_id": "1001505227",
				"_name": "Thon★"
			}
		]
	}
}
