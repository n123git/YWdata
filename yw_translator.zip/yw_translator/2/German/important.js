xmlval = {
	"items": {
		"item": [
			{
				"_id": "1332445335",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "3596800301",
				"_name": "Yo-kai Watch"
			},
			{
				"_id": "496659440",
				"_name": "Modell Null"
			},
			{
				"_id": "917977139",
				"_name": "Seltsame Uhr"
			},
			{
				"_id": "1102055589",
				"_name": "Seltsame Uhr"
			},
			{
				"_id": "2707808699",
				"_name": "Yo-kai-Medaillium"
			},
			{
				"_id": "1208370318",
				"_name": "Insektenfangnetz"
			},
			{
				"_id": "3507426612",
				"_name": "Angelrute"
			},
			{
				"_id": "2785551778",
				"_name": "Museumsticket"
			},
			{
				"_id": "1450226134",
				"_name": "Frische-Brise-Rad"
			},
			{
				"_id": "3480871020",
				"_name": "Frühlings-Rad"
			},
			{
				"_id": "2270540466",
				"_name": "Sonnenuntergangsrad"
			},
			{
				"_id": "4031939108",
				"_name": "Meeresküstenrad"
			},
			{
				"_id": "1626185653",
				"_name": "Kirschblütenrad"
			},
			{
				"_id": "401256227",
				"_name": "Frisches-Grün-Rad"
			},
			{
				"_id": "1999447750",
				"_name": "Federwolkenrad"
			},
			{
				"_id": "2758224",
				"_name": "Sonnenscheinrad"
			},
			{
				"_id": "2569226218",
				"_name": "Faszinierendes Rad"
			},
			{
				"_id": "3995367292",
				"_name": "Finsternisrad"
			},
			{
				"_id": "1883300575",
				"_name": "Goldenes Rad"
			},
			{
				"_id": "122147401",
				"_name": "Sonnenuntergangsrad"
			},
			{
				"_id": "2655945715",
				"_name": "Meeresküstenrad"
			},
			{
				"_id": "3913921381",
				"_name": "Kirschblütenrad"
			},
			{
				"_id": "2046209780",
				"_name": "Frisches-Grün-Rad"
			},
			{
				"_id": "250715746",
				"_name": "Federwolkenrad"
			},
			{
				"_id": "4038408713",
				"_name": "Sonnenscheinrad"
			},
			{
				"_id": "2276592287",
				"_name": "Faszinierendes Rad"
			},
			{
				"_id": "515595045",
				"_name": "Finsternisrad"
			},
			{
				"_id": "1773956019",
				"_name": "Goldenes Rad"
			},
			{
				"_id": "2471723833",
				"_name": "Auswahlmünze"
			},
			{
				"_id": "561480000",
				"_name": "Spezial-Auswahlmünze"
			},
			{
				"_id": "2487109408",
				"_name": "Tageskarte"
			},
			{
				"_id": "2049975820",
				"_name": "Freifahrkarte"
			},
			{
				"_id": "323085250",
				"_name": "Stempel-Sammelkarte"
			},
			{
				"_id": "3095318778",
				"_name": "Ferien-Hausaufgabe"
			},
			{
				"_id": "639255897",
				"_name": "Wunderpulverchen"
			},
			{
				"_id": "1360885199",
				"_name": "Super-Schraubendreher"
			},
			{
				"_id": "3356763253",
				"_name": "Gespenst-Krapfen"
			},
			{
				"_id": "3205698787",
				"_name": "Seelen-Krapfen"
			},
			{
				"_id": "799803762",
				"_name": "Mamas Wegbeschreibung"
			},
			{
				"_id": "1487616484",
				"_name": "Schulschlüssel"
			},
			{
				"_id": "2320020088",
				"_name": "Komasans Brief"
			},
			{
				"_id": "338438107",
				"_name": "Spiralen-Glocke"
			},
			{
				"_id": "1663768397",
				"_name": "Höllapeño"
			},
			{
				"_id": "4196550391",
				"_name": "Erstklassige Uhr"
			},
			{
				"_id": "2368042593",
				"_name": "Mysteriöse Murmel"
			},
			{
				"_id": "1788697446",
				"_name": "Steinweg-Extrakt"
			},
			{
				"_id": "1543533829",
				"_name": "Milchflaschendeckel"
			},
			{
				"_id": "721896851",
				"_name": "Maximumm-Kartenspiel"
			},
			{
				"_id": "3830756271",
				"_name": "Schuppenschl."
			},
			{
				"_id": "221714074",
				"_name": "Mega Watch"
			},
			{
				"_id": "1057059864",
				"_name": "Schlauch"
			},
			{
				"_id": "173724291",
				"_name": "Anwesenschlüssel (H.)"
			},
			{
				"_id": "1682363220",
				"_name": "Gr. Anwesenschlüssel"
			},
			{
				"_id": "4249846510",
				"_name": "Kl. Anwesenschlüssel"
			},
			{
				"_id": "3812194230",
				"_name": "„Yo-kai World“-Schlüssel"
			},
			{
				"_id": "75586225",
				"_name": "Altes-Haus-Schlüssel"
			},
			{
				"_id": "2009767659",
				"_name": "Schlüssel (Wildschwein)"
			},
			{
				"_id": "3883238266",
				"_name": "Schlüssel (Reh)"
			},
			{
				"_id": "1938188839",
				"_name": "Schlüssel (Falter)"
			},
			{
				"_id": "2103304725",
				"_name": "Peyn-Öl"
			},
			{
				"_id": "3261391014",
				"_name": "SM-Schnappschuss 1"
			},
			{
				"_id": "1390148919",
				"_name": "SM-Schnappschuss 2"
			},
			{
				"_id": "635227553",
				"_name": "SM-Schnappschuss 3"
			},
			{
				"_id": "1159414852",
				"_name": "SM-Schnappschuss 4"
			},
			{
				"_id": "840725714",
				"_name": "SM-Schnappschuss 5"
			},
			{
				"_id": "2870289768",
				"_name": "SM-Schnappschuss 6"
			},
			{
				"_id": "3692172798",
				"_name": "SM-Schnappschuss 7"
			},
			{
				"_id": "1115062365",
				"_name": "SM-Schnappschuss 8"
			},
			{
				"_id": "896643275",
				"_name": "SM-Schnappschuss 9"
			},
			{
				"_id": "2893603185",
				"_name": "SM-Schnappschuss 10"
			},
			{
				"_id": "3682587111",
				"_name": "Dralli Dracka"
			},
			{
				"_id": "1270926454",
				"_name": "Schlüssel (Apt. C-302)"
			},
			{
				"_id": "1019739360",
				"_name": "Schlüssel (Apt. A-201)"
			},
			{
				"_id": "1849038727",
				"_name": "Schlüssel (Apt. A-203)"
			},
			{
				"_id": "422651665",
				"_name": "Schlüssel (Apt. B-102)"
			},
			{
				"_id": "2151184043",
				"_name": "Schlüssel (Apt. B-204)"
			},
			{
				"_id": "4148119101",
				"_name": "Schlüssel (Apt. B-301)"
			},
			{
				"_id": "1767625630",
				"_name": "Schlüssel (Apt. C-101)"
			},
			{
				"_id": "509403912",
				"_name": "Schlüssel (Apt. C-303)"
			},
			{
				"_id": "4158193168",
				"_name": "Monsterfilm-Poster"
			},
			{
				"_id": "2162151046",
				"_name": "Rockstar-Klamotten"
			},
			{
				"_id": "433495868",
				"_name": "Helden-Aufsteller"
			},
			{
				"_id": "1859235754",
				"_name": "SW-Zeichentrickfilm"
			},
			{
				"_id": "4268667451",
				"_name": "Curry-Laden-Schild"
			},
			{
				"_id": "2305393325",
				"_name": "Filmstar-Kleid"
			},
			{
				"_id": "3920497480",
				"_name": "Otterinchen"
			},
			{
				"_id": "2661891038",
				"_name": "Y-Cola-Flasche"
			},
			{
				"_id": "127953508",
				"_name": "Niedlicher Nachttopf"
			},
			{
				"_id": "1890015986",
				"_name": "Schnapperl-Puppe"
			},
			{
				"_id": "4005810001",
				"_name": "Nya-ha-ha-Rolle"
			},
			{
				"_id": "2579824583",
				"_name": "Vernyichter-Rolle"
			},
			{
				"_id": "13479549",
				"_name": "Ausnyocker-Rolle"
			},
			{
				"_id": "4158121970",
				"_name": "Krapfen der Einheit"
			},
			{
				"_id": "1860089416",
				"_name": "Wichtige Papiere"
			},
			{
				"_id": "2277315453",
				"_name": "Gespenstischer Glibber"
			},
			{
				"_id": "4038730731",
				"_name": "Rote Schlüsselkarte"
			},
			{
				"_id": "1773367889",
				"_name": "Blaue Schlüsselkarte"
			},
			{
				"_id": "515130055",
				"_name": "Goldene Schlüsselkarte"
			},
			{
				"_id": "2383109974",
				"_name": "Muskel-Gürtel"
			},
			{
				"_id": "4178341824",
				"_name": "Stumpfes Schwert"
			},
			{
				"_id": "2580276773",
				"_name": "Makelloser Retro-Robo"
			},
			{
				"_id": "4006401715",
				"_name": "Abgenutzter Retro-Robo"
			},
			{
				"_id": "2009433865",
				"_name": "Schatzkarte"
			},
			{
				"_id": "12760991",
				"_name": "Durchnässte Karte"
			},
			{
				"_id": "2661687868",
				"_name": "Zerknitterte Karte"
			},
			{
				"_id": "3919647402",
				"_name": "Fleckige Karte"
			},
			{
				"_id": "1890075408",
				"_name": "Weitere Schatzkarte"
			},
			{
				"_id": "128938886",
				"_name": "Schatzkammer-Schlüssel"
			},
			{
				"_id": "2534436375",
				"_name": "Endgültige Schatzkarte"
			},
			{
				"_id": "3759627905",
				"_name": "Seltsamer Hebel"
			},
			{
				"_id": "3001464294",
				"_name": "SW-Fotoapparat"
			},
			{
				"_id": "3319891312",
				"_name": "Schulfoto"
			},
			{
				"_id": "1558762698",
				"_name": "Foto der Ladenpassage"
			},
			{
				"_id": "737141852",
				"_name": "Kalebessi-Foto"
			},
			{
				"_id": "3045814783",
				"_name": "SM-Autogramm"
			},
			{
				"_id": "3263971689",
				"_name": "Handgef. Handtuch"
			},
			{
				"_id": "3848423452",
				"_name": "Scharfzahn. Kamm"
			},
			{
				"_id": "2087393702",
				"_name": "„Dance Revolution“"
			},
			{
				"_id": "191637808",
				"_name": "Hexpress-Karte"
			},
			{
				"_id": "2500377747",
				"_name": "GG-Land-Ticket"
			},
			{
				"_id": "3792669701",
				"_name": "Schöntal-Ticket"
			},
			{
				"_id": "2064047551",
				"_name": "Schlinger-Ticket"
			},
			{
				"_id": "201452841",
				"_name": "Himmelsbad-Ticket"
			},
			{
				"_id": "2629759160",
				"_name": "Bergbad-Ticket"
			},
			{
				"_id": "3954819118",
				"_name": "Hügelbad-Ticket"
			},
			{
				"_id": "2340309451",
				"_name": "Wandererbad-Tick."
			},
			{
				"_id": "4235819357",
				"_name": "Waldbad-Ticket"
			},
			{
				"_id": "1701849319",
				"_name": "Glücksquell-Ticket"
			},
			{
				"_id": "309794929",
				"_name": "Schatzbad-Ticket"
			},
			{
				"_id": "2350091730",
				"_name": "Ausrüstungsgürtel"
			},
			{
				"_id": "4212440388",
				"_name": "Schattenumhang"
			},
			{
				"_id": "1646128382",
				"_name": "Bremshebel"
			},
			{
				"_id": "354081896",
				"_name": "Sorglos-Fahrkarte"
			},
			{
				"_id": "2242232825",
				"_name": "Glücksmünze"
			},
			{
				"_id": "4070764911",
				"_name": "Mumm-Abzeichen"
			},
			{
				"_id": "2689800712",
				"_name": "Important Item 20"
			},
			{
				"_id": "3612617374",
				"_name": "Important Item 21"
			},
			{
				"_id": "1314749220",
				"_name": "Important Item 22"
			},
			{
				"_id": "962218930",
				"_name": "Important Item 23"
			},
			{
				"_id": "2805915153",
				"_name": "Important Item 24"
			},
			{
				"_id": "3493457543",
				"_name": "Important Item 25"
			},
			{
				"_id": "3503128323",
				"_name": "Kantalupensamen"
			},
			{
				"_id": "2815053717",
				"_name": "Orangensamen"
			},
			{
				"_id": "930435588",
				"_name": "Kiwisamen"
			},
			{
				"_id": "1081238162",
				"_name": "Traubensamen"
			},
			{
				"_id": "548793207",
				"_name": "Erdbeersamen"
			},
			{
				"_id": "1471339489",
				"_name": "Melonensamen"
			},
			{
				"_id": "3468397147",
				"_name": "Wandakappa-Zahnrad"
			},
			{
				"_id": "3116153549",
				"_name": "Komasan-Zahnrad"
			},
			{
				"_id": "668479342",
				"_name": "Opa-Gusto-Zahnrad"
			},
			{
				"_id": "1356799992",
				"_name": "Möter-Zahnrad"
			},
			{
				"_id": "3386265154",
				"_name": "Noko-Zahnrad"
			},
			{
				"_id": "3201400532",
				"_name": "Dracki-Zahnrad"
			},
			{
				"_id": "778986309",
				"_name": "Serie-F-Glocke"
			},
			{
				"_id": "1500074963",
				"_name": "Herzige Glocke"
			},
			{
				"_id": "194558132",
				"_name": "Tiger-Glocke"
			},
			{
				"_id": "2090829858",
				"_name": "Abenteurer-Glocke"
			},
			{
				"_id": "3851868568",
				"_name": "Jet-Glocke"
			},
			{
				"_id": "2459035918",
				"_name": "Gewickeltes WAH!"
			},
			{
				"_id": "217414829",
				"_name": "Geliebter Deckel"
			},
			{
				"_id": "2079476795",
				"_name": "Düstere Glocke"
			}
		]
	}
}
