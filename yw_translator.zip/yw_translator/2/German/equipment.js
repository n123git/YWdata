xmlval = {
	"items": {
		"item": [
			{
				"_id": "1158785574",
				"_name": "Einfacher Armreif"
			},
			{
				"_id": "3681894277",
				"_name": "Billiger Armreif"
			},
			{
				"_id": "3692624796",
				"_name": "Nietenarmband"
			},
			{
				"_id": "2893156115",
				"_name": "Power-Armreif"
			},
			{
				"_id": "2870987530",
				"_name": "Abd. d. Rohlings"
			},
			{
				"_id": "1020072578",
				"_name": "Prächtiger Armreif"
			},
			{
				"_id": "897277609",
				"_name": "Armreif der Sonne"
			},
			{
				"_id": "1271538196",
				"_name": "Kometen-Armreif"
			},
			{
				"_id": "1115450943",
				"_name": "Arf. d. Unholds"
			},
			{
				"_id": "722316273",
				"_name": "Legendärer Armreif"
			},
			{
				"_id": "1154727953",
				"_name": "Rostiger Ring"
			},
			{
				"_id": "3669448114",
				"_name": "Hässlicher Ring"
			},
			{
				"_id": "3722088875",
				"_name": "Hübscher Ring"
			},
			{
				"_id": "2914018596",
				"_name": "Regenbogenring"
			},
			{
				"_id": "2866651453",
				"_name": "Ring der Illusion"
			},
			{
				"_id": "1024424117",
				"_name": "Feenring"
			},
			{
				"_id": "884552862",
				"_name": "Ring des Mondlichts"
			},
			{
				"_id": "1242056739",
				"_name": "Ring des Schicksals"
			},
			{
				"_id": "1136526344",
				"_name": "Ring des Unholds"
			},
			{
				"_id": "718258630",
				"_name": "Legendärer Ring"
			},
			{
				"_id": "1184202312",
				"_name": "Altes Amulett"
			},
			{
				"_id": "3639733227",
				"_name": "Abgenutztes Amulett"
			},
			{
				"_id": "3751555058",
				"_name": "Runenamulett"
			},
			{
				"_id": "2952190845",
				"_name": "Schutzamulett"
			},
			{
				"_id": "2828738404",
				"_name": "Rüstungsamulett"
			},
			{
				"_id": "1061799660",
				"_name": "Glücksamulett"
			},
			{
				"_id": "922716871",
				"_name": "Amulett der Galaxie"
			},
			{
				"_id": "1213134458",
				"_name": "Erdamulett"
			},
			{
				"_id": "1106819665",
				"_name": "Amulett des Unholds"
			},
			{
				"_id": "680099743",
				"_name": "Legendäres Amulett"
			},
			{
				"_id": "1196889215",
				"_name": "Einfaches Emblem"
			},
			{
				"_id": "3644031452",
				"_name": "Schwarzes Emblem"
			},
			{
				"_id": "3730720197",
				"_name": "Glänz. Emblem"
			},
			{
				"_id": "2922688842",
				"_name": "Niedliches Emblem"
			},
			{
				"_id": "2841212243",
				"_name": "Hermes-Emblem"
			},
			{
				"_id": "1049341147",
				"_name": "Aurora-Emblem"
			},
			{
				"_id": "926802160",
				"_name": "Sterns.-Emblem"
			},
			{
				"_id": "1233951821",
				"_name": "Blitz-Emblem"
			},
			{
				"_id": "1077596262",
				"_name": "Emblem des Unholds"
			},
			{
				"_id": "692786600",
				"_name": "Legendäres Emblem"
			},
			{
				"_id": "1108869882",
				"_name": "Zikadenschwert"
			},
			{
				"_id": "3675345728",
				"_name": "Stärkungsglocke"
			},
			{
				"_id": "2887148502",
				"_name": "Geistesglocke"
			},
			{
				"_id": "846394997",
				"_name": "Schutzglocke"
			},
			{
				"_id": "1165346531",
				"_name": "Geschw.glocke"
			},
			{
				"_id": "3699152729",
				"_name": "Immervolle Flasche"
			},
			{
				"_id": "2877007823",
				"_name": "Tengu-Fächer"
			},
			{
				"_id": "1002748510",
				"_name": "Muntermantel"
			},
			{
				"_id": "1287883464",
				"_name": "Nagelkeule"
			},
			{
				"_id": "1550776226",
				"_name": "Trommelschlägel"
			},
			{
				"_id": "3311904280",
				"_name": "Robo-Vitamin E"
			},
			{
				"_id": "2992674446",
				"_name": "Schleifers Armband"
			},
			{
				"_id": "585075487",
				"_name": "Glocke der Erinnerung"
			},
			{
				"_id": "3037549207",
				"_name": "Knochi-Stirnband"
			},
			{
				"_id": "728352564",
				"_name": "Krafti-Stirnband"
			},
			{
				"_id": "738460461",
				"_name": "Umgeschwert"
			},
			{
				"_id": "1526936507",
				"_name": "Wandelstein"
			},
			{
				"_id": "3255460353",
				"_name": "Reflektor"
			},
			{
				"_id": "1440267145",
				"_name": "Paradieskugel"
			},
			{
				"_id": "1138387149",
				"_name": "Finsterbrief"
			},
			{
				"_id": "3671275895",
				"_name": "Verfluchtes Schwert"
			},
			{
				"_id": "2916354529",
				"_name": "Verfluchter Stab"
			},
			{
				"_id": "867212354",
				"_name": "Verfluchter Schild"
			},
			{
				"_id": "1152888020",
				"_name": "Verfluchtes Gewand"
			},
			{
				"_id": "1100797588",
				"_name": "Zurückhalt.gürtel"
			},
			{
				"_id": "2945628088",
				"_name": "Affendiadem"
			},
			{
				"_id": "4256025923",
				"_name": "Orden des Generals"
			},
			{
				"_id": "1688509689",
				"_name": "Orden d. Generalleutnants"
			},
			{
				"_id": "329493615",
				"_name": "Orden des Generalmajors"
			},
			{
				"_id": "2378643916",
				"_name": "Orden des Oberst"
			},
			{
				"_id": "4206889306",
				"_name": "Orden des Majors"
			},
			{
				"_id": "1674139872",
				"_name": "Orden des Hauptmanns"
			},
			{
				"_id": "349071478",
				"_name": "Orden des Kommandanten"
			},
			{
				"_id": "2222028263",
				"_name": "Orden des Leutnants"
			}
		]
	}
}
