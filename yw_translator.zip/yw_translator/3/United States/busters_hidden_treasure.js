xmlval = {
	"items": {
		"item": [
			{
				"_id": "349196265",
				"_name": "Prestigio. Treasure"
			},
			{
				"_id": "2379816531",
				"_name": "Insightful Treasure"
			},
			{
				"_id": "4208864965",
				"_name": "Adept's Treasure"
			},
			{
				"_id": "1689959270",
				"_name": "Spirited Treasure"
			}
		]
	}
}
