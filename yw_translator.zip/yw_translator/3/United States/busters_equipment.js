xmlval = {
	"items": {
		"item": [
			{
				"_id": "1993296984",
				"_name": "Apprentice Sword"
			},
			{
				"_id": "4022738402",
				"_name": "Star Pupil's Sword"
			},
			{
				"_id": "2562796916",
				"_name": "Master's Sword"
			},
			{
				"_id": "111524055",
				"_name": "Scoundrel. Scimitar"
			},
			{
				"_id": "1906477121",
				"_name": "Sorcerer's Sword"
			},
			{
				"_id": "3903576571",
				"_name": "Pirate King's Blade"
			},
			{
				"_id": "2678909293",
				"_name": "Archfiend's Blade"
			},
			{
				"_id": "252966140",
				"_name": "Thunder Blade"
			},
			{
				"_id": "2014626922",
				"_name": "Crescent Moon"
			},
			{
				"_id": "416501135",
				"_name": "Crimson Edge"
			},
			{
				"_id": "1876196633",
				"_name": "Divine Blade"
			},
			{
				"_id": "4141690019",
				"_name": "Moxcalibur"
			},
			{
				"_id": "3463654205",
				"_name": "Brave Cat Whisker"
			},
			{
				"_id": "1467644551",
				"_name": "Metal Cat Musket"
			},
			{
				"_id": "545081873",
				"_name": "Moon Rabbit Ears"
			},
			{
				"_id": "3189366706",
				"_name": "Serpent's Spear"
			},
			{
				"_id": "3374247716",
				"_name": "Guardian's Cane"
			},
			{
				"_id": "1343733406",
				"_name": "Lucky Snake Globe"
			},
			{
				"_id": "655396360",
				"_name": "Fearless Cat Fang"
			},
			{
				"_id": "3081737113",
				"_name": "Twin Fox Flames"
			},
			{
				"_id": "3232277263",
				"_name": "Guardian's Codex"
			},
			{
				"_id": "2691640042",
				"_name": "Crimson Cat Paw"
			},
			{
				"_id": "3613923964",
				"_name": "White Wisp Bow"
			},
			{
				"_id": "1314999238",
				"_name": "Snow Maiden Staff"
			},
			{
				"_id": "963017552",
				"_name": "Eerie Mutt Book"
			},
			{
				"_id": "3703997651",
				"_name": "Treasure Watch"
			},
			{
				"_id": "197592018",
				"_name": "Crimson Edge"
			},
			{
				"_id": "2462995048",
				"_name": "Crimson Edge"
			},
			{
				"_id": "3855180542",
				"_name": "Crimson Edge"
			},
			{
				"_id": "2574200442",
				"_name": "Round Shield"
			},
			{
				"_id": "6717376",
				"_name": "Iron Shield"
			},
			{
				"_id": "2002866006",
				"_name": "Silver Shield"
			},
			{
				"_id": "3909475061",
				"_name": "Soldier's Shield"
			},
			{
				"_id": "2650991203",
				"_name": "Paladin's Shield"
			},
			{
				"_id": "118209497",
				"_name": "Crystal Shield"
			},
			{
				"_id": "1879870287",
				"_name": "Veritas Shield"
			},
			{
				"_id": "3769865950",
				"_name": "Legend Shield"
			},
			{
				"_id": "2545198664",
				"_name": "Hero's Shield"
			},
			{
				"_id": "4151521197",
				"_name": "Neptunia Shield"
			},
			{
				"_id": "2155093819",
				"_name": "Eternity Shield"
			},
			{
				"_id": "427642497",
				"_name": "Diabolic Shield"
			},
			{
				"_id": "567494943",
				"_name": "Legendary Buckler"
			},
			{
				"_id": "3831980528",
				"_name": "Hero's Shield"
			},
			{
				"_id": "2104373322",
				"_name": "Hero's Shield"
			},
			{
				"_id": "174653660",
				"_name": "Hero's Shield"
			}
		]
	}
}
